# Decisión de Stack Frontend – LaundryDesk

**Proyecto:** LaundryDesk  
**Actividad:** Elección del stack de frontend  
**Documento de decisión del equipo:** `decision_stack_frontend.md`

## 1. Stack elegido

Después de comparar las propuestas individuales del equipo y considerar la experiencia disponible, la arquitectura actual del backend y la complejidad de la interfaz requerida para LaundryDesk, se decidió utilizar el siguiente stack:

| Elemento | Tecnología elegida |
|---|---|
| Framework / librería de UI | React |
| Herramienta de construcción / servidor de desarrollo | Vite |
| Enfoque de estilos | Bootstrap 5 |
| Manejo de estado | Estado local de React (`useState` / `useReducer`) + Context API para la sesión |
| Navegación | React Router |
| Comunicación con backend | Fetch API |
| Formato de intercambio | JSON |
| Autenticación | JWT mediante `Authorization: Bearer <token>` |
| Variable de entorno para API | `VITE_API_URL` |

El frontend se desarrollará como una aplicación React construida con Vite y consumirá exclusivamente la API REST existente de LaundryDesk.

La arquitectura general será:

```text
React + Vite
     |
     | HTTP / JSON
     | Authorization: Bearer <JWT>
     v
Django REST Framework
     |
     v
PostgreSQL
```

## 2. Razones principales de la elección

La decisión se tomó considerando principalmente tres factores: experiencia del equipo, integración con el backend existente y complejidad real del proyecto.

### 2.1 Experiencia del equipo

React es la alternativa con la que el equipo ya tiene experiencia práctica durante las actividades recientes del curso. Esto reduce el riesgo de introducir una nueva tecnología únicamente para esta fase del proyecto.

Elegir React permite reutilizar conocimientos ya adquiridos sobre componentes, estado, consumo de APIs REST y ejecución mediante Vite.

En contraste, Alpine.js fue una alternativa técnicamente válida, pero no forma parte de la experiencia práctica reciente del equipo.

### 2.2 Integración con el backend

El backend de LaundryDesk ya está implementado como una API REST independiente utilizando Django y Django REST Framework.

React se utilizará únicamente como cliente web y no tendrá acceso directo a la base de datos. Toda comunicación se realizará a través del contrato definido por la API.

La URL base del backend será configurable mediante:

```env
VITE_API_URL=http://localhost:8000/api/v1
```

Las rutas administrativas enviarán el JWT mediante:

```http
Authorization: Bearer <token>
```

Las rutas públicas podrán consumirse sin autenticación cuando así lo defina el contrato de la API.

### 2.3 Complejidad del frontend

LaundryDesk requiere una interfaz pública y una interfaz administrativa.

Entre las funciones principales se encuentran la consulta de servicios y horarios, seguimiento de pedidos, autenticación del administrador, registro y consulta de pedidos, actualización de estados y administración de información operativa.

React permite dividir estas funcionalidades en componentes y páginas reutilizables sin requerir un framework de mayor complejidad.

## 3. Herramienta de construcción: Vite

Se seleccionó Vite como herramienta de construcción y servidor de desarrollo.

Las razones principales son:

- configuración inicial sencilla;
- integración directa con React;
- servidor de desarrollo rápido;
- soporte para variables de entorno;
- estructura de proyecto clara;
- menor configuración manual que Webpack.

El proyecto podrá iniciarse durante desarrollo con:

```bash
npm install
npm run dev
```

Vite también permite generar archivos estáticos mediante `npm run build`, por lo que el frontend podrá desplegarse como archivos estáticos sin obligar al proyecto a mantener un servidor Node.js en producción.

## 4. Enfoque de estilos: Bootstrap 5

Se eligió Bootstrap 5 como enfoque principal de estilos.

La decisión se basa en que LaundryDesk necesita componentes comunes de interfaz como formularios, botones, tablas, tarjetas, mensajes, barras de navegación y estructuras responsivas.

Bootstrap ofrece estos elementos sin requerir la creación de un sistema de estilos completo desde cero.

También ayuda a cumplir con el requisito de una interfaz adaptable a diferentes tamaños de pantalla mediante su sistema de rejilla responsiva.

El equipo podrá agregar CSS propio cuando un componente requiera personalización adicional.

## 5. Manejo de estado

Para el manejo de estado se decidió utilizar las herramientas incluidas en React.

El estado local de cada página o componente se manejará mediante `useState` y, cuando sea necesario, `useReducer`.

Context API se utilizará únicamente para información que realmente deba compartirse entre diferentes partes de la aplicación, principalmente la sesión del administrador.

Conceptualmente:

```text
AuthContext
├── usuario autenticado
├── token JWT
├── login()
└── logout()
```

No se utilizará Redux ni Zustand en esta etapa debido a que el proyecto no presenta un estado global suficientemente complejo que justifique una dependencia adicional.

Si la complejidad del frontend aumenta significativamente, esta decisión podrá revisarse posteriormente.

## 6. Navegación y comunicación con la API

Se utilizará React Router para manejar la navegación entre las diferentes páginas de la aplicación.

La comunicación con el backend se realizará inicialmente mediante Fetch API, evitando agregar una dependencia adicional mientras las necesidades de comunicación HTTP sean sencillas.

Las llamadas al backend se centralizarán en la carpeta:

```text
src/services/
```

Esto permitirá separar la lógica de presentación de la lógica de comunicación con la API.

Una estructura esperada es:

```text
services/
├── api.js
├── authService.js
├── pedidosService.js
├── serviciosService.js
└── horariosService.js
```

## 7. Alternativas consideradas y razones de descarte

### Alpine.js + Bootstrap

Fue una de las propuestas más fuertes porque puede integrarse directamente con plantillas Django, reduce el número de herramientas de construcción y permite mantener una sola unidad desplegable.

Sin embargo, se descartó como decisión final debido a que el equipo ya tiene experiencia práctica reciente con React y no con Alpine.js.

Además, React puede compilarse mediante Vite a archivos HTML, CSS y JavaScript estáticos, por lo que puede conservarse una estrategia de despliegue sencilla.

### React + TypeScript + Tailwind CSS

Esta alternativa ofrece ventajas como tipado estático y rapidez para crear estilos mediante clases utilitarias.

Sin embargo, se decidió no incorporar TypeScript y Tailwind CSS en esta etapa para evitar aumentar simultáneamente la curva de aprendizaje y la cantidad de tecnologías que el equipo debe dominar.

JavaScript con React es suficiente para el alcance actual, mientras que Bootstrap cubre los requerimientos visuales y responsivos principales.

### CSS Modules

CSS Modules proporciona una buena separación de estilos por componente y evita conflictos entre nombres de clases.

Se consideró una opción válida, pero Bootstrap fue seleccionado porque reduce el tiempo necesario para construir elementos comunes como formularios, tablas, botones, tarjetas y navegación.

CSS propio podrá seguir utilizándose cuando se necesite personalización.

### Vue 3

Vue 3 es una alternativa válida por su sistema de componentes y curva de aprendizaje accesible.

Sin embargo, elegir Vue implicaría cambiar a otra tecnología cuando el equipo ya cuenta con experiencia reciente utilizando React.

### Angular

Angular proporciona una estructura completa para aplicaciones grandes, pero introduce una curva de aprendizaje y una cantidad de conceptos mayor a la necesaria para el alcance actual de LaundryDesk.

### Next.js

Next.js agrega capacidades como renderizado del lado del servidor y generación estática avanzada.

Estas capacidades no son necesarias actualmente porque LaundryDesk ya cuenta con un backend REST independiente y el frontend funcionará principalmente como cliente de esa API.

### JavaScript Vanilla

JavaScript sin framework reduciría las dependencias del proyecto.

Sin embargo, conforme aumenten las páginas, formularios, estado de autenticación y componentes reutilizables, el mantenimiento manual del DOM y del estado sería más complejo.

### Redux / Zustand

Ambas herramientas son útiles cuando existe estado global complejo.

En LaundryDesk, el estado compartido identificado actualmente se concentra principalmente en la sesión del administrador, por lo que Context API resulta suficiente.

## 8. Estructura inicial esperada

El scaffolding inicial seguirá aproximadamente esta estructura:

```text
frontend/
├── src/
│   ├── assets/
│   ├── components/
│   ├── context/
│   ├── pages/
│   ├── services/
│   ├── styles/
│   ├── App.jsx
│   └── main.jsx
├── .env.example
├── package.json
└── vite.config.js
```

Las responsabilidades principales serán:

| Carpeta | Responsabilidad |
|---|---|
| `components/` | Componentes reutilizables de interfaz |
| `pages/` | Pantallas completas de la aplicación |
| `services/` | Comunicación con la API REST |
| `context/` | Estado compartido y autenticación |
| `assets/` | Imágenes, iconos y otros recursos |
| `styles/` | Estilos globales o personalizaciones adicionales |

## 9. Justificación final

El stack seleccionado es:

**React + Vite + Bootstrap 5 + estado local de React + Context API**

con React Router para navegación y Fetch API para comunicación con el backend.

La decisión busca utilizar tecnologías que el equipo ya conoce, mantener una separación clara entre frontend y backend, reducir dependencias innecesarias y conservar una estructura suficientemente modular para continuar creciendo durante el resto del curso.

React proporciona el modelo de componentes necesario para la interfaz, Vite simplifica el entorno de desarrollo, Bootstrap acelera la construcción de una interfaz responsiva y Context API cubre el estado global limitado que actualmente requiere LaundryDesk.

La elección mantiene además la filosofía spec-first del proyecto: el frontend consumirá la API definida por el contrato existente y no dependerá directamente de la implementación interna del backend.

## 10. Decisión

A partir de esta actividad, el stack oficial del frontend de LaundryDesk será:

**React + Vite + Bootstrap 5 + React Context API / estado local**, utilizando **React Router**, **Fetch API**, **JWT Bearer** y la variable de entorno **`VITE_API_URL`**.

Esta decisión será la base para el scaffolding y los componentes desarrollados durante las siguientes partes de la actividad.
