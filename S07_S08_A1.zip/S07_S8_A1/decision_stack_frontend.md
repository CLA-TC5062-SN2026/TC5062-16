Propuesta personal de stack de frontend — LaundryDesk

Integrante: Diego Hurtado  
Proyecto: LaundryDesk  
Actividad: Elección del stack de frontend

1\. Stack propuesto

Para el desarrollo del frontend de LaundryDesk propongo utilizar el siguiente stack:

<table width="964.0" cellspacing="0" cellpadding="0" style="width: 964.0px; border-style: solid; border-width: 1.0px 1.0px 1.0px 1.0px; border-color: #000000 #000000 #000000 #000000; border-collapse: collapse"><tbody><tr><td valign="middle" style="width: 278.7px; border-style: solid; border-width: 1.0px 1.0px 1.0px 1.0px; border-color: #000000 #000000 #000000 #000000; padding: 8.0px 12.0px 8.0px 12.0px"><p style="margin: 0.0px 0.0px 12.0px 0.0px; text-align: center; font: 12.0px 'Times New Roman'; -webkit-text-stroke: #000000"><span style="font-family: 'TimesNewRomanPS-BoldMT'; font-weight: bold; font-style: normal; font-size: 12.00px; font-kerning: none">Elemento</span></p></td><td valign="middle" style="width: 635.3px; border-style: solid; border-width: 1.0px 1.0px 1.0px 1.0px; border-color: #000000 #000000 #000000 #000000; padding: 8.0px 12.0px 8.0px 12.0px"><p style="margin: 0.0px 0.0px 12.0px 0.0px; text-align: center; font: 20.0px 'Times New Roman'; -webkit-text-stroke: #000000"><span style="font-family: 'TimesNewRomanPS-BoldMT'; font-weight: bold; font-style: normal; font-size: 20.00px; font-kerning: none">Tecnología propuesta</span></p></td></tr><tr><td valign="middle" style="width: 278.7px; border-style: solid; border-width: 1.0px 1.0px 1.0px 1.0px; border-color: #000000 #000000 #000000 #000000; padding: 8.0px 12.0px 8.0px 12.0px"><p style="margin: 0.0px 0.0px 12.0px 0.0px; font: 12.0px 'Times New Roman'; -webkit-text-stroke: #000000"><span style="font-family: 'Times New Roman'; font-weight: normal; font-style: normal; font-size: 12.00px; font-kerning: none">Framework / librería de UI</span></p></td><td valign="middle" style="width: 635.3px; border-style: solid; border-width: 1.0px 1.0px 1.0px 1.0px; border-color: #000000 #000000 #000000 #000000; padding: 8.0px 12.0px 8.0px 12.0px"><p style="margin: 0.0px 0.0px 12.0px 0.0px; font: 20.0px 'Times New Roman'; -webkit-text-stroke: #000000"><span style="font-family: 'TimesNewRomanPS-BoldMT'; font-weight: bold; font-style: normal; font-size: 20.00px; font-kerning: none">React con TypeScript</span></p></td></tr><tr><td valign="middle" style="width: 278.7px; border-style: solid; border-width: 1.0px 1.0px 1.0px 1.0px; border-color: #000000 #000000 #000000 #000000; padding: 8.0px 12.0px 8.0px 12.0px"><p style="margin: 0.0px 0.0px 12.0px 0.0px; font: 12.0px 'Times New Roman'; -webkit-text-stroke: #000000"><span style="font-family: 'Times New Roman'; font-weight: normal; font-style: normal; font-size: 12.00px; font-kerning: none">Herramienta de construcción / servidor de desarrollo</span></p></td><td valign="middle" style="width: 635.3px; border-style: solid; border-width: 1.0px 1.0px 1.0px 1.0px; border-color: #000000 #000000 #000000 #000000; padding: 8.0px 12.0px 8.0px 12.0px"><p style="margin: 0.0px 0.0px 12.0px 0.0px; font: 20.0px 'Times New Roman'; -webkit-text-stroke: #000000"><span style="font-family: 'TimesNewRomanPS-BoldMT'; font-weight: bold; font-style: normal; font-size: 20.00px; font-kerning: none">Vite</span></p></td></tr><tr><td valign="middle" style="width: 278.7px; border-style: solid; border-width: 1.0px 1.0px 1.0px 1.0px; border-color: #000000 #000000 #000000 #000000; padding: 8.0px 12.0px 8.0px 12.0px"><p style="margin: 0.0px 0.0px 12.0px 0.0px; font: 12.0px 'Times New Roman'; -webkit-text-stroke: #000000"><span style="font-family: 'Times New Roman'; font-weight: normal; font-style: normal; font-size: 12.00px; font-kerning: none">Enfoque de estilos</span></p></td><td valign="middle" style="width: 635.3px; border-style: solid; border-width: 1.0px 1.0px 1.0px 1.0px; border-color: #000000 #000000 #000000 #000000; padding: 8.0px 12.0px 8.0px 12.0px"><p style="margin: 0.0px 0.0px 12.0px 0.0px; font: 20.0px 'Times New Roman'; -webkit-text-stroke: #000000"><span style="font-family: 'TimesNewRomanPS-BoldMT'; font-weight: bold; font-style: normal; font-size: 20.00px; font-kerning: none">Tailwind CSS</span></p></td></tr><tr><td valign="middle" style="width: 278.7px; border-style: solid; border-width: 1.0px 1.0px 1.0px 1.0px; border-color: #000000 #000000 #000000 #000000; padding: 8.0px 12.0px 8.0px 12.0px"><p style="margin: 0.0px 0.0px 12.0px 0.0px; font: 12.0px 'Times New Roman'; -webkit-text-stroke: #000000"><span style="font-family: 'Times New Roman'; font-weight: normal; font-style: normal; font-size: 12.00px; font-kerning: none">Manejo de estado</span></p></td><td valign="middle" style="width: 635.3px; border-style: solid; border-width: 1.0px 1.0px 1.0px 1.0px; border-color: #000000 #000000 #000000 #000000; padding: 8.0px 12.0px 8.0px 12.0px"><p style="margin: 0.0px 0.0px 12.0px 0.0px; font: 20.0px 'Times New Roman'; -webkit-text-stroke: #000000"><span style="font-family: 'TimesNewRomanPS-BoldMT'; font-weight: bold; font-style: normal; font-size: 20.00px; font-kerning: none">Context API + estado local de React (</span><span style="font-family: 'Courier'; font-weight: bold; font-style: normal; font-size: 22.00px; font-kerning: none">useState</span><span style="font-family: 'TimesNewRomanPS-BoldMT'; font-weight: bold; font-style: normal; font-size: 20.00px; font-kerning: none"> / </span><span style="font-family: 'Courier'; font-weight: bold; font-style: normal; font-size: 22.00px; font-kerning: none">useReducer</span><span style="font-family: 'TimesNewRomanPS-BoldMT'; font-weight: bold; font-style: normal; font-size: 20.00px; font-kerning: none">)</span></p></td></tr></tbody></table>

Como herramientas complementarias propondría utilizar React Router para la navegación entre vistas y fetch o Axios para el consumo de la API REST.

2\. React con TypeScript

Propongo utilizar React porque considero que se adapta bien al tipo de interfaz que necesita LaundryDesk. El sistema puede dividirse de manera natural en componentes reutilizables para las distintas funciones públicas y administrativas.

Entre las vistas y componentes que se pueden construir se encuentran:

- inicio de sesión del administrador;
- consulta pública de servicios y precios;
- consulta de horarios;
- seguimiento del estado de un pedido;
- listado y detalle de pedidos;
- formularios para registrar y modificar información;
- administración de servicios y horarios;
- actualización del estado de los pedidos.

El backend ya está desarrollado como una API REST independiente utilizando Django y Django REST Framework, por lo que React puede utilizarse como cliente web sin necesidad de acoplar la interfaz al backend.

Además, propongo utilizar TypeScript en lugar de JavaScript puro. El proyecto maneja diferentes objetos del dominio, como pedidos, servicios, horarios, administradores e historiales de estado. El tipado permite definir interfaces para estos objetos y detectar errores durante el desarrollo antes de ejecutar la aplicación.

3\. Vite

Como herramienta de construcción y servidor de desarrollo propongo Vite.

Vite permite crear un proyecto React con TypeScript con muy poca configuración y proporciona un servidor de desarrollo rápido. Para el alcance de LaundryDesk considero que esto es conveniente porque permite concentrar el esfuerzo en las funcionalidades del sistema en lugar de dedicar tiempo a configurar manualmente herramientas como Webpack.

4\. Tailwind CSS

Para los estilos propongo utilizar Tailwind CSS.

LaundryDesk tendrá tanto una interfaz pública como una interfaz administrativa, por lo que será necesario mantener consistencia visual entre botones, formularios, tablas, tarjetas, mensajes de error, estados del pedido y menús de navegación.

Tailwind CSS permite construir estos elementos mediante clases utilitarias y facilita mantener un diseño consistente sin crear una gran cantidad de archivos CSS separados.

5\. Manejo de estado

Para el manejo de estado propongo comenzar utilizando las herramientas incluidas en React:

- useState para el estado local de componentes y formularios;
- useReducer si algún componente requiere manejar un estado más complejo;
- Context API para información que debe compartirse entre diferentes partes de la aplicación.

El principal estado global que identifico actualmente es la sesión del administrador, incluyendo la información del usuario autenticado y el token JWT necesario para consumir los endpoints protegidos del backend.

No considero necesario introducir Redux en esta etapa porque el alcance actual de LaundryDesk no presenta un estado global lo suficientemente complejo para justificar esa dependencia adicional.

Si conforme avance el proyecto el manejo de estado aumenta considerablemente, una alternativa que podría evaluarse posteriormente es Zustand.

6\. Integración con el backend actual

La propuesta se integra directamente con la arquitectura actual de LaundryDesk:

- Django + Django REST Framework para el backend;
- PostgreSQL como base de datos;
- API REST bajo /api/v1;
- respuestas en formato JSON;
- autenticación mediante JWT;
- encabezado Authorization: Bearer <token> para rutas protegidas.

El frontend desarrollado con React consumiría estos endpoints mediante HTTP y utilizaría el JWT recibido después del login para acceder a las funciones administrativas.

7\. Adecuación al proyecto LaundryDesk

LaundryDesk necesita dos tipos principales de interfaz.

Interfaz pública

El cliente debe poder:

- consultar servicios y precios;
- consultar horarios;
- consultar el estado de un pedido mediante su código de seguimiento.

Interfaz administrativa

El administrador debe poder:

- autenticarse;
- consultar pedidos;
- administrar servicios;
- administrar horarios;
- modificar estados de pedidos;
- registrar información relacionada con la operación.

React resulta conveniente para estas interfaces porque permite dividir la aplicación en componentes reutilizables y actualizar la información sin recargar completamente la página.

8\. Alternativas consideradas

Vue 3

Vue también sería una alternativa válida por su simplicidad y sistema de componentes. Sin embargo, prefiero React por su amplio ecosistema, documentación e integración con TypeScript.

Angular

Angular ofrece una solución muy completa, pero considero que introduce una complejidad mayor a la necesaria para el alcance actual de LaundryDesk.

Next.js

Next.js agrega capacidades como SSR y generación estática. Para LaundryDesk no identifico una necesidad importante de estas funciones, ya que el backend ya existe como API REST independiente.

JavaScript vanilla

Es posible desarrollar la interfaz sin framework, pero conforme crezcan las vistas y formularios, el mantenimiento del DOM y del estado sería más complejo.

Redux

Redux podría utilizarse para manejar estado global, pero actualmente sería una solución más compleja de lo necesario. Context API y estado local deberían ser suficientes.

9\. Ventajas de la propuesta

- Integración directa con la API REST existente.
- Componentes reutilizables.
- Tipado mediante TypeScript.
- Configuración sencilla con Vite.
- Desarrollo rápido de estilos con Tailwind CSS.
- Manejo de estado sin dependencias innecesarias.
- Amplia documentación y comunidad.
- Facilidad para ampliar el frontend posteriormente.
- Separación clara entre frontend y backend.

10\. Posibles desventajas

La principal desventaja es la curva de aprendizaje inicial de React, TypeScript y Tailwind CSS para integrantes con poca experiencia previa.

Además, Tailwind puede generar componentes con muchas clases directamente en el JSX si no se mantiene una buena organización.

Aun así, considero que estas desventajas son manejables para el alcance del proyecto.

11\. Propuesta final

Mi propuesta personal para el frontend de LaundryDesk es:

React + TypeScript + Vite + Tailwind CSS + Context API/estado local de React.

Como complementos utilizaría React Router para navegación y fetch o Axios para comunicarse con la API.

Considero que esta combinación ofrece un buen equilibrio entre facilidad de implementación, mantenibilidad y capacidad de crecimiento, además de integrarse de manera directa con el backend REST con JWT que ya fue desarrollado para LaundryDesk.