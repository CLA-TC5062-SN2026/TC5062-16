# Decisión de stack de frontend — LaundryDesk (propuesta individual)



\---

## 1\. Qué ya fija el backend

El stack del backend se acordó en el chat del equipo y quedó documentado en `arquitectura\_equipo.md`. Estas restricciones son las que el frontend debe respetar:

|Restricción ya acordada|Fuente|Implicación para el frontend|
|-|-|-|
|Django 5.2 LTS, DRF y PostgreSQL 16|`arquitectura\_equipo.md`, sección 3.3|El equipo trabaja en Python. El frontend no debe requerir un entorno Node adicional en producción.|
|Monolito modular: una sola unidad desplegable|Sección 3.1|Lo más simple es que Django sirva también el frontend. Así no hay dos servicios que mantener.|
|Autenticación con JWT Bearer (access y refresh)|Sección 3.4 y `openapi\_equipo.yaml` (`POST /auth/tokens`, `POST /auth/tokens/refresh`)|El navegador debe guardar y enviar el token en la cabecera `Authorization`.|
|Contrato spec-first: "el contrato es la frontera entre frontend y backend"|Sección 3.5|El frontend consume la API definida en `openapi\_equipo.yaml`. No debe depender de vistas que consulten la base de datos directamente.|
|RNF-04: interfaz adaptable a móvil|`arquitectura\_equipo.md`, sección 1.2|Hace falta un sistema de rejilla responsiva.|
|RNF-02 y RNF-03: consulta pública con datos reducidos y código de seguimiento|Sección 1.2|La pantalla de seguimiento es pública y no debe mostrar teléfono, correo ni notas.|
|Pendiente 5: tecnología del frontend abierta|Sección 6|Esta actividad resuelve ese pendiente para la propuesta individual.|
|Pendiente 8: vigencia y almacenamiento de tokens abiertos|Sección 6|La propuesta incluye una recomendación concreta (sección 3).|



\---

## 2\. Alternativas evaluadas

Opciones consideradas, con una descripción corta de cada una:

|Opción|Descripción|
|-|-|
|**A. HTML + Bootstrap 5 + Alpine.js servido por Django**|Plantillas HTML con clases de Bootstrap. Alpine.js agrega interactividad mediante atributos en el HTML (`x-data`, `x-show`, `x-for`). Los archivos estáticos los sirve WhiteNoise.|
|**B. HTML + Bootstrap 5 + JavaScript puro**|Igual que A, pero sin Alpine.js. Toda la lógica de la interfaz se escribe a mano con `document.querySelector` y eventos.|
|**C. Vue 3 + Vite, compilado y servido por Django**|Aplicación de componentes con un paso de compilación previo (Vite). El resultado final son archivos estáticos que Django sirve.|
|**D. React + Vite, como SPA en servicio separado**|Aplicación de una sola página (SPA: *Single Page Application*) que vive en su propio dominio y llama a la API.|
|**E. Svelte + Vite, como SPA en servicio separado**|Igual que D, con otro framework. Su comunidad y ecosistema son más pequeños.|
|**F. Next.js (ADR de Emilio)**|Descartada. Requiere TypeScript y Node, y el stack acordado es Python.|
|**G. Angular**|Descartada. Es un framework completo con una curva de aprendizaje alta, desproporcionado para un MVP de dos pantallas públicas y un panel administrativo.|

### Comparación

Calificación cualitativa (Alta = favorable, Baja = desfavorable). Los tiempos son estimaciones mías para un MVP de este alcance, no mediciones.

|Criterio|A. Alpine + Django|B. JS puro|C. Vue + Vite|D. React SPA|E. Svelte SPA|
|-|-|-|-|-|-|
|**Compatibilidad con el backend**|Alta: mismo origen, sin CORS|Alta: mismo origen|Media: necesita compilar antes de desplegar|Baja-media: CORS y dos orígenes|Baja-media: igual que D|
|**Curva de aprendizaje (equipo Python)**|Baja|Baja-media|Media|Media-alta|Media|
|**Costo económico**|Nulo en licencias y sin servicio extra|Nulo en licencias y sin servicio extra|Nulo en licencias; Node solo en la compilación|Nulo en licencias; un servicio adicional en Render (verificar precio vigente)|Igual que D|
|**Tiempo de implementación del MVP**|Bajo (días)|Medio (más código manual)|Medio|Alto (semanas)|Medio-alto|
|**Complejidad de despliegue**|Baja: una unidad|Baja: una unidad|Media: un paso de compilación en Docker|Alta: dos servicios, CORS, variables de entorno|Alta|
|**Riesgo de seguridad del frontend**|Medio: token en navegador, mitigable con CSP|Medio: igual|Medio-alto: muchas dependencias npm|Medio-alto: igual, más superficie|Medio-alto|
|**Encaje con *spec-first***|Alto, si consume la API|Alto, si consume la API|Alto|Alto|Alto|
|**Adecuación a RNF-04 (móvil)**|Alta con Bootstrap|Alta con Bootstrap|Alta|Alta|Alta|

> \*\*Hallazgo.\*\* Ninguna opción es incorrecta para el curso. La diferencia está en cuánto complejidad agrega cada una frente a lo que el MVP necesita. Las opciones D y E resuelven problemas de escala y de interfaces muy dinámicas que el SRS no plantea (el propio ADR de Emilio reconoce que no hay requisitos de escalabilidad).

\---

## 3\. Decisión propuesta

### Stack elegido

|Capa|Elección|Detalle|
|-|-|-|
|**Framework / librería de UI**|Alpine.js 3 sobre HTML de plantillas Django|Alpine solo agrega comportamiento: formularios, filtros de la lista de pedidos y cambio de estado. La estructura la da el HTML.|
|**Herramienta de construcción / servidor de desarrollo**|Ninguna herramienta de compilación. Servidor de desarrollo: `manage.py runserver`. En producción: `collectstatic` y WhiteNoise.|Bootstrap y Alpine se incluyen como archivos estáticos copiados de sus paquetes. No hay paso de compilación.|
|**Enfoque de estilos**|Bootstrap 5.3|Su sistema de rejilla es responsivo por defecto, lo que cubre RNF-04 sin escribir CSS extenso.|
|**Manejo de estado**|Estado local de cada componente Alpine, más un *store* global de Alpine para la sesión|El *store* guarda el usuario autenticado y el token de acceso. No se necesita una librería adicional como Redux o Pinia.|

### Manejo del token (respuesta al pendiente 8)

|Token|Dónde vive|Vigencia|Motivo|
|-|-|-|-|
|**Access token**|Variable en memoria (el *store* de Alpine)|15 minutos|Desaparece al cerrar la pestaña. Es la opción menos expuesta a robo entre sesiones.|
|**Refresh token**|`sessionStorage`|8 horas|Permite recuperar la sesión al recargar la página sin volver a pedir contraseña.|

Esto sigue la propuesta de ADR-001 de Sebastián. Tiene un costo de seguridad que documento en la sección 5.

### Cómo se conecta el frontend con la API

1. Django sirve la página HTML (por ejemplo, `/admin-panel/` o `/seguimiento/`).
2. Alpine llama a `/api/v1/...` con `fetch` y la cabecera `Authorization: Bearer <token>`.
3. Las rutas públicas (`/api/v1/seguimientos/{codigo}`, `/api/v1/horarios`) se consumen sin token. Las administrativas exigen JWT, como ya quedó verificado en `revision\_seguridad.md`.

\---

## 4\. Justificación en términos del proyecto

1. **Mismo origen, sin CORS.** Django sirve el HTML y la API desde el mismo dominio. No hay que configurar CORS (política que controla qué dominios pueden llamar a la API) ni resolver el problema de cookies entre subdominios de `onrender.com` que señaló Emilio.
2. **Una sola unidad desplegable.** Encaja con el monolito acordado y evita un segundo servicio en Render. Esto importa para RNF-01, porque cada servicio adicional puede tener costo y riesgo de suspensión según el plan (pendiente 2).
3. **Curva de aprendizaje baja.** El equipo trabaja en Python. Alpine se aprende en una sesión y no exige entender componentes, *hooks* ni un sistema de módulos de JavaScript.
4. **Tiempo de implementación acorde al MVP.** Son dos vistas públicas o semipúblicas (seguimiento y lista de pedidos) y un panel administrativo. Bootstrap cubre la rejilla, los formularios y las tablas.
5. **Costo cero en licencias y sin infraestructura extra.** Bootstrap y Alpine son de código abierto. No hay paso de compilación en el contenedor Docker del ADR-002.
6. **Respeta el proceso *spec-first*.** El HTML no contiene lógica de datos. Toda información viene del contrato `openapi\_equipo.yaml`. Así se evita la opción C, que el equipo ya rechazó.

### Por qué no las otras

* **B (JS puro):** la misma solución sin Alpine, pero con más código manual para mantener el estado. Es la alternativa de respaldo si el equipo no quiere depender de Alpine.
* **C (Vue compilado):** solución viable si el equipo tiene experiencia con Vue. Agrega un paso de compilación en Docker y más dependencias de npm, que son una superficie de ataque adicional.
* **D y E (SPA separada):** resuelven interfaces muy dinámicas, que el SRS no requiere. Agregan CORS, un segundo servicio y más tiempo de implementación.
* **F y G:** descartadas por el stack acordado y por la complejidad frente al alcance.

\---

## 5\. Riesgos

Riesgos explícitos de la propuesta:

|Riesgo|Severidad|Mitigación|
|-|-|-|
|**Robo del token por un script inyectado (XSS).** Un token guardado en el navegador puede ser leído por JavaScript si hay una vulnerabilidad.|Alta|Política CSP (*Content Security Policy*: lista de orígenes de script permitidos) que bloquea scripts en línea. Escapar todo dato antes de mostrarlo. Nunca usar `innerHTML` con datos del usuario.|
|**Alpine necesita `unsafe-eval` en la CSP normal.** Sin esa excepción, Alpine no funciona bajo una CSP estricta.|Media|Usar la variante de Alpine compatible con CSP (`@alpinejs/csp`). Las expresiones se escriben en archivos JS externos, no en atributos HTML.|
|**Dependencia de CDN.** Cargar Bootstrap desde internet agrega un tercero y complica la CSP.|Media|Copiar los archivos de Bootstrap y Alpine a la carpeta de estáticos y servirlos con WhiteNoise. Ninguna dependencia en línea.|
|**Actualizaciones manuales.** Al copiar los archivos, las versiones no se actualizan solas.|Baja|Registrar la versión usada en `decision\_stack\_frontend.md` y revisarla antes de la entrega final.|
|**Límite de Alpine para interfaces complejas.** Si el panel crece, Alpine puede quedarse corto.|Baja-media|La API es la frontera. Si hace falta migrar a Vue o React, el backend no cambia.|
|**Experiencia del equipo en JavaScript.** No sabemos si el equipo tiene experiencia con frameworks de JavaScript.|Media|Pregunta abierta para el equipo (sección 6).|
|**Token de refresco de 8 horas en `sessionStorage`.** Es una ventana larga si ocurre XSS.|Media|Mantener la CSP. Como alternativa, el equipo puede evaluar una cookie `httpOnly` para el refresco (sección 6).|

\---

## 

