# Propuesta individual de stack de frontend — BCA


**Actividad:** Construye | Generación de Componentes Frontend, Parte 0.1
**Autor:** Emilio (A01703835)
**Qué es esto:** mi propuesta para la discusión del equipo. No es la decisión final; esa se
documenta en `decision_stack_frontend.md` después de que los cuatro propongamos.

---

## 1. La propuesta

| Elemento | Propuesta |
|---|---|
| **Framework / librería de UI** | React 19 |
| **Herramienta de construcción / servidor de desarrollo** | Vite |
| **Enfoque de estilos** | Bootstrap 5 |
| **Manejo de estado** | Estado local con `useState` + Context API solo para la sesión |

---

## 2. Esto cierra un pendiente que ya teníamos abierto

El `arquitectura_equipo.md` que entregamos en S05-S06 dejó registrado como **pendiente 5**:

> *Tecnología del frontend, y si se sirve desde la misma unidad.*

Y en su resumen dice que el acuerdo del equipo cubrió **solo** el framework del backend, la API
y la base de datos. Todo lo demás del ADR-002 de Sebastián quedó sin adoptar, el frontend
incluido.

O sea que esta no es una propuesta nueva sobre terreno vacío: es la respuesta a una pregunta
que nosotros mismos dejamos abierta hace dos semanas.

---

## 3. Por qué React y no Alpine.js

El ADR-002 de Sebastián propuso **HTML5 + Bootstrap 5 + Alpine.js 3**, y descartó React con
este argumento:

> *"npm, JSX, manejo de estado y compilación: no cabe en la restricción de aprendizaje."*

**Ese argumento era correcto cuando lo escribió, y dejó de serlo esta semana.**

En el ejercicio introductorio de frontend (S07-A0), los cuatro integrantes construimos una
aplicación de React con Vite que consume una API REST, con operaciones de crear, leer,
actualizar y eliminar contra un backend real. Ninguno de los cuatro ha escrito una línea de
Alpine.js.

La actividad pide considerar explícitamente dos preguntas, y las dos apuntan al mismo lado:

- *¿Con qué tecnología tiene más experiencia el equipo?* → React. Es la única de frontend que
  hemos usado.
- *¿Hay miembros del equipo que ya usaron la tecnología de la actividad 0 de esta semana?* →
  Los cuatro.

Elegir Alpine hoy significaría descartar la única experiencia de frontend que el equipo tiene,
para aprender desde cero una herramienta que nadie ha tocado, a seis semanas del cierre.

---

## 4. El argumento del ADR que sí hay que responder

La curva de aprendizaje no era la única razón de Sebastián. La otra es estructural, y es
buena:

> *`frontend` | Archivos estáticos: páginas HTML + Bootstrap + Alpine.js del portal público y
> del panel.*

Alpine no necesita compilación, así que Django lo sirve directo desde el mismo contenedor con
WhiteNoise. Eso encaja con el **monolito modular** del ADR-001, que sí es decisión adoptada, y
mantiene corta la cadena de piezas de la que depende RNF-01 (disponibilidad del 99 %).

**React no rompe eso.** `npm run build` de Vite produce HTML, CSS y JavaScript estáticos:
archivos, igual que los de Alpine. WhiteNoise los sirve exactamente igual. Seguimos teniendo
una sola unidad desplegable, un solo servicio en Render y la misma cadena de disponibilidad.

Lo único que se agrega es un **paso de construcción en el despliegue**. Ese costo es real y lo
asumo explícitamente (sección 6), pero es un paso en el build, no un cambio de arquitectura.

Respondido eso, al descarte de React le queda solo el argumento de la curva de aprendizaje,
que es justo el que la actividad de esta semana invirtió.

---

## 5. Qué conservo del ADR-002

No propongo tirar la decisión de Sebastián, sino cambiarle una pieza:

- **Bootstrap 5 se queda.** Su justificación en el ADR sigue intacta: da diseño responsivo
  para RNF-04 sin CSS complejo. No propongo Tailwind, aunque sea más moderno, porque su
  ventaja no se nota en un panel administrativo de siete entidades y sería una cosa más que
  aprender.
- **El análisis de seguridad del JWT se queda completo.** El ADR ya identificó el riesgo de
  guardar el token en el navegador y lo mitigó con token de acceso solo en memoria y de corta
  duración, renovación en `sessionStorage` y política de seguridad de contenido. Ese análisis
  aplica igual en React, sin cambiar una palabra.
- **La frontera sigue siendo el contrato.** El frontend consume `openapi_equipo.yaml`, lo
  mismo que ya decidimos.

---

## 6. Manejo de estado: lo mínimo que funciona

En el ejercicio de A0 todo el estado vivía en `App.jsx` con cuatro `useState`. Nuestro panel
es más grande, pero sigue siendo **un solo administrador** y siete entidades.

Propongo:

- **`useState` local** para los datos de cada pantalla (la lista de pedidos, el formulario
  abierto, el filtro activo).
- **Context API** para una sola cosa: **la sesión** con el token JWT y los datos del
  administrador. Eso sí tiene que ser global, porque lo necesitan todas las pantallas
  protegidas y la lógica de renovación del token.
- **Sin Redux, sin Zustand.** No hay estado compartido complejo que las justifique, y agregar
  una librería de estado a una aplicación de este tamaño es complejidad sin beneficio. Si más
  adelante aparece la necesidad, se agrega entonces.

---

## 7. Costos que asumo

Para que la propuesta sea honesta, lo que se paga por elegir React:

| Costo | Magnitud |
|---|---|
| Paso de construcción (`npm run build`) en el despliegue | Minutos en el build; hay que configurarlo en Render |
| Node y npm como dependencia del proceso de despliegue | Una herramienta más en el pipeline, no en el servidor |
| Árbol de dependencias de npm más grande que el de Alpine | Mayor superficie de mantenimiento |
| El despliegue deja de ser "copiar archivos" | Hay que verificar el build antes de publicar |

Ninguno de estos cambia la arquitectura ni compromete un RNF. Todos son costos de proceso.

---

## 8. Resumen del argumento

1. El pendiente 5 del `arquitectura_equipo.md` pide exactamente esta decisión.
2. El ADR-002 descartó React por la curva de aprendizaje, y la actividad de esta semana
   invirtió ese hecho: hoy el equipo tiene experiencia con React y ninguna con Alpine.
3. El otro argumento del ADR —servir el frontend desde la misma unidad— se conserva con React,
   porque Vite compila a archivos estáticos que WhiteNoise sirve igual.
4. Bootstrap, el análisis de seguridad del JWT y la frontera del contrato se quedan como
   estaban.
5. El manejo de estado se mantiene al mínimo que el problema exige.
