# Propuesta de Stack Frontend – LaundryDesk

**Proyecto:** LaundryDesk  
**Aplicación:** Sistema web para 21st Street Laundry  
**Propuesta individual:** Isai Pérez  

## 1. Stack propuesto

Para el desarrollo del frontend de LaundryDesk se propone utilizar el siguiente stack tecnológico:

| Elemento | Tecnología propuesta |
|---|---|
| Framework / librería de UI | React |
| Herramienta de construcción y servidor de desarrollo | Vite |
| Enfoque de estilos | CSS Modules |
| Manejo de estado | Estado local de React + Context API |
| Comunicación con backend | Fetch API |
| Formato de intercambio de información | JSON |
| Autenticación | JWT mediante `Authorization: Bearer <token>` |

---

## 2. Framework de UI: React

Se propone utilizar **React** para construir la interfaz de usuario debido a su enfoque basado en componentes reutilizables y a su facilidad para desarrollar aplicaciones web que consumen APIs REST.

LaundryDesk requiere diferentes tipos de interfaces, entre ellas:

- Consulta pública de servicios, precios y horarios.
- Seguimiento público de pedidos.
- Inicio de sesión del administrador.
- Registro y administración de pedidos.
- Actualización del estado de los pedidos.
- Administración de servicios y horarios.

El modelo de componentes de React permite separar estas funcionalidades en elementos reutilizables como botones, campos de entrada, tarjetas, barras de navegación y formularios.

Además, React permite mantener separadas las responsabilidades del frontend respecto al backend desarrollado con Django REST Framework.

La arquitectura general sería:

```text
React Frontend
      |
      | HTTP / JSON
      | JWT Bearer Token
      v
Django REST API
      |
      v
PostgreSQL
```

---

## 3. Herramienta de construcción: Vite

Se propone utilizar **Vite** como herramienta de construcción y servidor de desarrollo.

Vite permite crear y ejecutar rápidamente un proyecto React mediante comandos simples como:

```bash
npm install
npm run dev
```

Entre sus ventajas para LaundryDesk se encuentran:

- Configuración inicial sencilla.
- Servidor de desarrollo rápido.
- Integración directa con React.
- Manejo sencillo de variables de entorno.
- Estructura de proyecto fácil de comprender.
- Menor configuración inicial comparada con herramientas como Webpack.

La URL del backend podrá configurarse mediante una variable de entorno:

```env
VITE_API_URL=http://localhost:8000/api/v1
```

De esta forma, la dirección del backend no tendrá que escribirse directamente dentro de los componentes.

---

## 4. Enfoque de estilos: CSS Modules

Se propone utilizar **CSS Modules** para manejar los estilos de los componentes.

Este enfoque permite asociar los estilos directamente con cada componente sin utilizar una librería de estilos externa.

Por ejemplo:

```text
components/
├── Button/
│   ├── Button.jsx
│   └── Button.module.css
│
├── Input/
│   ├── Input.jsx
│   └── Input.module.css
```

Las principales razones para elegir CSS Modules son:

- Evita conflictos entre nombres de clases CSS.
- Mantiene los estilos organizados por componente.
- No requiere aprender una sintaxis adicional.
- Permite utilizar CSS estándar.
- Mantiene bajo el número de dependencias externas.
- Es suficiente para la complejidad visual esperada de LaundryDesk.

El proyecto no requiere inicialmente un sistema de diseño complejo que justifique utilizar herramientas más grandes como Tailwind CSS o Bootstrap.

---

## 5. Manejo de estado: React State + Context API

Para el manejo de estado se propone comenzar utilizando:

- `useState` para estado local.
- `useContext` mediante Context API para información compartida.

El principal estado global requerido inicialmente será la autenticación del administrador, por ejemplo:

```text
AuthContext
├── usuario
├── token
├── login()
└── logout()
```

Esto permitirá que diferentes componentes puedan determinar si el usuario está autenticado.

Por ejemplo, la barra de navegación podrá mostrar diferentes opciones según el estado de autenticación.

```text
Usuario no autenticado
        |
        v
Inicio | Servicios | Seguimiento | Login

Usuario autenticado
        |
        v
Dashboard | Pedidos | Servicios | Horarios | Logout
```

No se propone utilizar inicialmente Redux o Zustand debido a que el tamaño y complejidad actual de LaundryDesk no justifican agregar una herramienta adicional de administración global de estado.

Si el proyecto aumenta considerablemente de complejidad, esta decisión podría reevaluarse.

---

## 6. Comunicación con el backend

El frontend se comunicará con la API REST de LaundryDesk mediante solicitudes HTTP.

La comunicación será centralizada dentro de:

```text
src/services/
```

Por ejemplo:

```text
services/
├── api.js
├── authService.js
├── pedidosService.js
├── serviciosService.js
└── horariosService.js
```

La URL base será obtenida desde:

```env
VITE_API_URL
```

Esto permitirá evitar direcciones del backend escritas directamente en múltiples archivos.

Las rutas protegidas enviarán el JWT utilizando:

```http
Authorization: Bearer <token>
```

---

## 7. Estructura inicial propuesta

La estructura inicial del frontend sería:

```text
frontend/
├── src/
│   ├── assets/
│   ├── components/
│   ├── context/
│   ├── pages/
│   ├── services/
│   ├── styles/
│   ├── App.jsx
│   └── main.jsx
│
├── .env.example
├── package.json
└── vite.config.js
```

Cada carpeta tendrá una responsabilidad definida:

| Carpeta | Responsabilidad |
|---|---|
| `components/` | Componentes reutilizables de interfaz |
| `pages/` | Pantallas completas de la aplicación |
| `services/` | Comunicación con la API REST |
| `context/` | Estado compartido, principalmente autenticación |
| `assets/` | Imágenes, iconos y recursos |
| `styles/` | Estilos globales |

---

## 8. Alternativas consideradas

### Vue 3

Vue ofrece una estructura sencilla y una curva de aprendizaje accesible. También cuenta con buenas herramientas para desarrollar aplicaciones basadas en componentes.

Sin embargo, React se considera una mejor alternativa para esta propuesta debido a su amplio ecosistema, disponibilidad de documentación y facilidad para separar componentes, servicios y manejo de autenticación.

### Angular

Angular proporciona una arquitectura completa y altamente estructurada.

Sin embargo, para el tamaño actual de LaundryDesk podría introducir mayor complejidad de configuración, estructura y aprendizaje de la necesaria.

### JavaScript Vanilla

JavaScript sin framework reduciría el número de dependencias.

Sin embargo, conforme se agreguen páginas, componentes, autenticación y administración de estado, el mantenimiento manual del DOM y de la estructura de la aplicación podría aumentar considerablemente.

### Tailwind CSS

Tailwind CSS permite desarrollar interfaces rápidamente mediante clases utilitarias.

Sin embargo, para la complejidad actual de LaundryDesk, CSS Modules proporciona suficiente organización sin introducir una dependencia adicional ni una sintaxis específica.

### Redux

Redux es una solución robusta para el manejo de estados globales complejos.

En LaundryDesk, el estado global previsto inicialmente es reducido y se concentra principalmente en autenticación, por lo que Context API resulta suficiente y disminuye la complejidad del proyecto.

---

## 9. Justificación de la propuesta

El stack:

**React + Vite + CSS Modules + Context API**

se propone debido a que ofrece un equilibrio entre facilidad de desarrollo, organización, mantenibilidad y capacidad de crecimiento.

LaundryDesk es una aplicación web basada principalmente en operaciones CRUD y comunicación con una API REST existente. La interfaz requiere componentes reutilizables, autenticación mediante JWT y algunas variables de estado compartidas, pero no presenta actualmente una complejidad que justifique herramientas adicionales de administración de estado o frameworks frontend de mayor tamaño.

La propuesta también permite mantener una separación clara entre las diferentes capas:

```text
UI Components
      ↓
Pages
      ↓
Context / State
      ↓
Services
      ↓
REST API
      ↓
Django Backend
```

Esta separación facilita el mantenimiento, las pruebas y la evolución futura del proyecto.

## 10. Propuesta final

Se propone al equipo utilizar:

- **React** como librería principal de interfaz.
- **Vite** como herramienta de construcción y servidor de desarrollo.
- **CSS Modules** para estilos.
- **React State + Context API** para manejo de estado.
- **Fetch API** para comunicación con el backend REST.
- **JWT** para autenticación en las rutas protegidas.

La propuesta busca mantener el frontend de LaundryDesk sencillo, modular y suficientemente escalable para cubrir los requerimientos actuales y las siguientes actividades del curso.