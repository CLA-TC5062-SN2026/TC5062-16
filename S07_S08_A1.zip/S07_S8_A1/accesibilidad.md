# Evaluación básica de accesibilidad

## Objetivo

Se realizó una revisión básica de accesibilidad sobre los componentes principales del frontend de LaundryDesk tomando como referencia las pautas indicadas en la actividad y WCAG 2.1.

La revisión se concentró principalmente en:

- Contraste suficiente entre texto y fondo, considerando como referencia una relación mínima de 4.5:1 para texto normal.
- Uso de atributos de accesibilidad cuando el significado de un elemento no depende únicamente de texto visible.
- Navegación mediante teclado.
- Manejo y visibilidad del foco en elementos interactivos.
- Asociación correcta entre campos de formulario, etiquetas, ayudas y mensajes de error.
- Comportamiento del Navbar en diferentes tamaños de pantalla.

## Componentes evaluados

Se revisaron los siguientes componentes:

- `Button.jsx`
- `InputField.jsx`
- `Card.jsx`
- `Navbar.jsx`

También se revisó su integración dentro de `HomePage.jsx` y los estilos globales de la aplicación.

## Hallazgos y correcciones aplicadas

### 1. Visibilidad del foco en elementos interactivos

**Problema identificado:**  
Aunque los controles podían utilizarse mediante teclado, era importante garantizar que el usuario pudiera identificar claramente qué elemento tenía el foco.

**Corrección aplicada:**  
Se agregó en los estilos globales una regla `:focus-visible` con un contorno azul de alto contraste y separación respecto al elemento:

```css
:focus-visible {
  outline: 3px solid #0a58ca;
  outline-offset: 3px;
}
```

**Resultado:**  
Se verificó manualmente mediante la tecla `Tab` que el campo de entrada y los botones `Consultar pedido` y `Limpiar` presentan un indicador visible cuando reciben el foco.

Esto permite utilizar la interfaz mediante teclado sin depender del mouse.

---

### 2. Asociación entre el campo de entrada y sus mensajes

**Problema identificado:**  
Un mensaje de ayuda o error mostrado únicamente de forma visual podría no ser relacionado correctamente con el campo correspondiente por tecnologías de asistencia.

**Corrección aplicada:**  
En `InputField.jsx` se utilizaron:

- `label` asociado al campo mediante `htmlFor`.
- `aria-describedby` para relacionar el campo con el texto de ayuda o error.
- `aria-invalid` cuando existe un error de validación.
- Mensaje de error visible además del cambio visual del borde.

**Resultado:**  
Cuando se ingresó un código inválido, por ejemplo `123`, el sistema mostró el mensaje:

> Ingresa un código de seguimiento válido.

El error no se comunica únicamente mediante color, ya que también existe un mensaje textual.

---

### 3. Navegación directa al contenido principal

**Problema identificado:**  
Los usuarios que navegan exclusivamente con teclado podrían tener que recorrer repetidamente todos los elementos de navegación antes de llegar al contenido principal.

**Corrección aplicada:**  
Se incorporó un enlace de salto al inicio de la página:

`Saltar al contenido principal`

El enlace permanece oculto normalmente y se vuelve visible cuando recibe el foco mediante teclado.

El contenido principal fue identificado con `id="contenido-principal"` y puede recibir el foco.

**Resultado:**  
Después de recargar la aplicación y presionar `Tab`, el enlace de salto puede utilizarse con `Enter`. Se comprobó que la navegación cambia a `#contenido-principal` y coloca el foco directamente en el contenido principal de la página.

---

### 4. Accesibilidad del Navbar responsive

**Problema identificado:**  
En pantallas pequeñas, un menú desplegable debe comunicar correctamente si se encuentra abierto o cerrado y debe conservar una forma clara de operación.

**Corrección aplicada:**  
El componente `Navbar` utiliza atributos como:

- `aria-label`
- `aria-expanded`
- `aria-controls`

También se implementó un botón de menú hamburguesa para resoluciones pequeñas.

**Resultado:**  
Se comprobó manualmente que al reducir el tamaño de la ventana:

- El Navbar cambia al botón de menú hamburguesa.
- El menú puede abrirse y cerrarse.
- En estado no autenticado muestra `Iniciar sesión`.
- En estado autenticado muestra `Diego · Administrador` y `Cerrar sesión`.

---

### 5. Estado de carga del botón

**Problema identificado:**  
Durante una operación, el cambio de estado de un botón debe ser perceptible y evitar acciones repetidas.

**Corrección aplicada:**  
El componente `Button` utiliza:

- `isLoading` para representar el estado de carga.
- `disabled` durante la operación.
- `aria-busy` para comunicar que existe un proceso en ejecución.
- Un spinner decorativo junto con el texto `Consultando...`.

**Resultado:**  
Al realizar una consulta válida, el botón cambia temporalmente a su estado de carga y posteriormente vuelve a su estado normal.

---

## Revisión de contraste

Se revisaron visualmente las principales combinaciones de texto y fondo utilizadas en la aplicación.

El diseño utiliza principalmente:

- Texto oscuro sobre fondos blancos o gris claro.
- Texto claro sobre el Navbar oscuro.
- Botones con colores estándar de Bootstrap.
- Mensajes de error acompañados por texto y no únicamente por color.

Se tomó como criterio de referencia WCAG 2.1, que establece una relación mínima de contraste de 4.5:1 para texto normal.

No se detectaron durante la revisión combinaciones que dificultaran de forma evidente la lectura. Para una evaluación posterior más exhaustiva se podrían utilizar herramientas automáticas de medición de contraste o auditorías del navegador.

## Pruebas manuales realizadas

Se realizaron las siguientes comprobaciones:

1. Navegación entre los controles mediante `Tab`.
2. Navegación inversa mediante `Shift + Tab`.
3. Verificación del indicador visible de foco.
4. Validación de mensajes de error en el campo de seguimiento.
5. Uso del enlace `Saltar al contenido principal`.
6. Verificación del Navbar en resolución reducida.
7. Apertura y cierre del menú hamburguesa.
8. Cambio entre estado autenticado y no autenticado.
9. Ejecución del estado de carga del botón.

## Resultado

Después de la revisión y de las correcciones aplicadas, los componentes esenciales de LaundryDesk cuentan con una base de accesibilidad adecuada para esta etapa del proyecto.

Las correcciones más importantes fueron mejorar la visibilidad del foco durante la navegación por teclado y relacionar correctamente los campos de formulario con sus mensajes de ayuda y error.

Además, se incorporaron mejoras adicionales como el enlace para saltar al contenido principal, atributos ARIA en elementos interactivos y comportamiento responsive accesible en el Navbar.