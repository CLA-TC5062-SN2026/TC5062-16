# Revisión de seguridad — Partes 1 y 2

## 1. Módulo de autenticación

Se implementaron los endpoints `POST /api/v1/auth/register`, `POST /api/v1/auth/login` y `GET /api/v1/auth/me`.

- Las contraseñas se almacenan únicamente como hash bcrypt.
- `register` nunca devuelve `password` ni `password_hash`.
- El JWT se firma con HS256 usando `JWT_SECRET` desde variables de entorno.
- La expiración se controla con `JWT_EXPIRATION` y el claim `exp`.
- Tokens expirados, alterados o con firma inválida se rechazan con HTTP 401.
- `/auth/me` obtiene el administrador desde el claim `sub` del JWT y exige una cuenta activa.

## 2. Registro

LaundryDesk define un solo administrador en el MVP (RD-06). La entrega anterior utilizaba una fila `admin_temporal` para mantener válidas las llaves foráneas de pedidos e historial. El primer `register` convierte esa fila temporal en la cuenta real conservando su UUID; si no existe la fila temporal, crea la cuenta. Intentos posteriores responden 409.

## 3. Login

El login utiliza correo y contraseña. Una contraseña incorrecta, un correo inexistente o una cuenta inactiva producen la misma respuesta 401 para no revelar información de la cuenta.

## 4. Protección de rutas

En Parte 1 se implementó y validó la infraestructura de JWT sobre `/auth/me`. En Parte 2 se extendió la misma autenticación a los endpoints CRUD administrativos de acuerdo con `openapi_equipo.yaml`; las operaciones públicas conservan acceso anónimo explícito.

## 5. Control por roles

No aplica al MVP actual: RD-06 establece un único administrador y deja fuera del alcance la administración de roles diferenciados.

## 6. Resultados de las pruebas de autenticación

Se realizaron pruebas manuales contra el backend Django conectado a PostgreSQL para verificar el funcionamiento del módulo de autenticación y del middleware JWT.

| Prueba | Resultado esperado | Resultado obtenido | Estado |
|---|---:|---:|---|
| `POST /api/v1/auth/register` con datos válidos | 201 | 201 | Aprobada |
| Respuesta de `/auth/register` no expone `password` ni `password_hash` | Sin datos sensibles | Solo devuelve `id`, `usuario`, `email` y `activo` | Aprobada |
| Contraseña almacenada en la base de datos | Hash bcrypt | Prefijo `$2b$` confirmado en `password_hash` | Aprobada |
| `POST /api/v1/auth/login` con credenciales válidas | 200 + JWT | 200 + token en `access` | Aprobada |
| `POST /api/v1/auth/login` con contraseña incorrecta | 401 | 401 | Aprobada |
| `GET /api/v1/auth/me` sin token | 401 | 401 | Aprobada |
| `GET /api/v1/auth/me` con token alterado | 401 | 401 | Aprobada |
| `GET /api/v1/auth/me` con token válido | 200 | 200 + datos del administrador | Aprobada |
| `GET /api/v1/auth/me` con token expirado | 401 | 401 | Aprobada |

Para verificar la expiración se modificó temporalmente `JWT_EXPIRATION` a 5 segundos, se generó un token nuevo y se realizó una petición después de 7 segundos. El backend respondió HTTP 401, confirmando que el claim `exp` es validado correctamente. Al finalizar la prueba, `JWT_EXPIRATION` se restauró a `3600` segundos.

## 7. Protección de rutas (Parte 2)

La autenticación `JWTAuthentication` se configuró como mecanismo por defecto de Django REST Framework y `IsAuthenticated` como permiso por defecto. Las operaciones públicas o mixtas hacen excepciones explícitas en la vista, siguiendo `openapi_equipo.yaml`.

| Ruta | Método | Acceso | Resultado de verificación |
|---|---|---|---|
| `/api/v1/auth/register` | POST | Público | 201 con registro válido |
| `/api/v1/auth/login` | POST | Público | 200 con credenciales válidas; 401 con credenciales incorrectas |
| `/api/v1/auth/me` | GET | JWT | 200 con JWT válido; 401 sin token, alterado o expirado |
| `/api/v1/servicios` | GET | Público / JWT opcional | 200 sin token para servicios activos |
| `/api/v1/servicios` | POST | JWT | 401 sin token |
| `/api/v1/servicios?incluir_inactivos=true` | GET | JWT | 401 sin token; 200 con JWT válido |
| `/api/v1/horarios` | GET | Público | 200 sin token |
| `/api/v1/pedidos` | GET | JWT | 401 sin token; 401 con token inválido; 200 con JWT válido |
| `/api/v1/pedidos` y operaciones administrativas relacionadas | CRUD | JWT | Protegidas mediante `IsAuthenticated` |
| `/api/v1/seguimientos/{codigo}` | GET | Público | Definida como `AllowAny` según el contrato de la API |

### Identidad administrativa en los CRUD

Los endpoints administrativos ya no usan `ADMIN_ID_TEMPORAL` para registrar quién realizó una operación. Al crear un pedido y su historial inicial, y al cambiar un estado, se toma el UUID de `request.user`, obtenido del JWT validado. Esto conserva la trazabilidad del administrador autenticado.

### Control por rol

No se implementó un control de acceso adicional por roles porque no aplica al MVP actual. El requerimiento RD-06 establece una única cuenta administrativa y deja fuera del alcance la administración de roles diferenciados. Por esta razón, el escenario HTTP 403 por rol incorrecto indicado en la actividad se considera no aplicable.

## 8. Conclusión de la revisión

Las pruebas manuales confirman que el módulo de autenticación cumple con los controles solicitados para la actividad:

- las contraseñas se almacenan mediante bcrypt y nunca se exponen en las respuestas;
- los JWT tienen expiración explícita y los tokens alterados o expirados son rechazados;
- las credenciales incorrectas producen HTTP 401;
- las rutas administrativas requieren autenticación;
- las operaciones expresamente públicas continúan disponibles sin JWT;
- la configuración sensible se obtiene mediante variables de entorno.

Con base en las pruebas realizadas, las Partes 1 y 2 de autenticación y protección de rutas se consideran verificadas.

### Comandos sugeridos

Primero obtén un JWT válido con `POST /auth/login` y copia el valor de `access`. En Bash puedes guardarlo manualmente:

```bash
TOKEN="pega-aqui-el-jwt-valido"
```

Después ejecuta:

```bash
# 1. Sin token -> 401
curl -i http://127.0.0.1:8000/api/v1/pedidos

# 2. Token inválido -> 401
curl -i http://127.0.0.1:8000/api/v1/pedidos \
  -H "Authorization: Bearer TOKEN_MODIFICADO"

# 3. Token válido -> 200
curl -i http://127.0.0.1:8000/api/v1/pedidos \
  -H "Authorization: Bearer $TOKEN"

# 4. Ruta pública -> 200
curl -i http://127.0.0.1:8000/api/v1/horarios

# 5. Solicitar inactivos sin JWT -> 401
curl -i "http://127.0.0.1:8000/api/v1/servicios?incluir_inactivos=true"
```
