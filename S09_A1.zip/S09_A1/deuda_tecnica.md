# Parte 5 – Reflexión sobre deuda técnica

**Proyecto:** LaundryDesk (backend Django/DRF y frontend React/Vite)

---

## 1. ¿Cuánta deuda técnica tiene el proyecto actualmente? ¿Cómo la medirías?

### Cuantificación actual

La deuda se identificó con tres fuentes: la revisión de código del frontend, el análisis estático del backend (Pylint y Mypy) y la evaluación SOLID.

| Fuente | Hallazgos | Lectura real |
|---|---|---|
| Code Review del frontend | 13 hallazgos: 2 altos, 7 medios, 1 bajo-medio y 3 bajos | La refactorización cerró H11, H8 y H7. Quedan **10 abiertos**. H4 puede estar cubierto por H8, pero hay que confirmarlo porque el `request()` final no está en los documentos. |
| Pylint (backend) | 86 mensajes, calificación 8.91/10 | **69 son documentación** (C0114, C0115, C0116). Hay 2 de longitud de línea y 6 de `W0223` que son falsos positivos del contrato de DRF. Quedan **7 hallazgos de diseño reales**: `R0911`, `R0913`/`R0917`, `R1714`, tres `W0707` y un `C0415` en `views.py`. |
| Mypy (backend) | 4 errores en 2 archivos | Los 55 errores iniciales no eran deuda, sino falta de configuración de los plugins de Django y DRF. |
| Pruebas | Frontend: un script manual de 10 checks. Backend: no hay evidencia de pruebas automatizadas en los documentos. | Es la deuda más importante por su efecto sobre todas las demás, porque sin pruebas no se puede refactorizar con seguridad. |

**Estimación cualitativa:** deuda **moderada**. No hay problemas críticos según el análisis estático, pero hay dos riesgos altos en el frontend:

- **H11 (ya corregido):** la pantalla pública mostraba una confirmación inventada. Era un riesgo de confianza para el usuario.
- **H1 (abierto, requiere backend):** cerrar sesión no invalida el JWT, que sigue válido 3600 s. Un token robado da acceso a `/pedidos` durante una hora.

Además, H2 (token en `sessionStorage`) y H5 (IDs sin codificar) aumentan el impacto de un eventual XSS.

No tenemos todavía una cifra en horas porque las estimaciones de esfuerzo no están documentadas.

### Cómo la medirías

Propondría un modelo sencillo, parecido a SQALE, con tres componentes:

1. **Inventario de deuda:** cada hallazgo es un ítem con severidad, archivo, esfuerzo estimado en horas y estado (abierto, en progreso, cerrado).
2. **Índice de deuda:** suma de esfuerzo estimado de los ítems abiertos, separada por severidad. Esto permite decir "tenemos X horas de deuda alta" en lugar de "tenemos muchos problemas".
3. **Métricas automáticas por sprint:**
   - Pylint: puntaje y número de mensajes de tipo `R` y `W`, excluyendo documentación.
   - Mypy: número de errores, que debe ser 0 en código nuevo.
   - Cobertura de pruebas, cuando existan.
   - Complejidad ciclomática (por ejemplo con `radon`) en funciones como `request()` o el manejador de excepciones.
   - Tendencia: deuda creada frente a deuda pagada en cada sprint. Si la deuda nueva supera a la pagada durante varios sprints, el proyecto se está degradando aunque el puntaje de Pylint no cambie.

---

## 2. ¿Qué aspectos de la deuda generamos intencionalmente y cuáles fueron involuntarios?

La clasificación se basa en lo que muestran los documentos. El equipo debe confirmarla con sus decisiones registradas.

### Intencional (decidimos asumirla)

| Decisión | Motivo | Riesgo que asumimos | Estado |
|---|---|---|---|
| Token en `sessionStorage` | Reducir la persistencia del token en el navegador | No protege de XSS. El comentario de `api.js` dice lo contrario (H2). | Abierta. Mitigación propuesta: CSP. |
| Consulta simulada en la pantalla de seguimiento | Tener una demo sin backend | Se quedó en la entrega y mostraba una respuesta falsa (H11). | Cerrada en la refactorización. |
| Verificación con script manual | Avanzar sin montar un framework de pruebas | Solo cubre `api.js` y los servicios. El script se marcó como "no forma parte de la entrega", pero sigue dentro de `src/` (H10). | Abierta. |
| Paginación sin controles | Alcance de la primera entrega | La página parece vacía cuando no hay datos en la primera página (H3). | Abierta. |
| Divergencias con el backend documentadas con comentarios "OJO" | Registrar lo que no coincide con el contrato sin bloquear el avance | Bajo, porque el riesgo está controlado y visible. | Es una práctica correcta de deuda controlada. |

### Involuntario (no lo previmos)

| Problema | Cómo apareció | Evidencia |
|---|---|---|
| `request()` con siete responsabilidades | Se fue agregando funcionalidad a la misma función | H8, SRP |
| CRUD copiado entre servicios | Cada recurso se copió del anterior | H7, DRY |
| Manejador central de excepciones con 8 `return` | Cada nuevo tipo de error se agregó en el mismo lugar | R0911, SRP y OCP |
| `IntegrityError` capturado sin `raise ... from` | Se transformaba la excepción sin conservar la causa | W0707, DIP |
| Tipado débil en `choices` y en la paginación de DRF | No se configuró Mypy con plugins desde el inicio | Mypy, 4 errores |
| Nombres mezclados en español e inglés | No había una regla de nomenclatura | H9 |
| Comentario de `AuthContext` que no coincide con el código | El comentario se escribió antes de un cambio de comportamiento | H6 |
| Sin `package-lock.json`, `.gitignore` ni lint | Falta de configuración del repositorio | H13 |
| Ruta comodín ausente y enlace que recarga la app | Omisiones en la revisión | H12 |

**Lección principal:** la deuda intencional que no se registró terminó comportándose como involuntaria. La consulta simulada era una decisión válida para una demo, pero nadie la inventarió como deuda, y llegó a la entrega. Lo mismo pasó con el script de verificación marcado como temporal. Una decisión de deuda sin dueño ni fecha de pago deja de ser una decisión.

---

## 3. ¿Cómo integraríamos el análisis de calidad y la evaluación SOLID en el flujo Scrum?

Propuesta concreta, pensada para el siguiente sprint del proyecto:

### Definición de terminado (Definition of Done)

Una historia no se considera terminada si:

- Pylint no baja del umbral acordado en el backend y no introduce mensajes nuevos de tipo `R` o `W`.
- Mypy no reporta errores en el código nuevo o modificado.
- `npm run build` y `npm run verify:servicios` (o las pruebas formales que reemplacen al script) pasan.
- La revisión de código incluye una lista corta de SOLID para los cambios que tocan un módulo con hallazgos abiertos.

### Backlog de producto

- Cada hallazgo se registra como ítem de deuda técnica, con su severidad y su esfuerzo estimado.
- Se prioriza con el Product Owner, con una justificación de negocio. Por ejemplo, H1 y H3 tienen impacto directo en el usuario, mientras que H9 y H10 son de mantenimiento.
- Propuesta: reservar una capacidad fija por sprint para deuda, por ejemplo 15%. Scrum no fija un porcentaje; es una decisión del equipo que conviene revisar en la retrospectiva.

### Refinamiento y planificación

- Si una historia toca un módulo con deuda abierta, el ítem de deuda se refina junto con la historia. Por ejemplo, H8 (`request()`) se atiende cuando se modifique el módulo de pedidos, no en un sprint aislado.
- El orden sugerido es: H11 y H1 primero por riesgo, después H3, H4, H2 y H5, luego H7, H8 y H13 porque facilitan el resto, y al final H9, H10 y H12.

### Automatización

- Un pipeline de integración continua ejecuta en cada push: Pylint, Mypy, build y pruebas. Así la calidad deja de depender de revisarla a mano.
- Mypy se configura con los plugins de Django y DRF desde el inicio, para evitar falsos positivos como los 55 errores iniciales.

### Roles

- **Equipo de desarrollo:** responsable de mantener los indicadores y de proponer la deuda nueva que detecte.
- **Product Owner:** decide cuánta deuda se paga frente a funcionalidad nueva, con criterios explícitos.
- **Scrum Master:** protege la capacidad reservada para deuda y ayuda a eliminar bloqueos, como la falta de pruebas.

### Retrospectiva

- Revisar la tendencia del índice de deuda y la relación entre deuda creada y pagada.
- Revisar si las decisiones intencionales de deuda tienen dueño y fecha. Las que no la tengan se registran como ítems del backlog.

### Sobre SOLID en particular

La evaluación SOLID se usa como guía de diseño, no como lista obligatoria. Según el análisis:

- **SRP y OCP** en el manejador de excepciones y **SRP** en `request()`: se atienden cuando el módulo se modifique.
- **DIP** en las vistas que capturan `IntegrityError`: se mueve la traducción a la capa de servicios en la siguiente historia que toque esas vistas.
- **LSP e ISP** en los serializers: no se agregan métodos `create()` o `update()` solo para silenciar al linter. Se documenta que son serializers de entrada.

---

## Conclusión

El proyecto tiene deuda moderada, concentrada en tres áreas: confiabilidad del frontend (manejo de errores y falsas confirmaciones), seguridad de la sesión (que requiere cambios en el backend) y falta de pruebas automatizadas. La mayor parte de los hallazgos de Pylint son de documentación y no representan riesgo funcional.

La mejora más valiosa no es corregir todo, sino registrar la deuda como ítems del backlog, con dueño y estimación, e integrar las métricas en la Definition of Done. Así la deuda intencional se mantiene como decisión consciente y no se convierte en deuda involuntaria.

**Próximos pasos recomendados:**

1. Crear el inventario de deuda con los 13 hallazgos, sus estados y estimaciones.
2. Agregar Pylint y Mypy al pipeline y fijar el umbral en la Definition of Done.
3. Atender H1 coordinando el cambio en el backend, porque es el riesgo alto que sigue abierto.
