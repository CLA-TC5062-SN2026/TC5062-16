# Refactorización guiada

## Objetivo

A partir de los hallazgos obtenidos durante el Code Review se seleccionaron tres problemas relevantes para mejorar la confiabilidad y mantenibilidad del frontend de LaundryDesk.

Los hallazgos seleccionados fueron:

- **H11:** consulta simulada en la pantalla pública.
- **H8:** función `request()` con múltiples responsabilidades.
- **H7:** operaciones CRUD duplicadas entre servicios.

Las tres refactorizaciones fueron implementadas sobre la versión actual del repositorio del equipo y posteriormente se verificó que el frontend continuara compilando correctamente.

---

## Refactorización 1 — Reemplazar la consulta simulada por el servicio real

### Hallazgo

**ID:** H11  
**Archivo:** `frontend/src/pages/HomePage.jsx`

### Antes

La pantalla de seguimiento no realizaba una consulta al backend. Después de una validación local del código utilizaba un temporizador:

```javascript
window.setTimeout(() => {
  setIsLoading(false)
  setMessage(
    `Consulta de demostración realizada para ${codigo.trim()}.`
  )
}, 700)
```

Además, la página mantenía un estado local de autenticación:

```javascript
const [isAuthenticated, setIsAuthenticated] = useState(false)
```

Esto generaba una segunda fuente de verdad distinta a `AuthContext`.

### Problema

La interfaz mostraba una confirmación aunque el código de seguimiento no existiera realmente.

Los errores reales del backend tampoco podían mostrarse al usuario.

El estado de autenticación local también podía quedar inconsistente respecto a la sesión real de la aplicación.

### Después

Se incorporó el servicio de seguimiento existente:

```javascript
import * as seguimientosService from '../services/seguimientosService.js'
```

y la operación se convirtió en una llamada asíncrona real:

```javascript
const handleSubmit = async (event) => {
  event.preventDefault()
  setMessage('')

  const codigoLimpio = codigo.trim()

  if (codigoLimpio.length < 5) {
    setError('Ingresa un código de seguimiento válido.')
    return
  }

  setError('')
  setIsLoading(true)

  try {
    const pedido = await seguimientosService.consultar(codigoLimpio)

    setMessage(
      `Estado de tu pedido: ${pedido.estado_actual}.`
    )
  } catch (error) {
    setError(
      error?.codigo === 'NO_ENCONTRADO'
        ? 'No encontramos un pedido con ese código.'
        : error?.mensaje ||
          'No fue posible consultar el pedido. Intenta de nuevo.'
    )
  } finally {
    setIsLoading(false)
  }
}
```

También se eliminó el estado local de autenticación y se utilizó el contexto compartido:

```javascript
const { administrador, estaAutenticado, cerrarSesion } = useAuth()
```

La acción de iniciar sesión ahora navega a la ruta real:

```javascript
onLogin={() => navigate('/login')}
```

### Justificación técnica

La página deja de generar una respuesta artificial y utiliza la capa de servicios definida por la arquitectura del proyecto.

También se elimina la duplicación del estado de autenticación y se conserva una única fuente de verdad mediante `AuthContext`.

### Verificación

Después de implementar el cambio se ejecutó:

```bash
npm run build
```

El proyecto compiló correctamente, sin errores.

---

## Refactorización 2 — Separar responsabilidades de `request()`

### Hallazgo

**ID:** H8  
**Archivo:** `frontend/src/services/api.js`

### Antes

La función `request()` concentraba distintas responsabilidades:

- construir la URL;
- agregar parámetros;
- generar headers;
- obtener y agregar el JWT;
- configurar el timeout;
- ejecutar `fetch`;
- capturar errores de red;
- leer y convertir el cuerpo de la respuesta;
- manejar errores HTTP;
- limpiar la sesión ante un `401`.

Esto generaba una función con múltiples motivos para cambiar.

### Después

La lógica se separó en funciones especializadas:

```javascript
function construirUrl(path, params) {
  const url = new URL(`${API_URL}${path}`)

  const entradas =
    params instanceof URLSearchParams
      ? params.entries()
      : Object.entries(params ?? {})

  for (const [clave, valor] of entradas) {
    if (valor !== undefined && valor !== null && valor !== '') {
      url.searchParams.append(clave, valor)
    }
  }

  return url
}
```

```javascript
function encabezados() {
  const token = getToken()

  const headers = {
    'Content-Type': 'application/json',
  }

  if (token) {
    headers.Authorization = `Bearer ${token}`
  }

  return headers
}
```

```javascript
function errorDeRed(error, url) {
  console.error(
    `[capa de servicios] Falló la conexión con ${url.toString()}:`,
    error
  )

  return new ApiError({
    mensaje: mensajeDeRed(error),
    codigo: 'ERROR_RED',
    esErrorDeRed: true,
  })
}
```

```javascript
function interpretarCuerpo(texto, url, status) {
  if (!texto) {
    return null
  }

  try {
    return JSON.parse(texto)
  } catch (error) {
    console.error(
      `[capa de servicios] Respuesta no interpretable de ${url.toString()}:`,
      error
    )

    throw new ApiError({
      mensaje: 'El servidor respondió con un formato inesperado.',
      codigo: 'RESPUESTA_INVALIDA',
      status,
    })
  }
}
```

```javascript
function errorDeRespuesta(response, datos, url) {
  if (response.status === 401) {
    clearToken()
  }

  if (response.status >= 500) {
    console.error(
      `[capa de servicios] ${response.status} de ${url.toString()}:`,
      datos
    )
  }

  return new ApiError({
    mensaje:
      datos?.mensaje ||
      'Ocurrió un problema. Intenta de nuevo en unos minutos.',
    codigo: datos?.codigo || 'ERROR_DESCONOCIDO',
    errores: datos?.errores || [],
    status: response.status,
  })
}
```

La función `request()` quedó como coordinadora de dichas responsabilidades.

También se agregó manejo explícito para una configuración inválida de `VITE_API_URL`, convirtiéndola en un `ApiError` con código:

```text
CONFIGURACION_INVALIDA
```

### Justificación técnica

La refactorización aplica el principio de responsabilidad única.

Cada función tiene un propósito concreto, por lo que la construcción de URLs, los headers, la interpretación de respuestas y los distintos tipos de error pueden modificarse con menor impacto sobre el resto del cliente HTTP.

Además, se fortalece la promesa del módulo de exponer un tipo común `ApiError` en lugar de dejar escapar algunas excepciones técnicas.

### Verificación

Antes de realizar la refactorización se ejecutó el script:

```bash
npm run verify:servicios
```

obteniendo:

```text
10/10 checks en verde.
```

Después de implementar la refactorización se ejecutaron nuevamente:

```bash
npm run build
npm run verify:servicios
```

El build finalizó correctamente y se conservaron:

```text
10/10 checks en verde.
```

Por lo tanto, no se detectaron regresiones en los comportamientos cubiertos por la verificación existente.

---

## Refactorización 3 — Eliminar CRUD duplicado mediante una fábrica de recursos

### Hallazgo

**ID:** H7  
**Archivos originales:**

- `frontend/src/services/serviciosService.js`
- `frontend/src/services/horariosService.js`

**Archivo nuevo:**

- `frontend/src/services/recursoService.js`

### Antes

Los servicios de horarios y servicios implementaban por separado operaciones prácticamente idénticas:

- listar;
- obtener por identificador;
- crear;
- actualizar.

Por ejemplo:

```javascript
function obtener(horarioId) {
  return request(`/horarios/${horarioId}`)
}

function crear(datos) {
  return request('/horarios', {
    method: 'POST',
    body: datos,
  })
}

function actualizar(horarioId, cambios) {
  return request(`/horarios/${horarioId}`, {
    method: 'PATCH',
    body: cambios,
  })
}
```

El mismo patrón aparecía en `serviciosService.js`.

### Después

Se creó una fábrica reutilizable en `recursoService.js`:

```javascript
import { request } from './api.js'

function crearRecurso(ruta) {
  const rutaConId = (id) =>
    `${ruta}/${encodeURIComponent(id)}`

  return {
    listar: (params) =>
      request(ruta, { params }),

    obtener: (id) =>
      request(rutaConId(id)),

    crear: (datos) =>
      request(ruta, {
        method: 'POST',
        body: datos,
      }),

    actualizar: (id, cambios) =>
      request(rutaConId(id), {
        method: 'PATCH',
        body: cambios,
      }),
  }
}

export { crearRecurso }
```

`horariosService.js` quedó reducido a:

```javascript
import { crearRecurso } from './recursoService.js'

const horarios = crearRecurso('/horarios')

const {
  listar,
  obtener,
  crear,
  actualizar,
} = horarios

export {
  listar,
  obtener,
  crear,
  actualizar,
}
```

En `serviciosService.js` se reutilizan las operaciones comunes y se conserva únicamente el comportamiento específico del listado de servicios:

```javascript
import { crearRecurso } from './recursoService.js'

const servicios = crearRecurso('/servicios')

function listar({ incluirInactivos = false } = {}) {
  return servicios.listar(
    incluirInactivos
      ? { incluir_inactivos: 'true' }
      : undefined
  )
}

const {
  obtener,
  crear,
  actualizar,
} = servicios

export {
  listar,
  obtener,
  crear,
  actualizar,
}
```

### Justificación técnica

La refactorización elimina lógica CRUD duplicada y centraliza las operaciones comunes de recursos REST.

Esto reduce el número de lugares que deben modificarse cuando cambia una operación común.

También se incorporó:

```javascript
encodeURIComponent(id)
```

en un único punto para construir rutas con identificadores de forma consistente.

Cada servicio conserva únicamente el comportamiento particular de su recurso.

### Verificación

Se verificó individualmente la sintaxis de los tres archivos:

```bash
node --check src/services/recursoService.js
node --check src/services/serviciosService.js
node --check src/services/horariosService.js
```

Los comandos finalizaron sin errores.

Posteriormente se ejecutaron:

```bash
npm run build
npm run verify:servicios
```

El proyecto compiló correctamente y la capa de servicios mantuvo:

```text
10/10 checks en verde.
```

---

## Resultado final

Las tres refactorizaciones seleccionadas fueron implementadas y verificadas.

| Hallazgo | Refactorización | Resultado |
|---|---|---|
| H11 | Sustitución de consulta simulada por `seguimientosService` y uso de `AuthContext` | Implementada |
| H8 | Separación de responsabilidades de `request()` | Implementada |
| H7 | Extracción del CRUD común a `recursoService.js` | Implementada |

Las verificaciones realizadas después de los cambios fueron:

```text
npm run build
→ Correcto

npm run verify:servicios
→ 10/10 checks en verde

node --check recursoService.js
→ Correcto

node --check serviciosService.js
→ Correcto

node --check horariosService.js
→ Correcto
```

Los cambios no modifican la arquitectura general de LaundryDesk. Se enfocan en eliminar respuestas simuladas, reducir responsabilidades excesivas y evitar duplicación de código, manteniendo el comportamiento existente de la aplicación.

