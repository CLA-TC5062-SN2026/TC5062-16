# Definition of Done (DoD) — LaundryDesk

**Proyecto:** LaundryDesk — 21st Street Laundry
---

## 1\. Qué es la DoD en este proyecto y qué no es

La Definition of Done es la lista de condiciones que **cualquier** historia de usuario debe cumplir para considerarse terminada. Es la misma para todas las historias y no cambia de una a otra.

En el proyecto ya existen otros dos tipos de criterio, así que conviene separarlos:

|Concepto|Dónde vive|Alcance|Ejemplo|
|-|-|-|-|
|**Criterios de aceptación**|Cada historia en `backlog\_completo.md` (trazados a `RF-XX-AC-Y`)|Específicos de una historia: qué debe hacer la funcionalidad|HU-04: "un pedido válido se crea con estado `Recibido`"|
|**Criterio de done de la tarea**|Cada tarea en `tareas\_tecnicas.md`|Una tarea técnica de ≤4 h|T04-03: "una solicitud incompleta no genera un pedido"|
|**Definition of Done**|Este documento|Todas las historias: con qué calidad se entrega|"La historia fue revisada por un integrante distinto al autor"|

Una historia puede cumplir todos sus criterios de aceptación y aun así **no** estar terminada si no cumple la DoD (por ejemplo, si funciona pero nadie la revisó o expone datos personales).

\---

## 2\. Propuesta inicial del agente

Se pidió al agente de IA que propusiera una DoD para el proyecto. Su propuesta inicial fue la siguiente:

1. El código fue revisado por al menos un par mediante Pull Request.
2. Existen pruebas unitarias con una cobertura mínima del 80 %.
3. El pipeline de integración continua (CI) está en verde: compilación, pruebas y *linter* automáticos en cada Pull Request.
4. La funcionalidad está desplegada en un ambiente de *staging* (servidor de pruebas que imita producción).
5. Existen pruebas de integración y *end-to-end* (E2E: pruebas que recorren el flujo completo como lo haría el usuario) automatizadas.
6. El análisis estático (*linter*: herramienta que revisa el estilo y errores comunes del código) no reporta advertencias.
7. Se ejecutó un escaneo de seguridad del código y de las dependencias.
8. Se ejecutaron pruebas de rendimiento.
9. La documentación de la API está actualizada en formato OpenAPI.
10. Todos los criterios de aceptación de la historia se cumplen.
11. El Product Owner aprobó la historia.

\---

## 3\. Evaluación y ajustes

La propuesta del agente corresponde a la DoD de un equipo profesional con infraestructura ya montada. Se revisó cada punto contra tres preguntas: **¿se puede verificar hoy con lo que tenemos?**, **¿cabe en la capacidad del sprint?** y **¿protege algo que el SRS exige?**

|#|Propuesta del agente|Decisión|Justificación|
|-|-|-|-|
|1|Revisión por pares en Pull Request|**Se conserva**|No requiere infraestructura y es el principal control de calidad que podemos aplicar sin CI.|
|2|Cobertura de pruebas unitarias ≥ 80 %|**Se difiere**|No hay framework de pruebas configurado. Además, una meta de cobertura empuja a escribir pruebas superficiales para alcanzar el porcentaje. Se sustituye por evidencia de prueba de cada criterio de aceptación (punto P1 de la DoD final).|
|3|Pipeline de CI en verde|**Se elimina por ahora**|El contexto del curso indica explícitamente que todavía no hay CI/CD. Se sustituye por "el proyecto se ejecuta desde una copia limpia del repositorio" (R3), que es la verificación manual equivalente.|
|4|Despliegue en *staging*|**Se difiere**|No existe ambiente de despliegue. RNF-01 (disponibilidad del 99 %) solo podrá verificarse cuando exista uno.|
|5|Pruebas de integración y E2E automatizadas|**Se sustituye**|Se reemplaza por la demostración del flujo completo al cierre del sprint (Nivel incremento).|
|6|*Linter* sin advertencias|**Se ajusta**|Sin *linter* configurado el punto no es verificable. Se exige en su lugar que no haya errores en la consola del navegador ni del servidor durante el flujo probado (R4).|
|7|Escaneo de seguridad|**Se sustituye**|Un escaneo genérico no garantiza lo que el SRS sí pide. Se reemplaza por verificaciones concretas de RNF-02 y RNF-05 (N1, N2) y por la prohibición de credenciales en el repositorio (R5).|
|8|Pruebas de rendimiento|**Se elimina**|El SRS no define ningún requerimiento de rendimiento, así que no existe un valor contra el cual medir.|
|9|Documentación OpenAPI|**Se ajusta**|Exigir OpenAPI en el Sprint 1 añade una herramienta más. Se pide documentar en el README los endpoints o modelos nuevos o modificados (D2), en el formato que el equipo ya use.|
|10|Criterios de aceptación cumplidos|**Se conserva y se refuerza**|Se exige además referenciar el ID `RF-XX-AC-Y` en la evidencia, para mantener la trazabilidad con el SRS.|
|11|Aprobación del Product Owner|**Se ajusta**|El equipo no tiene un Product Owner formal separado. La aceptación se da mediante demostración ante el equipo, que valida contra los criterios de aceptación (A1).|

### Puntos que el agente no propuso y se agregaron

La propuesta del agente era genérica: no incluía ningún requerimiento propio de LaundryDesk. Se agregaron los requerimientos no funcionales del SRS que aplican a **todas** las historias, porque son exactamente el tipo de condición que una DoD debe cubrir:

* **RNF-05 — Control de acceso:** toda operación administrativa nueva debe rechazar solicitudes sin sesión.
* **RNF-02 — Protección de datos personales:** ninguna respuesta pública expone teléfono, correo, instrucciones ni notas.
* **RNF-04 — Usabilidad móvil:** las pantallas nuevas funcionan en celular sin desplazamiento horizontal, con mensajes que entienda un administrador no técnico.
* **RNF-06 — Persistencia:** los datos sobreviven a un reinicio del servidor.
* **Sincronización con el SRS:** si durante la implementación cambia una regla (como el caso pendiente de RD-03 sobre peso y precio), el cambio debe reflejarse en `SRS\_equipo.md` antes de cerrar la historia.
* **Estado en GitHub Projects:** el tablero debe reflejar la realidad, para que la velocidad del sprint se calcule con datos correctos.

\---

## 4\. Definition of Done final

### 4.1 Nivel historia de usuario

Una historia de usuario se considera **terminada** únicamente cuando cumple **todos** los puntos siguientes. Si falta uno, la historia no está terminada y no suma Story Points a la velocidad del sprint.

**Funcionalidad y pruebas**

* **P1.** Cada criterio de aceptación de la historia fue probado y su resultado quedó registrado como comentario en el Issue, indicando el ID (`RF-XX-AC-Y` o número de criterio de la HU), los pasos seguidos y el resultado obtenido.
* **P2.** Se probaron tanto los escenarios exitosos como los de error descritos en los criterios de aceptación (datos faltantes, credenciales incorrectas, valores inválidos, etc.).
* **P3.** Todas las tareas técnicas de la historia en `tareas\_tecnicas.md` cumplen su criterio de done, incluida la tarea de QA.

**Código y repositorio**

* **R1.** El código está integrado en la rama principal del repositorio `TC5062-\[Num\_equipo]` mediante un Pull Request vinculado al Issue de la historia.
* **R2.** El Pull Request fue revisado y aprobado por al menos un integrante distinto a su autor.
* **R3.** El proyecto se instala y ejecuta desde una copia limpia del repositorio siguiendo las instrucciones del README, sin pasos adicionales no documentados.
* **R4.** Durante el flujo probado no aparecen errores en la consola del navegador ni en la del servidor.
* **R5.** El repositorio no contiene contraseñas, claves de servicios ni datos reales de clientes. La configuración sensible se maneja mediante variables de entorno excluidas del control de versiones.

**Requerimientos no funcionales transversales**

* **N1. Control de acceso (RNF-05):** toda operación administrativa creada o modificada por la historia rechaza una solicitud sin sesión autenticada. Se verifica intentando la operación sin iniciar sesión.
* **N2. Privacidad (RNF-02):** ninguna respuesta o pantalla accesible sin autenticación expone teléfono, correo, instrucciones internas ni notas. Las contraseñas no se almacenan en texto plano.
* **N3. Uso móvil (RNF-04):** las pantallas nuevas se pueden usar en un ancho de 360 px (simulado con las herramientas de desarrollador del navegador) sin desplazamiento horizontal.
* **N4. Mensajes comprensibles (RNF-04):** los errores que ve el administrador están en español, indican qué corregir y no muestran detalles técnicos internos.
* **N5. Persistencia (RNF-06):** los datos creados o modificados por la historia siguen disponibles después de reiniciar el servidor y volver a abrir el navegador.

**Documentación y trazabilidad**

* **D1.** El Issue está cerrado, sus sub-issues completadas y la tarjeta se encuentra en la columna *Done* del tablero de GitHub Projects.
* **D2.** Si la historia agregó o modificó endpoints, modelos de datos o pasos de instalación, el README los documenta.
* **D3.** Si la implementación cambió o aclaró una regla del SRS, `SRS\_equipo.md` fue actualizado o el cambio quedó registrado como pendiente en el Issue. Ningún comportamiento difiere del SRS sin quedar documentado.

**Aceptación**

* **A1.** La historia se demostró funcionando al equipo y este confirmó que cumple sus criterios de aceptación.

### 4.2 Nivel incremento (cierre del sprint)

Al terminar cada sprint, además de lo anterior:

* **I1.** Solo se consideran entregadas las historias que cumplen la DoD completa. Las historias incompletas regresan al Product Backlog para reestimarse y no cuentan para la velocidad.
* **I2.** La rama principal se ejecuta sin errores y el flujo del Sprint Goal se demuestra de principio a fin.

  * **Sprint 1:** iniciar sesión → registrar un pedido → capturar peso, precio e instrucciones → ver el código de seguimiento generado → reiniciar el servidor y confirmar que el pedido sigue ahí.
* **I3.** Se registra la velocidad real del sprint (Story Points terminados conforme a la DoD) para usarla en la planeación del siguiente.

\---

## 5\. Aplicación de los requisitos transversales en el Sprint 1

No todos los requisitos no funcionales tienen algo que verificar en cada historia. Esta tabla indica qué se revisa en cada historia del Sprint 1 para que el punto no se marque sin probarlo.

|Requisito|HU-03 Login|HU-04 Registro|HU-05 Datos operativos|HU-06 Código|
|-|-|-|-|-|
|N1 — Acceso (RNF-05)|Rutas protegidas rechazan sin sesión|Crear pedido exige sesión|Editar pedido exige sesión|— (forma parte de HU-04)|
|N2 — Privacidad (RNF-02)|Contraseña con hash, no en texto plano|Respuestas no accesibles sin sesión|Instrucciones no accesibles sin sesión|El código no revela datos del cliente|
|N3 — Móvil (RNF-04)|Pantalla de login|Formulario de registro|Edición de peso/precio|Confirmación con código|
|N4 — Mensajes (RNF-04)|Credenciales incorrectas|Campos obligatorios faltantes|Peso o precio inválido|—|
|N5 — Persistencia (RNF-06)|Sesión/usuario administrador|Pedido tras reinicio|Valores tras reinicio|Código tras reinicio|

\---

## 

