# Sprint 1 — Descomposición de historias en tareas técnicas
## Proyecto: LaundryDesk

## Objetivo

Descomponer las historias seleccionadas para el Sprint 1 en tareas técnicas concretas, pequeñas y verificables.

Las historias incluidas son:

- HU-03 — Iniciar sesión como administrador.
- HU-04 — Registrar un pedido de wash & fold.
- HU-05 — Completar los datos operativos del pedido.
- HU-06 — Generar un código único de seguimiento.

Cada tarea fue definida para poder completarse idealmente en un máximo de 4 horas y cuenta con un responsable, rol y criterio de finalización.

---

# HU-03 — Iniciar sesión como administrador

**Historia de usuario:**  
Como administrador, quiero autenticarme antes de acceder al área administrativa, para proteger las funciones internas y los datos de los clientes.

**Story Points:** 3

## Tareas técnicas

### T03-01 — Definir modelo y mecanismo de autenticación

**Responsable:** Diego — Backend Dev  
**Estimación:** 2 h

**Descripción:**  
Definir la estructura necesaria para representar al administrador y el mecanismo que utilizará el sistema para comprobar sus credenciales y mantener una sesión autenticada.

**Criterio de Done:**

- Existe una definición clara del usuario administrador.
- Se ha definido cómo se almacenarán y validarán las credenciales.
- Se ha definido cómo se identificará una sesión autenticada.
- La solución no almacena contraseñas en texto plano.

---

### T03-02 — Implementar autenticación en backend

**Responsable:** Diego — Backend Dev  
**Estimación:** 3 h

**Descripción:**  
Implementar la operación de inicio de sesión para validar las credenciales proporcionadas por el administrador.

**Criterio de Done:**

- Credenciales válidas permiten iniciar una sesión.
- Credenciales inválidas producen una respuesta de acceso rechazado.
- La operación puede probarse desde el backend de manera independiente.

---

### T03-03 — Proteger operaciones administrativas

**Responsable:** Diego — Backend Dev  
**Estimación:** 3 h

**Descripción:**  
Agregar el control necesario para impedir que usuarios no autenticados ejecuten funciones administrativas.

**Criterio de Done:**

- Una solicitud autenticada puede acceder a una operación protegida.
- Una solicitud no autenticada es rechazada.
- El comportamiento es consistente con los criterios de aceptación de HU-03.

---

### T03-04 — Crear interfaz de inicio de sesión

**Responsable:** Diego — Frontend Dev  
**Estimación:** 3 h

**Descripción:**  
Construir la pantalla de acceso para que el administrador pueda introducir sus credenciales.

**Criterio de Done:**

- La interfaz contiene los campos necesarios para autenticarse.
- Puede enviar las credenciales al backend.
- Muestra un mensaje comprensible cuando las credenciales son incorrectas.
- Una autenticación correcta permite continuar al área administrativa.

---

### T03-05 — Probar flujo de autenticación

**Responsable:** Diego — QA  
**Estimación:** 2 h

**Descripción:**  
Validar los escenarios principales de autenticación.

**Criterio de Done:**

Se han comprobado al menos los siguientes escenarios:

1. Credenciales válidas.
2. Credenciales incorrectas.
3. Intento de acceso a una función administrativa sin autenticación.

---

# HU-04 — Registrar un pedido de wash & fold

**Historia de usuario:**  
Como administrador, quiero registrar un nuevo pedido de wash & fold con los datos básicos del cliente, para iniciar su trazabilidad desde el momento en que la ropa es recibida.

**Story Points:** 5

## Tareas técnicas

### T04-01 — Definir modelo de datos del pedido

**Responsable:** Diego — Backend / Database Dev  
**Estimación:** 3 h

**Descripción:**  
Definir la estructura persistente necesaria para almacenar un pedido.

Como mínimo debe contemplar:

- Nombre del cliente.
- Número telefónico.
- Servicio.
- Fecha de recepción.
- Estado.
- Correo electrónico opcional.

**Criterio de Done:**

- El modelo representa todos los campos obligatorios de HU-04.
- Permite correo electrónico opcional.
- Permite almacenar el estado inicial del pedido.
- El modelo puede persistirse en la base de datos.

---

### T04-02 — Crear operación backend para registrar pedidos

**Responsable:** Diego — Backend Dev  
**Estimación:** 3 h

**Descripción:**  
Implementar la operación que recibe los datos del pedido y crea un nuevo registro.

**Criterio de Done:**

- Un administrador autenticado puede enviar los datos requeridos.
- Una solicitud válida crea un pedido.
- El pedido se almacena de forma persistente.
- El pedido inicia con estado `Recibido`.

---

### T04-03 — Implementar validación de campos obligatorios

**Responsable:** Diego — Backend Dev  
**Estimación:** 2 h

**Descripción:**  
Validar que un pedido no pueda registrarse si falta información obligatoria.

**Criterio de Done:**

- Nombre, teléfono, servicio y fecha de recepción son validados.
- Una solicitud incompleta no genera un pedido.
- El sistema identifica los campos requeridos que faltan.

---

### T04-04 — Crear formulario de registro de pedidos

**Responsable:** Diego — Frontend Dev  
**Estimación:** 4 h

**Descripción:**  
Construir la interfaz administrativa que permita capturar los datos necesarios para crear un pedido.

**Criterio de Done:**

- El formulario incluye todos los campos requeridos.
- El correo electrónico puede dejarse vacío.
- El formulario envía correctamente la información al backend.
- El usuario recibe confirmación cuando el pedido se registra correctamente.

---

### T04-05 — Probar registro y persistencia del pedido

**Responsable:** Diego — QA  
**Estimación:** 2 h

**Descripción:**  
Verificar los escenarios de registro exitoso e inválido.

**Criterio de Done:**

- Un pedido válido se almacena.
- El estado inicial es `Recibido`.
- Los datos permanecen disponibles después de cerrar y volver a acceder al sistema.
- Una solicitud con datos obligatorios faltantes es rechazada.

---

# HU-05 — Completar datos operativos del pedido

**Historia de usuario:**  
Como administrador, quiero registrar o actualizar el peso, precio final e instrucciones especiales de un pedido, para mantener completa y actualizada la información necesaria para su operación.

**Story Points:** 5

## Tareas técnicas

### T05-01 — Extender el modelo de pedido con datos operativos

**Responsable:** Diego — Backend / Database Dev  
**Estimación:** 2 h

**Descripción:**  
Incorporar al modelo del pedido los campos necesarios para peso, precio final e instrucciones especiales.

**Criterio de Done:**

- El pedido puede almacenar peso.
- El pedido puede almacenar precio final.
- El pedido puede almacenar instrucciones especiales.
- Las instrucciones especiales pueden ser opcionales.

---

### T05-02 — Implementar operación backend de actualización

**Responsable:** Diego — Backend Dev  
**Estimación:** 3 h

**Descripción:**  
Implementar una operación que permita modificar los datos operativos de un pedido existente.

**Criterio de Done:**

- Puede actualizarse peso.
- Puede actualizarse precio final.
- Pueden agregarse o modificarse instrucciones.
- Los cambios persisten.
- Actualizar estos datos no modifica automáticamente el estado del pedido.

---

### T05-03 — Validar peso y precio

**Responsable:** Diego — Backend Dev  
**Estimación:** 2 h

**Descripción:**  
Implementar validaciones para evitar valores inválidos en los datos operativos.

**Criterio de Done:**

- El sistema rechaza valores no válidos para peso.
- El sistema rechaza valores no válidos para precio.
- Los mensajes de validación permiten identificar el problema.

---

### T05-04 — Crear interfaz para completar datos operativos

**Responsable:** Diego — Frontend Dev  
**Estimación:** 3 h

**Descripción:**  
Crear dentro del detalle administrativo del pedido los controles para capturar o modificar peso, precio e instrucciones.

**Criterio de Done:**

- Se muestran los valores actuales del pedido.
- El administrador puede editarlos.
- Los cambios pueden guardarse.
- Después de guardar, la interfaz refleja los valores persistidos.

---

### T05-05 — Probar actualización de datos operativos

**Responsable:** Diego — QA  
**Estimación:** 2 h

**Descripción:**  
Validar el registro y modificación de peso, precio e instrucciones.

**Criterio de Done:**

- Los valores válidos se almacenan.
- Una modificación reemplaza correctamente el valor anterior.
- Las instrucciones permanecen asociadas al pedido.
- El estado del pedido no cambia debido a esta operación.

---

# HU-06 — Generar un código único de seguimiento

**Historia de usuario:**  
Como administrador, quiero que cada pedido registrado reciba automáticamente un código único de seguimiento, para poder entregarlo al cliente y habilitar la consulta posterior del pedido.

**Story Points:** 3

## Tareas técnicas

### T06-01 — Definir estrategia de generación de códigos

**Responsable:** Diego — Backend Dev  
**Estimación:** 2 h

**Descripción:**  
Definir el mecanismo para generar códigos de seguimiento únicos y no basados en una secuencia numérica simple predecible.

**Criterio de Done:**

- Existe una estrategia documentada para generar el código.
- El código no depende de una secuencia visible como `1`, `2`, `3`, etc.
- Puede comprobarse su unicidad antes de almacenar el pedido.

---

### T06-02 — Implementar generación automática del código

**Responsable:** Diego — Backend Dev  
**Estimación:** 2 h

**Descripción:**  
Integrar la generación del código con el proceso de creación del pedido.

**Criterio de Done:**

- Cada pedido nuevo recibe automáticamente un código.
- El código queda asociado al pedido persistido.
- No es necesario que el administrador capture el código manualmente.

---

### T06-03 — Implementar control de unicidad

**Responsable:** Diego — Backend / Database Dev  
**Estimación:** 2 h

**Descripción:**  
Evitar que dos pedidos puedan almacenarse con el mismo código de seguimiento.

**Criterio de Done:**

- La persistencia del sistema impide códigos duplicados.
- Si se produce una colisión durante la generación, el sistema genera un nuevo código.
- Dos pedidos registrados de manera independiente terminan con códigos diferentes.

---

### T06-04 — Mostrar el código después del registro

**Responsable:** Diego — Frontend Dev  
**Estimación:** 2 h

**Descripción:**  
Mostrar al administrador el código generado cuando se crea correctamente un pedido.

**Criterio de Done:**

- El código aparece en la confirmación o detalle del pedido.
- El administrador puede identificar claramente qué código corresponde al pedido recién creado.
- El código mostrado coincide con el almacenado en el backend.

---

### T06-05 — Probar unicidad y generación automática

**Responsable:** Diego — QA  
**Estimación:** 2 h

**Descripción:**  
Crear varios pedidos para comprobar el comportamiento de los códigos.

**Criterio de Done:**

- Todos los pedidos creados obtienen un código.
- No existen códigos duplicados entre los pedidos probados.
- Los códigos no siguen una secuencia numérica incremental simple.
- El código persistido corresponde al mostrado al administrador.

---

# Revisión crítica de la descomposición

Después de generar la primera propuesta de tareas se revisó cada historia buscando tareas faltantes, tareas demasiado amplias y dependencias que pudieran impedir su ejecución durante el Sprint.

## Ajustes realizados

1. Se separaron las tareas de backend y frontend para evitar actividades demasiado grandes.

2. Se agregaron tareas de QA independientes para cada historia, evitando considerar una historia terminada únicamente porque su código fue implementado.

3. En HU-03 se separó la implementación del inicio de sesión de la protección de operaciones administrativas, ya que validar credenciales y controlar autorización son responsabilidades diferentes.

4. En HU-04 se separó la definición del modelo de datos, la creación de la operación backend, las validaciones y la interfaz de captura.

5. En HU-05 se separó la actualización del modelo de la lógica para modificar los datos, permitiendo probar cada responsabilidad de manera independiente.

6. En HU-06 se separó la generación del código del control de unicidad, debido a que generar un identificador y garantizar que no exista otro igual son responsabilidades relacionadas pero diferentes.

7. Ninguna tarea planificada supera las 4 horas estimadas.

8. Se definió un criterio de Done específico para cada tarea con resultados observables.

9. Las tareas fueron asignadas mediante roles técnicos aunque sean realizadas por el mismo integrante, permitiendo distinguir responsabilidades de backend, frontend, base de datos y QA.

10. Las tareas de HU-04 y HU-05 deberán revisarse después de que el equipo resuelva la diferencia detectada respecto al momento en que se capturan el peso y el precio. El stakeholder indicó que estos datos se determinan al recibir la ropa, mientras el SRS consolidado todavía permite completarlos posteriormente.

---

# Resumen de tareas del Sprint 1

| Historia | Backend / DB | Frontend | QA | Total tareas |
|---|---:|---:|---:|---:|
| HU-03 | 3 | 1 | 1 | 5 |
| HU-04 | 3 | 1 | 1 | 5 |
| HU-05 | 3 | 1 | 1 | 5 |
| HU-06 | 3 | 1 | 1 | 5 |
| **Total** | **12** | **4** | **4** | **20 tareas** |

Las 20 tareas representan la descomposición técnica inicial del Sprint Backlog y podrán ajustarse durante el Sprint si el equipo identifica nueva información técnica, manteniendo el Sprint Goal como referencia principal.