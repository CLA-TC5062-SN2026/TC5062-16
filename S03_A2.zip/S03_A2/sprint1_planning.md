# Sprint 1 Planning — LaundryDesk

## 1. Propuesta inicial del Sprint Goal

Para el Sprint 1 se propone construir la base operativa del proceso de recepción de pedidos de wash & fold en LaundryDesk.

### Sprint Goal

> **Al finalizar el Sprint 1, el administrador de LaundryDesk podrá autenticarse y registrar de forma persistente un pedido de wash & fold con la información necesaria para su operación, obteniendo automáticamente un código único de seguimiento que permita iniciar la trazabilidad del pedido.**

El objetivo se concentra en crear el primer flujo operativo funcional del sistema: permitir que el dueño ingrese de forma segura y registre correctamente un pedido recibido en la lavandería.

---

## 2. Historias seleccionadas para el Sprint

Para alcanzar el Sprint Goal se seleccionaron las siguientes historias del Product Backlog:

| Historia | Descripción | Story Points | Prioridad |
|---|---|---:|---|
| HU-03 | Iniciar sesión como administrador | 3 | Alta |
| HU-04 | Registrar un pedido de wash & fold | 5 | Alta |
| HU-05 | Completar los datos operativos del pedido | 5 | Alta |
| HU-06 | Generar un código único de seguimiento | 3 | Alta |
| **Total** |  | **16 SP** | |

### Justificación de la selección

**HU-03 — Iniciar sesión como administrador**

Es una historia habilitadora para el resto de las operaciones internas de LaundryDesk. El registro y modificación de información de pedidos requieren que el administrador se encuentre autenticado, por lo que esta funcionalidad debe estar disponible antes de implementar el flujo administrativo.

**HU-04 — Registrar un pedido de wash & fold**

Representa una de las funciones centrales del proyecto. Permite convertir el proceso actual de recepción de ropa en un registro digital y establecer el punto de inicio de la trazabilidad del pedido.

**HU-05 — Completar los datos operativos del pedido**

Permite registrar información necesaria para operar el servicio, como peso, precio final e instrucciones especiales. Esta información complementa el registro inicial y proporciona los datos necesarios para continuar el procesamiento del pedido.

**HU-06 — Generar un código único de seguimiento**

Permite identificar de manera única cada pedido y establece la base para las funcionalidades posteriores de seguimiento. El código será utilizado en Sprints posteriores para permitir que el cliente consulte el estado de su pedido.

Las cuatro historias pertenecen al núcleo de recepción y trazabilidad del servicio y presentan dependencias naturales entre ellas. Al completarlas, el Sprint entregará un incremento funcional coherente en lugar de un conjunto de funcionalidades aisladas.

---

## 3. Capacidad estimada del equipo

La capacidad propuesta para el Sprint 1 es de:

> **16 Story Points**

El Sprint tendrá una duración de dos semanas, con una disponibilidad aproximada de 8 a 9 horas de trabajo por semana.

Al tratarse del primer Sprint del proyecto, el equipo todavía no cuenta con una velocidad histórica que permita conocer con precisión cuántos Story Points puede completar durante un Sprint.

Por esta razón, se decidió utilizar una estimación conservadora de 16 Story Points. Esta capacidad también considera que durante el primer Sprint existirán actividades iniciales de configuración del entorno, integración del trabajo de los integrantes, resolución de dependencias técnicas y coordinación del equipo.

Los Story Points se utilizan como una medida relativa de esfuerzo, complejidad e incertidumbre y no como una conversión directa a horas de trabajo.

---

## 4. Evaluación crítica de la propuesta

Después de revisar la propuesta inicial se evaluaron tres aspectos: realismo, enfoque en valor y coherencia del Sprint Goal.

### Realismo

La propuesta se considera realista para un primer Sprint.

Las cuatro historias seleccionadas suman 16 Story Points y se encuentran entre las funcionalidades de mayor prioridad del Product Backlog. No se recomienda agregar más historias al compromiso inicial debido a que el equipo todavía no dispone de datos históricos de velocidad.

Agregar, por ejemplo, HU-07 — Consultar la lista de pedidos — aumentaría el compromiso a 21 Story Points y ampliaría el alcance del Sprint hacia la gestión operativa de pedidos. Aunque esta historia aporta valor, no es indispensable para cumplir el objetivo específico definido para este Sprint.

Por lo tanto, HU-07 se mantiene en el Product Backlog como una de las siguientes candidatas para el Sprint posterior.

### Enfoque en valor

Las historias seleccionadas entregan valor porque permiten construir el primer flujo operativo de LaundryDesk.

Al finalizar el Sprint, el administrador no tendrá únicamente componentes técnicos aislados: podrá ingresar al sistema, registrar un pedido real, conservar su información y obtener un identificador único para comenzar su seguimiento.

Esta selección también es consistente con la información obtenida del stakeholder, quien señaló que el registro de pedidos y la conservación de su información son funciones esenciales para comenzar a utilizar LaundryDesk.

### Coherencia

Las historias presentan una secuencia lógica:

**Autenticación → Registro del pedido → Información operativa → Código de seguimiento**

Esta relación permite que todas las historias contribuyan directamente al Sprint Goal.

No se incluyeron funcionalidades como consulta pública, filtrado de pedidos, actualización de estados, notificaciones o configuración del negocio, ya que ampliarían el objetivo y pueden desarrollarse de manera incremental en Sprints posteriores.

---

## 5. Ajuste final de la propuesta

Después de la evaluación crítica no se consideró necesario modificar el conjunto de historias seleccionado.

Sin embargo, se identificó un punto que deberá resolverse durante el refinamiento previo al desarrollo de HU-04 y HU-05: el stakeholder indicó que el peso y el precio normalmente se determinan al momento de recibir la ropa, mientras que el SRS consolidado permite completar estos datos posteriormente.

Esta diferencia deberá ser validada por el equipo para determinar si peso y precio deben formar parte obligatoria del registro inicial o mantenerse como información que puede completarse después. La decisión no modifica por ahora la selección del Sprint, ya que ambas historias se encuentran incluidas.

---

# Sprint Goal acordado

> **Al finalizar el Sprint 1, el administrador de LaundryDesk podrá autenticarse y registrar de forma persistente un pedido de wash & fold con la información necesaria para su operación, obteniendo automáticamente un código único de seguimiento que permita iniciar la trazabilidad del pedido.**

## Sprint Backlog seleccionado

| Orden | Historia | Story Points |
|---:|---|---:|
| 1 | HU-03 — Iniciar sesión como administrador | 3 |
| 2 | HU-04 — Registrar un pedido de wash & fold | 5 |
| 3 | HU-05 — Completar los datos operativos del pedido | 5 |
| 4 | HU-06 — Generar un código único de seguimiento | 3 |
| **Total comprometido** | | **16 SP** |

El Sprint Goal y las historias seleccionadas se consideran concretos, coherentes y alcanzables para un Sprint inicial de dos semanas. La capacidad deberá revisarse al finalizar el Sprint utilizando la velocidad realmente obtenida por el equipo.