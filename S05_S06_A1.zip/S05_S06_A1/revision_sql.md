# Revisión crítica del esquema SQL — LaundryDesk

**Actividad:** S05-S06-A1
**Archivo revisado:** `esquema_bd.sql`
**Motor:** PostgreSQL 16

> **Resumen.**
> - **Qué se revisó:** `esquema_bd.sql` se revisó contra `diagrama_clases_equipo.puml` y `SRS_equipo.md` v0.9.
> - **Correcciones aplicadas (cuatro):**
>   - índices de búsqueda del cliente;
>   - índice único parcial de `servicio.nombre`;
>   - ocho citas de trazabilidad: seis incorrectas y dos faltantes;
>   - se quitó el índice sobre `email_cliente`, que no tenía requerimiento.
> - **Coherencia con `openapi_equipo.yaml`, verificada** (sección 3.4). Coinciden los UUID, las fechas `date-time`, los decimales como cadena, las horas `HH:MM`, los valores de los enums, los `maxLength` de cada `VARCHAR`, los campos obligatorios y los `409` de las dos restricciones únicas. De las nueve diferencias encontradas al escribir el contrato, **tres siguen abiertas** (sección 8, pendiente 1):
>   - `servicio.unidad` sin `CHECK`;
>   - el servicio inactivo, que solo se valida en código;
>   - el formato de hora del `TimeField` de DRF.
> - **Sin verificar:** el uso de los índices nuevos con datos reales.
> - **Pendientes:** quedan ocho. Dos son **bloqueantes** para la Parte 2:
>   - el pendiente 4, confirmar la asociación `Administrador → HistorialEstado`;
>   - el pendiente 5, decidir entre la tabla `administrador` y `django.contrib.auth`.

---

## 1. Qué se generó y con qué insumos

Se generó `esquema_bd.sql`, el esquema físico completo de la base de datos de LaundryDesk para PostgreSQL 16. El backend en Django se construirá a partir de él con `inspectdb`.

**Insumos:**

| Insumo | Uso |
|---|---|
| `diagrama_clases_equipo.puml` | Fuente de verdad del modelo: clases, atributos, multiplicidades, enums y decisiones de consolidación D1–D6. |
| `SRS_equipo.md` v0.9 | Requerimientos que se citan en los comentarios de trazabilidad (RF, RNF, RD). Se incorporó a la carpeta después de la primera versión del esquema; las citas se revisaron contra él (sección 2.3). |
| `insumos/` (diagramas, OpenAPI y matrices de trazabilidad individuales) | Contexto para interpretar los requerimientos antes de contar con `SRS_equipo.md`. |

**Requisitos de generación que pidió el equipo:**

- Una tabla por clase del diagrama.
- PK `UUID` con `DEFAULT gen_random_uuid()`.
- Una FK por relación, con `ON DELETE` justificado.
- `NOT NULL` y `UNIQUE` según el diagrama.
- Enums como `VARCHAR` + `CHECK`, sin `CREATE TYPE ... AS ENUM`, porque `inspectdb` no mapea bien los enums nativos.
- Nombres en `snake_case`.
- Fechas con `TIMESTAMPTZ`.
- Índices justificados por requerimiento y comentarios de trazabilidad en cada tabla.

**Resultado final:** 7 tablas, 6 llaves foráneas, 30 restricciones `CHECK`, 3 restricciones `UNIQUE` y 20 índices. Los 20 índices incluyen los que PostgreSQL crea para las PK y las `UNIQUE`.

---

## 2. Correcciones aplicadas

### 2.1 Índices de búsqueda sobre los datos de contacto del cliente

**Qué se generó al inicio.** La tabla `pedido` tenía índices para:
- el filtrado de RF-07 (`estado_actual`, `fecha_recepcion`);
- el proceso de conservación de RD-07 (`fecha_cierre`);
- la consulta pública por código (la `UNIQUE` de `codigo_seguimiento`).

No había índices sobre `nombre_cliente`, `telefono_cliente` ni `email_cliente`, porque ningún requerimiento de `SRS_equipo.md` pedía buscar por esos campos.

**Qué se cambió.** Se agregaron dos índices:

```sql
CREATE INDEX pedido_telefono_cliente_idx
    ON pedido (telefono_cliente);

CREATE INDEX pedido_nombre_cliente_idx
    ON pedido (UPPER(nombre_cliente) text_pattern_ops);
```

En el mismo ajuste se agregó un tercer índice, sobre `email_cliente`, que después se quitó en la revisión (sección 2.4).

**Por qué.**

- **La necesidad.** El negocio necesita verificar la identidad del cliente con nombre y teléfono cuando no trae su ticket, y esa búsqueda no tenía índice.
- **Trazabilidad.** Los índices responden a **RF-11 de `insumos/emilio/SRS_final.md`**, el SRS individual de S02, anterior a la consolidación: "Verificar la identidad del cliente al entregar el pedido". En particular responden a RF-11-AC-2 y RF-11-AC-3, que usan nombre y teléfono como alternativa al ticket.
  - **No es el RF-11 de `SRS_equipo.md`**, que es "Administrar servicios, precios y horarios". Al consolidar, el equipo reutilizó el ID para otro requerimiento.
  - La cita de RF-11 que se dio al pedir los índices era correcta para el SRS individual. El problema es que el mismo ID nombra dos requerimientos distintos según el documento (ver sección 8, pendiente 2).
  - El comentario SQL de los índices cita ahora `SRS_final.md` de forma explícita.
- **`UPPER(...)` en el nombre.** Django traduce `iexact` como `UPPER(col) = UPPER(valor)` e `istartswith` como `UPPER(col) LIKE UPPER('x%')`. Un índice sobre la columna sin `UPPER` no se usaría en esas consultas.
- **`text_pattern_ops`** permite usar el índice también en búsquedas por prefijo con `LIKE`.
- **El teléfono es el dato más selectivo.** Su búsqueda es exacta, así que el código debe normalizar el formato (sin espacios ni guiones) al guardar y al buscar.
- **Verificación.** La prueba con `EXPLAIN` se hizo con `enable_seqscan = off` sobre una tabla vacía. Demuestra que los dos índices son compatibles con la forma de consulta que genera Django, es decir, que los operadores y `UPPER(...)` coinciden. **No** demuestra que el planificador los elegiría con datos reales. Detalle en la sección 7.
- **Límite conocido.** No cubren búsquedas con el texto en medio del nombre (`icontains`, es decir `%texto%`); para eso haría falta un índice GIN con `pg_trgm`.

### 2.2 Índice único parcial de `servicio.nombre`

**Qué se generó al inicio.** `servicio.nombre` no tenía restricción de unicidad, porque el diagrama no lo marca como `{unique}`. Se reportó como una decisión tomada.

**Qué se cambió.** Se agregó:

```sql
CREATE UNIQUE INDEX servicio_nombre_activo_uq
    ON servicio (UPPER(btrim(nombre)))
    WHERE activo;
```

**Por qué.**

- **El problema.** Dos servicios activos con el mismo nombre confundirían al administrador al registrar un pedido (RF-03).
- **Por qué parcial.** Los servicios se desactivan en vez de borrarse (RF-11-AC-3). Con un `UNIQUE` simple, un servicio desactivado bloquearía su nombre para siempre e impediría crear uno nuevo con ese nombre y otro precio (RF-11-AC-1). Con `WHERE activo`, la unicidad solo aplica a los servicios activos, que son los que el administrador puede elegir.
- **`UPPER(btrim(...))`** hace que "Wash & Fold" y " wash & fold " cuenten como el mismo nombre.
- **Verificado en PostgreSQL 16:**
  - un duplicado activo que solo cambia en mayúsculas y espacios es rechazado;
  - después de desactivar el servicio original sí se crea uno nuevo con el mismo nombre;
  - reactivar el original mientras el nuevo sigue activo es rechazado.
- **Impacto en Django.** `inspectdb` no detecta índices parciales. Hay que declarar a mano `UniqueConstraint(Upper(Trim('nombre')), condition=Q(activo=True), name='servicio_nombre_activo_uq')` en `Meta.constraints`, y la reactivación conflictiva debe responder 409 en lugar de un `IntegrityError`.

### 2.3 Citas de trazabilidad corregidas contra `SRS_equipo.md`

**Qué se generó al inicio.** Los comentarios se escribieron con el significado de los requerimientos reconstruido a partir de las matrices de trazabilidad y los diagramas individuales, porque `SRS_equipo.md` no estaba en la carpeta. Ningún comentario citaba un ID inexistente. Seis citas, sin embargo, atribuían al SRS cosas que no dice, y faltaban dos.

**Qué se cambió y por qué.** Seis citas atribuían al SRS algo que no dice:

| # | Ubicación | Cita original | Qué dice el SRS | Corrección |
|---|---|---|---|---|
| 1 | `historial_estado_motivo_ck` y `COMMENT ON COLUMN historial_estado.motivo` | "RF-08-AC-5: toda corrección manual exige motivo" | RF-08-AC-5 pide que la corrección se confirme explícitamente; no exige motivo. | Cita RF-08-AC-5 para la corrección y aclara que el motivo obligatorio es regla del diagrama consolidado (nota de `HistorialEstado`). |
| 2 | Índice `historial_estado_pedido_fecha_idx` | "RF-08 / RF-08-AC-5: mostrar la bitácora" | Ningún criterio pide consultar el historial de estados. | Cita D3 (decisión de auditoría del diagrama) y aclara que no hay un criterio del SRS detrás. |
| 3 | Índice `notificacion_pedido_idx` | "Idempotencia … (repetirlo no reenvía el aviso, RF-12-AC-1)" | RF-12-AC-1 pide generar la solicitud de correo; no habla de evitar reenvíos. La idempotencia es una decisión del contrato OpenAPI. | Cita RD-07 (anonimizar el destinatario) y marca la idempotencia como decisión del OpenAPI. |
| 4 | FK `notificacion_pedido_fk` | "(RD-07, RNF-02)" | RNF-02 trata de quién puede acceder a los datos personales, no de eliminarlos. | Solo RD-07. |
| 5 | `COMMENT ON COLUMN administrador.password_hash` | "RNF-05" | RNF-05 exige sesión autenticada; no menciona cómo guardar contraseñas. | Cita RF-02 (credenciales) y aclara que guardar solo el hash es práctica de seguridad, no requisito del SRS. |
| 6 | Índice `pedido_fecha_recepcion_idx` | "RF-07-AC-1 y RF-07-AC-2: listar pedidos ordenados por fecha" | RF-07-AC-1 pide mostrar código y estado; no fija ningún orden. | Lo justifica RF-07-AC-2 (filtro solo por fecha); ordenar por fecha queda como uso secundario. |

Dos citas faltaban:

| # | Requerimiento | Dónde se agregó |
|---|---|---|
| 7 | **RD-02** (todo pedido inicia en `Recibido`) | Comentario de la tabla `pedido`, `COMMENT ON TABLE pedido`, el `DEFAULT 'RECIBIDO'` de `estado_actual` y `historial_estado_creacion_ck`. |
| 8 | **RD-03** (peso y precio pueden completarse después del registro) | Comentario de la tabla `pedido`, `COMMENT ON TABLE pedido` y el bloque de datos operativos (`peso`, `precio_final`). |

**Cambio adicional en la misma revisión.** El comentario de `servicio.unidad` incluía las tarifas "$1.50/lb wash & dry, $2.50/lb wash & fold", que provienen de la entrevista con el cliente real (`insumos/emilio/entrevista_cliente_real.md`, sección 1, Pregunta 2, y sección 5, "Precios") y llegaron al esquema a través de la nota de `Pedido` del diagrama. RD-03 dice que el SRS no fija una tarifa por libra, y wash & dry no está en el alcance del SRS. El comentario ahora solo indica la unidad ("lb") y que el precio es configurable (RF-11, RD-03). La discrepancia queda registrada como gap en la sección 8.

### 2.4 Índice sobre `email_cliente`, quitado

**Qué se generó al inicio.** Junto con los índices de teléfono y nombre (sección 2.1) se agregó un índice parcial sobre el correo:

```sql
CREATE INDEX pedido_email_cliente_idx
    ON pedido (UPPER(email_cliente))
    WHERE email_cliente IS NOT NULL;
```

**Qué se cambió.** Se quitó de `esquema_bd.sql`. En su lugar queda un comentario que explica por qué `email_cliente` no tiene índice.

**Por qué.** Ningún requerimiento busca pedidos por correo:

- El RF-11 de `insumos/emilio/SRS_final.md`, que justifica los índices de la sección 2.1, verifica al cliente con el ticket, el nombre y el teléfono, no con el correo.
- `SRS_equipo.md` usa el correo solo como destinatario del aviso de pedido listo (RF-12), que se envía desde el pedido y no requiere buscar por correo.
- Lo único que `insumos/emilio/entrevista_cliente_real.md` dice del correo es que se registraría internamente para promociones (sección 1, Pregunta 1; sección 5, "Datos del cliente"). Eso no es una búsqueda por correo.

Un índice sin consulta que lo use solo encarece cada `INSERT` y `UPDATE` de `pedido`.

---

## 3. Revisión punto por punto

### 3.1 ¿Están todas las entidades del diagrama de clases?

El diagrama tiene 7 clases y 5 enums. Cada clase tiene su tabla y cada enum es un `CHECK`:

| Clase del diagrama | Tabla |
|---|---|
| `Pedido` | `pedido` |
| `HistorialEstado` | `historial_estado` |
| `NotaPedido` | `nota_pedido` |
| `Servicio` | `servicio` |
| `HorarioAtencion` | `horario_atencion` |
| `Notificacion` | `notificacion` |
| `Administrador` | `administrador` |

| Enum del diagrama | Representación |
|---|---|
| `EstadoPedido` | `pedido_estado_actual_ck`, `historial_estado_anterior_ck`, `historial_estado_nuevo_ck` |
| `TipoNota` | `nota_pedido_tipo_ck` |
| `DiaSemana` | `horario_atencion_dia_semana_ck` |
| `CanalNotificacion` | `notificacion_canal_ck` |
| `EstadoEnvio` | `notificacion_estado_envio_ck` |

**Evidencia:** `\dt` sobre la base importada devuelve exactamente esas 7 tablas (sección 7). Las clases que la leyenda del diagrama descarta (`Negocio`, `TransicionEstado`, `Sesion`) y la entidad `Cliente` (D1) no tienen tabla, como corresponde.

### 3.2 ¿Están todos los atributos?

Los 46 atributos del diagrama tienen columna, con el nombre en `snake_case`. Además hay 6 columnas de FK, que salen de las asociaciones y no de los atributos.

| Clase | Atributos en el diagrama | Columnas | Columnas de FK adicionales |
|---|---|---|---|
| `Pedido` | 13: `id`, `codigoSeguimiento`, `fechaRecepcion`, `nombreCliente`, `telefonoCliente`, `emailCliente`, `peso`, `precioFinal`, `instruccionesEspeciales`, `estadoActual`, `fechaListo`, `fechaCierre`, `anonimizado` | 13 | `servicio_id`, `administrador_id` |
| `HistorialEstado` | 6: `id`, `estadoAnterior`, `estadoNuevo`, `fechaCambio`, `esCorreccion`, `motivo` | 6 | `pedido_id`, `administrador_id` |
| `NotaPedido` | 4: `id`, `tipo`, `texto`, `fechaRegistro` | 4 | `pedido_id` |
| `Servicio` | 6: `id`, `nombre`, `descripcion`, `precio`, `unidad`, `activo` | 6 | — |
| `HorarioAtencion` | 5: `id`, `diaSemana`, `horaApertura`, `horaCierre`, `cerrado` | 5 | — |
| `Notificacion` | 8: `id`, `canal`, `destinatario`, `estadoEnvio`, `intentos`, `fechaSolicitud`, `fechaEnvio`, `error` | 8 | `pedido_id` |
| `Administrador` | 4: `id`, `usuario`, `passwordHash`, `activo` | 4 | — |

**Obligatoriedad.**
- Los atributos sin `[0..1]` son `NOT NULL`.
- Los 13 marcados `[0..1]` son nullable: `email_cliente`, `peso`, `precio_final`, `instrucciones_especiales`, `fecha_listo`, `fecha_cierre`, `estado_anterior`, `motivo`, `descripcion`, `hora_apertura`, `hora_cierre`, `fecha_envio` y `error`.
- Los valores iniciales del diagrama (`anonimizado = false`, `esCorreccion = false`, `activo = true`, `cerrado = false`, `intentos = 0`) son `DEFAULT`.

**Unicidad.** Los tres `{unique}` del diagrama son restricciones `UNIQUE`: `pedido_codigo_seguimiento_uq`, `horario_atencion_dia_semana_uq` y `administrador_usuario_uq`.

### 3.3 ¿Las llaves foráneas reflejan la cardinalidad y la tabla referenciada correctas?

Cada asociación del diagrama tiene una FK. La FK está en la tabla del lado "muchos", apunta a la tabla del lado "1" y es `NOT NULL` porque ese lado es obligatorio. Ninguna columna de FK es `UNIQUE`, así que el lado "muchos" admite cero o más filas.

| Relación del diagrama | FK | Tabla referenciada | Nulabilidad | Cardinalidad resultante |
|---|---|---|---|---|
| `Pedido "1" *-- "1..*" HistorialEstado` | `historial_estado_pedido_fk` (`historial_estado.pedido_id`) | `pedido` | `NOT NULL` | Cada registro pertenece a exactamente un pedido. El mínimo de 1 registro por pedido **no** se puede expresar con una FK (sección 6, punto 1). |
| `Pedido "1" *-- "0..*" NotaPedido` | `nota_pedido_pedido_fk` (`nota_pedido.pedido_id`) | `pedido` | `NOT NULL` | 1 a 0..* |
| `Pedido "0..*" --> "1" Servicio` | `pedido_servicio_fk` (`pedido.servicio_id`) | `servicio` | `NOT NULL` | Cada pedido tiene exactamente un servicio. |
| `Pedido "1" --> "0..*" Notificacion` | `notificacion_pedido_fk` (`notificacion.pedido_id`) | `pedido` | `NOT NULL` | 1 a 0..* |
| `Administrador "1" --> "0..*" Pedido` | `pedido_administrador_fk` (`pedido.administrador_id`) | `administrador` | `NOT NULL` | 1 a 0..* |
| `Administrador "1" --> "0..*" HistorialEstado` | `historial_estado_administrador_fk` (`historial_estado.administrador_id`) | `administrador` | `NOT NULL` | 1 a 0..* |

**Comprobación en la base importada:**
- `pg_constraint` reporta 6 FK: 2 en `pedido`, 2 en `historial_estado`, 1 en `nota_pedido` y 1 en `notificacion`.
- En la prueba de humo, borrar un servicio o un administrador referenciado falló con `pedido_servicio_fk` y `pedido_administrador_fk` (RESTRICT).
- Borrar un pedido eliminó su historial y sus notificaciones (CASCADE).

**Observación.** La leyenda del diagrama marca la asociación `Administrador → HistorialEstado` como "pendiente de confirmar con el equipo". El esquema la implementa como `NOT NULL`; si el equipo la rechaza, hay que eliminar `historial_estado.administrador_id` (ver sección 8).

### 3.4 ¿Los tipos de dato son coherentes con `openapi_equipo.yaml`?

**Sí, con tres diferencias que siguen abiertas.** `openapi_equipo.yaml` se escribió cotejándolo columna por columna con `esquema_bd.sql`, y Redocly CLI 1.25.11 lo valida sin errores.

**Lo que coincide:**

- **Identificadores.** UUID (`format: uuid`) en todas las PK y FK expuestas, también en los parámetros de ruta (D2).
- **Fechas.** Las cinco columnas `TIMESTAMPTZ` expuestas (`fecha_recepcion`, `fecha_listo`, `fecha_cierre`, `fecha_cambio`, `fecha_registro`) son `format: date-time`.
- **Decimales.** `peso`, `precio` y `precio_final` son cadenas decimales (`"12.50"`), sin pérdida de precisión:
  - `precio` y `precio_final`: hasta 8 dígitos enteros y 2 decimales, como `NUMERIC(10,2)`, y mayores o iguales a 0;
  - `peso`: mayor que 0 y como máximo `99999.99`, como `NUMERIC(7,2)` y `pedido_peso_positivo_ck`.
- **Horas.** `hora_apertura` y `hora_cierre` son cadenas `HH:MM`.
- **Enums.** `EstadoPedido`, `TipoNota` y `DiaSemana` tienen exactamente los valores de sus `CHECK`, incluidos `EN_PROCESO` y `MIERCOLES`. `CanalNotificacion` y `EstadoEnvio` no aparecen porque `notificacion` no tiene operaciones; `aviso_correo` es un enum propio del contrato, no de la base.
- **Longitudes.** Cada `maxLength` es igual a su `VARCHAR`:
  - `nombre_cliente` y `usuario`, 150;
  - `telefono_cliente`, `codigo_seguimiento` y `unidad`, 20;
  - `email_cliente`, 254;
  - `servicio.nombre`, 100.
- **Obligatoriedad.** Las columnas `NOT NULL` sin `DEFAULT` son `required` en el contrato, incluida `servicio.unidad`, que tres specs individuales omitían. Las que tienen `DEFAULT` son opcionales al crear: `fecha_recepcion`, `activo`, `cerrado` y `es_correccion`.
- **Textos no vacíos.** Los campos con `CHECK (btrim(...) <> '')` llevan el patrón `\S` en lugar de `minLength 1`.
- **Unicidad.** Las dos restricciones únicas que el usuario puede violar tienen su `409`: `servicio_nombre_activo_uq` (`NOMBRE_SERVICIO_DUPLICADO`) y `horario_atencion_dia_semana_uq` (`DIA_HORARIO_DUPLICADO`).

**Diferencias encontradas al escribir el contrato:**

| # | Diferencia | Estado |
|---|---|---|
| 1 | Las filas de la lista de pedidos no traían `id`, así que no se podía abrir el detalle desde la lista. | Corregida: las filas llevan `id`. |
| 2 | En OpenAPI, `exclusiveMinimum` y `maximum` solo aplican a números, y `peso` es una cadena. | Resuelta: los dos límites están en el patrón de `peso`. |
| 3 | Una corrección que saca de un estado cerrado un pedido anonimizado limpia `fecha_cierre` y viola `pedido_anonimizado_ck`. | Resuelta en el contrato: `PUT /pedidos/{pedido_id}/estado` responde `409 PEDIDO_ANONIMIZADO`. La regla se aplica en código. |
| 4 | Una `fecha_recepcion` futura no falla al registrar, sino después: al pasar a `LISTO` o `ENTREGADO` viola `pedido_fecha_listo_orden_ck` o `pedido_fecha_cierre_orden_ck`. | Resuelta en el contrato: el alta responde `422`. La regla se aplica en código. |
| 5 | El contrato rechaza un pedido con un servicio inactivo, pero la base lo acepta: la FK no conoce `activo` (sección 6, punto 4). | **Abierta** (sección 8, pendiente 1). |
| 6 | `unidad` no tiene `CHECK`, así que el contrato no puede enumerar sus valores y la deja como texto libre. | **Abierta** (sección 3.5 y sección 8, pendiente 1). |
| 7 | Las columnas `TEXT` no tienen tamaño, y sin límite el contrato aceptaría cadenas arbitrariamente largas. | Resuelta: el contrato es más estricto que la base (`descripcion` 500, `instrucciones_especiales` 1000, `texto` 2000, `motivo` 500). |
| 8 | El `TimeField` de DRF devuelve `08:00:00` por defecto, y el contrato dice `HH:MM`. | **Abierta** (sección 8, pendiente 1). |
| 9 | El patrón `\S` es más estricto que el `CHECK`: `btrim` solo quita espacios, así que una cadena de tabulaciones pasa la base y el contrato la rechaza. | Aceptada: no rompe nada. |

### 3.5 ¿Hay restricciones faltantes que el negocio requiere?

**Cubiertas en el esquema:**

| Regla de negocio | Restricción |
|---|---|
| Código de seguimiento único (RF-05-AC-2, RNF-03) | `pedido_codigo_seguimiento_uq` |
| Datos obligatorios del pedido (RF-03): nombre, teléfono, servicio, fecha de recepción | `NOT NULL` + `pedido_nombre_no_vacio_ck`, `pedido_telefono_no_vacio_ck` |
| Estado inicial `Recibido` (RD-02) | `DEFAULT 'RECIBIDO'` + `historial_estado_creacion_ck` |
| Fecha de `Listo` disponible para la consulta pública (RF-06-AC-2) | `pedido_fecha_listo_ck` |
| Plazo de conservación desde la fecha de cierre (RD-07) | `pedido_fecha_cierre_ck`, `pedido_anonimizado_ck` |
| Corrección manual con motivo (RF-08-AC-5 + regla del diagrama) | `historial_estado_motivo_ck` |
| Un horario por día (D5) y horas coherentes | `horario_atencion_dia_semana_uq`, `horario_atencion_horas_ck` |
| Un solo servicio activo por nombre | `servicio_nombre_activo_uq` (agregada en la revisión, sección 2.2) |
| Servicio y autor del pedido no se pierden | `ON DELETE RESTRICT` en `pedido_servicio_fk`, `pedido_administrador_fk`, `historial_estado_administrador_fk` |

**Faltantes detectadas y su resolución:**

- **Búsqueda del cliente por nombre y teléfono.** Faltaban los índices y ya se agregaron (sección 2.1). El requerimiento que la sustenta no está en el SRS (sección 8).
- **Unicidad del nombre de servicio.** Faltaba y ya se agregó (sección 2.2).

**Faltantes que no pueden ser restricciones SQL** (validación entre tablas o dependiente del flujo): ver sección 6.

**Faltantes que se dejaron fuera a propósito:**

- **Un solo administrador (RD-06).** Se podría forzar con `CREATE UNIQUE INDEX ... ON administrador ((true))`, pero bloquearía reemplazar la cuenta.
- **Formato del teléfono y del correo.** Se valida en el código, porque el SRS no define un formato.
- **Valores de `servicio.unidad`.** La columna es texto libre sin `CHECK`, así que la base acepta `lb` en un servicio y `libra` en otro, y el precio por unidad se interpreta distinto. No se agregó porque enumerar los valores exige una decisión de negocio que no definen ni `SRS_equipo.md` ni `insumos/emilio/entrevista_cliente_real.md`: la entrevista solo da tarifas por libra (Sección 1, Pregunta 2) y no dice si habrá servicios por pieza o por carga. Ver sección 8, pendiente 1.

---

## 4. Decisiones que el diagrama no especificaba

### 4.1 Longitudes de VARCHAR

| Columna | Tipo | Razón |
|---|---|---|
| `pedido.codigo_seguimiento` | `VARCHAR(20)` | El diagrama no define cómo se genera el código; se dejó margen. |
| `pedido.nombre_cliente` | `VARCHAR(150)` | Nombre completo con holgura. |
| `pedido.telefono_cliente` | `VARCHAR(20)` | E.164 usa hasta 15 dígitos más el "+"; se dejó espacio para separadores. |
| `pedido.email_cliente`, `notificacion.destinatario` | `VARCHAR(254)` | Límite práctico de una dirección de correo (RFC 5321) y `max_length` por defecto del `EmailField` de Django. |
| `servicio.nombre` | `VARCHAR(100)` | Nombre comercial corto. |
| `servicio.unidad` | `VARCHAR(20)` | "lb", "pieza", etc. |
| `administrador.usuario` | `VARCHAR(150)` | Igual que el `username` de Django. |
| `administrador.password_hash` | `VARCHAR(255)` | Para que quepan hashes argon2 o pbkdf2 con sus parámetros. |
| `estado_actual`, `estado_anterior`, `estado_nuevo` | `VARCHAR(20)` | El valor más largo es `EN_PROCESO` (10); se dejó margen para estados futuros (RD-08). |
| `dia_semana`, `tipo`, `canal`, `estado_envio` | `VARCHAR(10)` | El valor más largo es `MIERCOLES` / `INCIDENCIA` / `PENDIENTE` (9–10). |
| `descripcion`, `instrucciones_especiales`, `texto`, `motivo`, `error` | `TEXT` | Texto libre sin límite en el diagrama ni en el SRS. |

### 4.2 Precisión de NUMERIC

| Columna | Tipo | Razón |
|---|---|---|
| `pedido.peso` | `NUMERIC(7,2)` | Libras con dos decimales, hasta 99,999.99 lb. |
| `servicio.precio`, `pedido.precio_final` | `NUMERIC(10,2)` | Moneda con centavos; `NUMERIC` evita los errores de redondeo de `float`. |

### 4.3 Valores por defecto

**Los que vienen del diagrama:**
- `anonimizado = FALSE`, `es_correccion = FALSE`, `cerrado = FALSE`
- `activo = TRUE` (en `servicio` y en `administrador`)
- `intentos = 0`

**Los que se decidieron en el esquema:**
- `estado_actual = 'RECIBIDO'` (RD-02, RF-03-AC-1).
- `estado_envio = 'PENDIENTE'`: el aviso nace pendiente en el outbox.
- `now()` en `fecha_recepcion`, `fecha_cambio`, `fecha_registro` y `fecha_solicitud`.

Nota: `inspectdb` no traslada los `DEFAULT` de la base a los modelos. Si el código crea filas desde Django, debe asignar estos valores o declararlos con `db_default`.

### 4.4 Otras decisiones de tipo

- **Horas sin zona horaria.** `hora_apertura` y `hora_cierre` son `TIME`, no `TIMESTAMPTZ`: son horas del día local del negocio, no instantes. La documentación de PostgreSQL desaconseja `TIMETZ`.
- **`CHECK` adicionales** que el diagrama sugiere sin dibujarlos:
  - textos obligatorios que no pueden quedar vacíos;
  - `peso > 0`, `precio >= 0`, `precio_final >= 0` e `intentos >= 0`;
  - el orden entre fechas;
  - las coherencias entre estado y fecha de la sección 5.

### 4.5 ON DELETE de cada llave foránea

| FK | Acción | Razón |
|---|---|---|
| `historial_estado_pedido_fk` | `CASCADE` | Composición en el diagrama: el historial no existe sin su pedido. Si RD-07 se cumple eliminando el pedido, su historial se elimina en la misma operación. |
| `nota_pedido_pedido_fk` | `CASCADE` | Composición: la nota solo tiene sentido dentro de su pedido y puede contener datos del cliente. |
| `notificacion_pedido_fk` | `CASCADE` | Es asociación, no composición, pero el aviso no tiene valor sin su pedido y `destinatario` es dato personal que debe eliminarse con él (RD-07). |
| `pedido_servicio_fk` | `RESTRICT` | Los servicios se desactivan, no se borran (RF-11-AC-3). Borrar uno dejaría pedidos sin el servicio que se cobró. |
| `pedido_administrador_fk` | `RESTRICT` | Quién registró el pedido es dato de auditoría. El administrador se desactiva con `activo = FALSE`. |
| `historial_estado_administrador_fk` | `RESTRICT` | "Quién hizo el cambio" es lo que convierte el historial en auditoría (D3). |

---

## 5. Restricciones que obligan a actualizar varias columnas en la misma sentencia

> **Para quien escriba los servicios CRUD en Django.**
>
> PostgreSQL revisa cada `CHECK` al terminar **cada sentencia**, no al hacer `COMMIT`, y los `CHECK` no pueden diferirse. Por eso dos `UPDATE` seguidos dentro de `transaction.atomic()` **no bastan**: las columnas relacionadas tienen que ir en la **misma** sentencia.
>
> En Django eso significa:
> - `instance.save()` sin `update_fields` funciona, porque escribe todas las columnas.
> - `save(update_fields=[...])` debe incluir **todas** las columnas del grupo.
> - `QuerySet.update(...)` debe recibir **todas** las columnas del grupo en la misma llamada.
>
> `inspectdb` genera modelos con `managed = False` y sin `Meta.constraints`, así que Django no conoce estas reglas. Si se violan, el error llega como `IntegrityError` (500), no como error de validación. Conviene repetirlas en `Meta.constraints` o en `clean()` para responder 422 o 409.

### Tabla `pedido`

| Restricción | Columnas | Regla | Qué debe hacer el servicio |
|---|---|---|---|
| `pedido_fecha_listo_ck` | `estado_actual`, `fecha_listo` | `estado_actual <> 'LISTO' OR fecha_listo IS NOT NULL` | Al pasar a `LISTO`, asignar `fecha_listo` en la misma sentencia. |
| `pedido_fecha_cierre_ck` | `estado_actual`, `fecha_cierre` | `(estado_actual IN ('ENTREGADO','CANCELADO')) = (fecha_cierre IS NOT NULL)` | Al pasar a `ENTREGADO` o `CANCELADO`, asignar `fecha_cierre`. Si una corrección saca al pedido de un estado final, poner `fecha_cierre = NULL` en la misma sentencia. |
| `pedido_anonimizado_ck` | `anonimizado`, `fecha_cierre` | `NOT anonimizado OR fecha_cierre IS NOT NULL` | Solo poner `anonimizado = TRUE` en un pedido que ya tiene `fecha_cierre`. **Efecto combinado con la regla anterior:** un pedido anonimizado no puede reabrirse con una corrección, porque `fecha_cierre` no puede volver a `NULL`. El servicio debe rechazarlo antes de llegar a la base. |
| `pedido_fecha_listo_orden_ck` | `fecha_recepcion`, `fecha_listo` | `fecha_listo >= fecha_recepcion` | Si se edita `fecha_recepcion`, no puede quedar después de `fecha_listo`. |
| `pedido_fecha_cierre_orden_ck` | `fecha_recepcion`, `fecha_cierre` | `fecha_cierre >= fecha_recepcion` | Si se edita `fecha_recepcion`, no puede quedar después de `fecha_cierre`. |

### Tabla `historial_estado`

Solo se insertan filas, así que todas las columnas van juntas en el `INSERT`. Basta con respetar las reglas.

| Restricción | Columnas | Regla | Qué debe hacer el servicio |
|---|---|---|---|
| `historial_estado_creacion_ck` | `estado_anterior`, `estado_nuevo` | `estado_anterior IS NOT NULL OR estado_nuevo = 'RECIBIDO'` | Solo el registro de creación del pedido va sin estado anterior, y su estado nuevo es `RECIBIDO`. |
| `historial_estado_distinto_ck` | `estado_anterior`, `estado_nuevo` | `estado_anterior IS NULL OR estado_anterior <> estado_nuevo` | No registrar un "cambio" al mismo estado. Esto también protege la idempotencia del `PUT` de estado. |
| `historial_estado_motivo_ck` | `es_correccion`, `motivo` | `NOT es_correccion OR (motivo IS NOT NULL AND btrim(motivo) <> '')` | Con `es_correccion = TRUE`, el motivo es obligatorio y no puede quedar vacío. |

### Tabla `horario_atencion`

| Restricción | Columnas | Regla | Qué debe hacer el servicio |
|---|---|---|---|
| `horario_atencion_horas_ck` | `cerrado`, `hora_apertura`, `hora_cierre` | `cerrado OR (hora_apertura IS NOT NULL AND hora_cierre IS NOT NULL AND hora_apertura < hora_cierre)` | Para abrir un día marcado como cerrado: `cerrado = FALSE` y las dos horas en la misma sentencia. Para cambiar las horas, mandar las dos juntas: pasar de 08:00–12:00 a 13:00–18:00 cambiando primero solo `hora_apertura` falla, porque 13:00 > 12:00. |

### Tabla `notificacion`

| Restricción | Columnas | Regla | Qué debe hacer el servicio |
|---|---|---|---|
| `notificacion_fecha_envio_ck` | `estado_envio`, `fecha_envio` | `(estado_envio = 'ENVIADA') = (fecha_envio IS NOT NULL)` | Al marcar `ENVIADA`, asignar `fecha_envio` en la misma sentencia. Si sale de `ENVIADA`, poner `fecha_envio = NULL`. |
| `notificacion_fecha_envio_orden_ck` | `fecha_solicitud`, `fecha_envio` | `fecha_envio >= fecha_solicitud` | `fecha_envio` no puede ser anterior a la solicitud. |

### Regla entre tablas (no es un `CHECK`, pero se aplica igual)

Un cambio de estado se hace **en un mismo `transaction.atomic()`**:
1. actualizar `pedido.estado_actual`, con `fecha_listo` o `fecha_cierre` en la misma sentencia según corresponda;
2. insertar su fila en `historial_estado`;
3. si el nuevo estado es `LISTO` y el pedido tiene correo, insertar la fila en `notificacion` (patrón outbox, RF-12-AC-2, RNF-06).

---

## 6. Restricciones del dominio que no se pueden expresar en SQL

Las restricciones de esta sección dependen de otras tablas, del orden de las operaciones, del tiempo o de reglas de seguridad. Un `CHECK` solo ve la fila que se está escribiendo, y una FK solo garantiza que la fila referenciada exista.

1. **Todo pedido tiene al menos un registro de historial** (multiplicidad `1..*`). Crear el pedido y su registro `RECIBIDO` en la misma transacción.
2. **Transiciones de estado permitidas** (RD-01, RD-04, RF-08-AC-4, RF-10-AC-2):
   - el flujo normal es `RECIBIDO → EN_PROCESO → LISTO → ENTREGADO`, más `RECIBIDO → CANCELADO`;
   - cualquier otra transición normal se rechaza con 409;
   - las correcciones manuales (RF-08-AC-5) requieren confirmación explícita.
   - El diagrama decidió dejar las transiciones en el código y no en una tabla (clase `TransicionEstado` descartada).
3. **Coherencia entre `pedido` e `historial_estado`:**
   - `pedido.estado_actual` es igual al `estado_nuevo` del registro más reciente;
   - cada `estado_anterior` es igual al `estado_nuevo` del registro previo;
   - `fecha_listo` coincide con la `fecha_cambio` del paso a `LISTO`.
4. **Un servicio inactivo no se usa en pedidos nuevos** (RF-11-AC-3). La FK no conoce el valor de `activo`.
5. **Un administrador inactivo** (`activo = FALSE`) no puede autenticarse ni registrar pedidos o cambios.
6. **Código de seguimiento no predecible** (RNF-03). La base solo garantiza que sea único; el generador debe usar una fuente criptográficamente segura (`secrets` en Python).
7. **Formatos y normalización:**
   - teléfono normalizado, para que funcione la búsqueda exacta de la sección 2.1;
   - correo válido;
   - `notificacion.destinatario` coherente con `canal`.
8. **Reglas de notificación** (RF-12):
   - solo se crea si el pedido tiene correo (RF-12-AC-3);
   - solo por `CORREO` en el MVP (las SMS están fuera de alcance, SRS 1.2 y 2.4);
   - no se duplica cuando se repite el `PUT` de estado;
   - el límite de reintentos está por definir.
9. **Anonimización a los 12 meses del cierre (RD-07):**
   - un proceso programado debe reemplazar `nombre_cliente`, `telefono_cliente`, `email_cliente` y `notificacion.destinatario`, y marcar `anonimizado = TRUE`;
   - como nombre y teléfono son `NOT NULL`, se sustituyen por un marcador en lugar de quedar vacíos;
   - después, los datos personales del pedido no deben modificarse.
10. **Datos personales fuera de la consulta pública** (RNF-02). La consulta por código selecciona solo código, estado, fecha de recepción y `fecha_listo`.
11. **Un solo administrador (RD-06).** Se podría expresar, pero se dejó fuera a propósito (sección 3.5).
12. **Unicidad del nombre de servicio en Django.** La base ya la garantiza (`servicio_nombre_activo_uq`), pero Django debe replicarla para responder 409 en lugar de un `IntegrityError` (sección 2.2).

---

## 7. Verificación de la importación

El esquema final se importó en un contenedor local de **PostgreSQL 16.15** (imagen `postgres:16`), con `psql -v ON_ERROR_STOP=1`. La importación terminó con código de salida 0 y `\dt` devolvió las siete tablas:

```
              List of relations
 Schema |       Name       | Type  |  Owner
--------+------------------+-------+----------
 public | administrador    | table | postgres
 public | historial_estado | table | postgres
 public | horario_atencion | table | postgres
 public | nota_pedido      | table | postgres
 public | notificacion     | table | postgres
 public | pedido           | table | postgres
 public | servicio         | table | postgres
(7 rows)
```

**Conteos en el catálogo** (`pg_constraint`, `pg_indexes`): 7 PK, 6 FK, 3 `UNIQUE`, 30 `CHECK` y 20 índices.

**Pruebas de comportamiento:**

- **Restricciones (sobre el esquema inicial).** Se rechazaron con la restricción esperada:
  - una corrección sin motivo (`historial_estado_motivo_ck`);
  - un pedido en `LISTO` sin `fecha_listo` (`pedido_fecha_listo_ck`);
  - un pedido en `ENTREGADO` sin `fecha_cierre` (`pedido_fecha_cierre_ck`);
  - un horario con la apertura después del cierre (`horario_atencion_horas_ck`);
  - un estado inválido (`pedido_estado_actual_ck`).
- **ON DELETE.** Borrar un servicio y un administrador referenciados falló por RESTRICT. Borrar el pedido eliminó su historial y su notificación por CASCADE.
- **Índices de búsqueda del cliente.** Con `EXPLAIN` (y `enable_seqscan = off`, porque la tabla de prueba estaba vacía), las consultas con la forma que genera Django usan `pedido_telefono_cliente_idx` y `pedido_nombre_cliente_idx` (igualdad y prefijo) (sección 2.1). La misma prueba incluyó `pedido_email_cliente_idx` antes de que se quitara (sección 2.4). En la búsqueda combinada de nombre y teléfono, el planificador eligió uno solo de los dos índices y aplicó el otro criterio como filtro, que es lo esperado.
- **Unicidad del nombre de servicio.** `servicio_nombre_activo_uq` rechaza el duplicado activo y la reactivación conflictiva, y permite reutilizar el nombre de un servicio desactivado (sección 2.2).

El contenedor fue temporal (`--rm`) y se eliminó al terminar.

---

## 8. Pendientes

1. **Coherencia con `openapi_equipo.yaml`: cerrado.** El contrato ya existe y se cotejó con el esquema (sección 3.4). De los tres puntos que quedaban abiertos, dos ya se resolvieron en el backend (ver "Correcciones al código generado"):
   - **`servicio.unidad` sin `CHECK`.** **Sigue abierto.** Hay que decidir con el negocio qué unidades existen antes de enumerarlas en el `CHECK` y en el contrato (sección 3.5). El backend lo deja como texto libre validado solo por longitud mientras no haya esa decisión.
   - **El servicio inactivo solo se validaba en código.** **Resuelto.** `PedidoCrearSerializer.servicio_id` usa un `PrimaryKeyRelatedField` con `queryset=Servicio.objects.filter(activo=True)` en `api/serializers.py`: un `servicio_id` inactivo cae naturalmente en `422 VALIDACION`.
   - **Formato de hora del `TimeField` de DRF.** **Resuelto.** `HoraField` en `api/serializers.py` fija `format='%H:%M'` e `input_formats=['%H:%M']`.

2. **Problemas de la consolidación del SRS y diferencias con la entrevista:**
   - **Requerimiento perdido en la consolidación: verificar la identidad del cliente al entregar.**
     - Existía como **RF-11 de `insumos/emilio/SRS_final.md`** (SRS individual de S02, línea 326), con tres criterios:
       - RF-11-AC-1: verificar con el ticket;
       - RF-11-AC-2: verificar con nombre y teléfono si el cliente no trae el ticket;
       - RF-11-AC-3: rechazar la entrega si no coinciden.
     - **No pasó a `SRS_equipo.md` v0.9.** Ningún RF del equipo lo cubre, aunque la sección 1.2 del SRS del equipo menciona "identificar al cliente" como necesidad del negocio.
     - Los índices de la sección 2.1 ya citan el RF-11 de `SRS_final.md`. Si el SRS del equipo incorpora el requerimiento, hay que cambiar la cita por el ID nuevo.
     - **Base de la fuente.** `SRS_final.md` declara en su encabezado (líneas 4–7) que se basa en la entrevista simulada (Sesión 1). `insumos/emilio/entrevista_cliente_real.md` no menciona la verificación de identidad, así que conviene confirmarla con el cliente al reincorporarla.
   - **Colisión de IDs entre los dos SRS: toda cita de RF-11 es ambigua.**
     - El mismo ID nombra dos requerimientos distintos:
       - en `SRS_final.md`, RF-11 es "Verificar la identidad del cliente al entregar el pedido";
       - en `SRS_equipo.md`, RF-11 es "Administrar servicios, precios y horarios".
     - El equipo reutilizó el ID al consolidar.
     - **El problema no se limita a RF-11.** Casi todos los IDs cambiaron de significado entre los dos documentos. Solo RF-09, RNF-02 y RNF-03 conservan el mismo requerimiento.
     - **Regla para este documento y `esquema_bd.sql`:** toda cita de RF, RNF o RD sin documento indicado se refiere a `SRS_equipo.md` v0.9. Las únicas citas a `SRS_final.md` son las de los índices de búsqueda del cliente, y lo dicen explícitamente.
   - **Tarifas por libra y servicio wash & dry.**
     - La entrevista con el cliente real menciona $1.50/lb en wash & dry (sin doblado) y $2.50/lb en wash & fold, con precios ajustables en el tiempo.
     - **Fuente:** `insumos/emilio/entrevista_cliente_real.md`:
       - sección 1, Pregunta 2: "they call it a wash and dry services, no folding would start a dollar and a half per pound and then the wash and fold would be 2.50 per pound";
       - sección 5, "Precios".
     - `SRS_equipo.md` no fija ninguna tarifa (su RD-03) y su alcance solo incluye wash & fold.
     - El esquema no depende de esas cifras, porque el precio es configurable (RF-11 de `SRS_equipo.md`). Lo que hay que resolver en el SRS del equipo es si wash & dry entra al alcance.

3. **Actualizar el diagrama de clases para que coincida con el esquema.**
   - **Unicidad.** El esquema tiene `servicio_nombre_activo_uq`, pero `diagrama_clases_equipo.puml` no marca la restricción. También hay que documentar el 409 por nombre duplicado en el contrato OpenAPI.
   - **Tarifas.** El comentario de `servicio.unidad` ya no cita las tarifas por libra (sección 2.3), pero la nota de `Pedido` en `diagrama_clases_equipo.puml` las sigue citando ($1.50/lb wash & dry, $2.50/lb wash & fold). Hay que quitarlas del diagrama para que los dos artefactos coincidan.

4. **RESUELTO — confirmar la asociación `Administrador → HistorialEstado`.**
   - Decisión del equipo (confirmada en la conversación de implementación): **se mantiene**. `historial_estado.administrador_id` sigue `NOT NULL` con la FK `historial_estado_administrador_fk`, tal como está en `esquema_bd.sql`, y así quedó modelada en `api/models.py` (`HistorialEstado.administrador`).

5. **RESUELTO — tabla `administrador` frente a `django.contrib.auth`.**
   - Decisión del equipo (confirmada en la conversación de implementación): **la tabla `administrador` se queda como está**, no se usa `django.contrib.auth` en esta entrega. Ver "Correcciones al código generado" para el razonamiento completo y sus consecuencias (no hay autenticación todavía, se usa un administrador temporal fijo).

6. **Dirección del cliente.**
   - La entrevista con el stakeholder dice que la recolección y entrega a domicilio es el punto de partida del servicio, y pone la dirección entre los datos del cliente.
   - **Fuente:** `insumos/emilio/entrevista_cliente_real.md`:
     - sección 1, Pregunta 2: "Name, address, phone number, services needed";
     - sección 2, "Alcance del servicio": "la recolección y entrega a domicilio es el punto de partida del servicio";
     - también en la sección 4 (primera fila de la tabla) y en la sección 5, "Datos del cliente".
   - `pedido` no tiene esa columna y el SRS no la pide: deja la recolección fuera del MVP (sección 1.2, RD-08).
   - `insumos/emilio/decision_arquitectonica.md` señala que las direcciones reutilizables exigirían una identidad de cliente que persista más allá del pedido. Eso reabriría D1 (sin entidad `Cliente`) y obligaría a revisar RD-07 y RD-02.

7. **Canal de notificación elegido por el cliente.**
   - El stakeholder pidió que cada cliente elija entre correo y mensaje de texto.
   - **Fuente:** `insumos/emilio/entrevista_cliente_real.md`:
     - sección 2, "Notificaciones": "Propone que el sistema permita a cada cliente elegir entre correo electrónico y mensaje de texto";
     - sección 5, "Canal de notificación";
     - sección 4, cuarta fila de la tabla.
   - `pedido` no tiene dónde guardar esa preferencia. Hoy el canal solo existe en cada fila de `notificacion` (`notificacion.canal`).
   - La sección 6 restringe el MVP a correo, siguiendo al SRS (secciones 1.2 y 2.4).

8. **Contradicción sobre el número de usuarios.**
   - En la sesión, el stakeholder dijo que habría un nivel de acceso de empleado limitado al tablero y a las notificaciones. En la ronda de seguimiento dijo que un solo usuario basta.
   - **Fuente:** `insumos/emilio/entrevista_cliente_real.md`:
     - sección 1, Pregunta 6: "more than one would have access so there's also an employee access level for the dashboard and the notification system only";
     - sección 2, "Usuarios del sistema": "un solo usuario sería suficiente";
     - la sección 6, "Contradicción pendiente de resolver", registra el conflicto.
   - **Inconsistencia dentro del mismo archivo:** la sección 3 da por confirmado que "El sistema tendrá un solo usuario administrador", aunque la sección 6 deja la cuestión abierta.
   - Si es lo primero, `administrador` necesita un campo de rol.
   - Hoy el esquema asume RD-06 (un único administrador) como resuelto.

---

## 9. Correcciones al código generado

> **Contexto de esta sección.** El equipo pidió completar el CRUD de la Parte 2 (servicio, horario_atencion y pedido) dejando la decisión de ingeniería en mis manos, con tres restricciones explícitas: usar la arquitectura ya elegida (Django + DRF + PostgreSQL), priorizar lo más fácil de aprender y mantener con ~3 semanas de trabajo restante, y documentar aquí cada corrección o decisión. Esta sección es ese registro. No se tocó `esquema_bd.sql`: todo lo de abajo es código de aplicación sobre el esquema ya existente.

### 9.1 Pila tecnológica y por qué no se cambió nada

Se mantiene exactamente lo que el equipo ya tenía: **Django 5.x + Django REST Framework + PostgreSQL 16**, con `psycopg[binary]` (el driver moderno recomendado por Django 5, sin necesidad de compilar nada) y `python-dotenv` para las variables de entorno. No se introdujo ningún componente nuevo (no Celery, no Redis, no GraphQL, no un framework de autenticación): con 3 semanas restantes y un equipo que "no entiende bien el tema", cada pieza nueva es una curva de aprendizaje que no se va a alcanzar a dominar. Todo lo que había que resolver, se resolvió con herramientas que ya vienen incluidas en Django/DRF.

### 9.2 Decisión de arquitectura: sin autenticación esta entrega, con un administrador temporal

La actividad indica explícitamente que **este entregable no incluye seguridad en los endpoints** (la autenticación se trabaja aparte, en otra entrega). Consecuencias de esa decisión, para que el equipo las tenga claras:

- `settings.py` no incluye `django.contrib.auth`, `django.contrib.sessions` ni `django.contrib.admin`: solo `django.contrib.contenttypes` (dependencia técnica de Django) más `rest_framework` y la app `api`.
- `DEFAULT_PERMISSION_CLASSES = ["rest_framework.permissions.AllowAny"]`: ningún endpoint pide credenciales todavía.
- Donde el contrato necesita "quién hizo esto" (`pedido.administrador_id`, `historial_estado.administrador_id`, ambas `NOT NULL` por el esquema), se usa una variable de entorno `ADMIN_ID_TEMPORAL` (ver `.env.example`), resuelta en `settings.ADMIN_ID_TEMPORAL`.
- Se agregó el comando `python manage.py seed_admin`, que crea (una sola vez, es idempotente) la fila de `administrador` con ese mismo id, para que las FK `NOT NULL` tengan a qué apuntar. El equipo debe correrlo una vez después de importar `esquema_bd.sql` y antes de probar cualquier endpoint de `pedido`.
- En `api/exceptions.py` quedan ya resueltos los casos `NotAuthenticated`/`AuthenticationFailed` → `401 NO_AUTENTICADO`. Hoy es código muerto (nada los dispara), pero queda listo para cuando el equipo agregue JWT en la entrega de seguridad: no van a tener que tocar el formato de error, solo agregar `IsAuthenticated` y una vista de login.
- **Riesgo a tener presente:** mientras no haya autenticación, cualquiera que tenga la URL del backend puede crear o modificar pedidos, que incluyen datos personales del cliente (nombre, teléfono, correo). Esto es aceptable solo para desarrollo y para la demo de esta entrega, corriendo el backend en local o en un entorno no público. No debe desplegarse así a Render con datos reales de clientes.

### 9.3 Corrección de formato: los errores y la paginación de DRF no coinciden con el contrato

DRF, por defecto, usa `{"detail": "..."}` o un diccionario plano de campo→mensajes para los errores, y responde siempre `400` para `ValidationError`. El contrato (`openapi_equipo.yaml`) exige:
- un sobre único de error: `{codigo, mensaje, errores: [{campo, mensaje}]}`;
- `422`, no `400`, cuando el JSON es válido pero algún campo no pasa la validación;
- `400` reservado solo para un cuerpo que ni siquiera es JSON interpretable;
- `404` tanto para un recurso que no existe como para un id de ruta que no es un UUID válido;
- `409` para conflictos de negocio (nombre de servicio duplicado, transición de estado no permitida, etc.).

**Corrección aplicada:** se escribió un manejador de excepciones centralizado, `api/exceptions.py`, registrado en `settings.py` como `REST_FRAMEWORK["EXCEPTION_HANDLER"]`. Traduce cada tipo de excepción de Django/DRF al formato y código exactos del contrato, y define las excepciones de negocio propias (`NombreServicioDuplicadoError`, `DiaHorarioDuplicadoError`, `TransicionNoPermitidaError`, `RequiereRevisionManualError`, `PedidoAnonimizadoError`) que las vistas y `api/services.py` usan para los `409`.

De la misma forma, el paginador por defecto de DRF responde `{count, next, previous, results}` y el contrato pide `{resultados, total, pagina, tamano_pagina}`. Se escribió `PedidoPageNumberPagination` en `api/pagination.py`, usado solo en `GET /pedidos`.

### 9.4 Modelado: `managed = False` sobre las tablas de `esquema_bd.sql`

`api/models.py` es el equivalente a lo que generaría `python manage.py inspectdb` apuntando a la base ya importada con `esquema_bd.sql`, corregido a mano según los puntos que la sección 5 de este documento ya advertía que `inspectdb` no detecta:
- los `choices` de cada enum (`inspectdb` no los genera a partir de un `CHECK`, porque no son tipos nativos de PostgreSQL);
- el índice único parcial `servicio_nombre_activo_uq`, declarado como `UniqueConstraint(Upper(Trim('nombre')), condition=Q(activo=True), ...)` en `Meta.constraints`, exactamente como se anticipó en la sección 2.2;
- el `db_column` y el `on_delete` de cada FK, copiando el mismo `ON DELETE` que ya tiene `esquema_bd.sql` (`RESTRICT` o `CASCADE`, sección 4.5).

Todas las tablas son `Meta.managed = False`: Django nunca va a crear, alterar ni borrar estas tablas con una migración. El equipo sigue siendo responsable de aplicar `esquema_bd.sql` directamente en PostgreSQL (como ya lo venían haciendo) antes de correr el backend.

### 9.5 Reglas de varias columnas (sección 5) y de negocio (sección 6): dónde quedaron en el código

Toda la lógica que la sección 5 de este documento pedía mantener "en la misma sentencia" (por los `CHECK` que PostgreSQL evalúa por sentencia, no por transacción) y toda la lógica de la sección 6 que no se puede expresar en SQL, se concentró en **`api/services.py`**, dentro de una función `cambiar_estado()` decorada con `@transaction.atomic`:

- aplica el flujo normal de transiciones (`RECIBIDO → EN_PROCESO → LISTO → ENTREGADO`, más `RECIBIDO → CANCELADO`) y rechaza cualquier otra con `409 TRANSICION_NO_PERMITIDA`, salvo que esté en la lista explícita de correcciones permitidas (reabrir un `CANCELADO` o retroceder un estado) **y** venga con `es_correccion=true`, `confirmacion=true` y `motivo`; si falta alguno de esos tres, responde `409 REQUIERE_REVISION_MANUAL`;
- es idempotente: pedir el mismo `estado_nuevo` que el pedido ya tiene no falla ni crea un historial nuevo, tal como exige `PUT` y la restricción `historial_estado_distinto_ck`;
- bloquea cualquier cambio sobre un pedido `anonimizado` con `409 PEDIDO_ANONIMIZADO`, antes de tocar la base (así nunca se intenta violar `pedido_anonimizado_ck`);
- escribe `estado_actual`, `fecha_listo` y `fecha_cierre` en un solo `save(update_fields=[...])`, nunca en escrituras separadas, siguiendo al pie de la letra la advertencia de la sección 5;
- crea la fila de `historial_estado` en la misma transacción;
- si el nuevo estado es `LISTO` y el pedido tiene `email_cliente`, crea la fila de `notificacion` en estado `PENDIENTE` (patrón outbox): el backend de esta entrega **no envía correos**, solo deja la intención registrada, tal como ya estaba previsto en la sección 5, punto 3, y en la sección 6, punto 8.

También en `api/services.py`: `generar_codigo_seguimiento()` usa el módulo `secrets` (no `random`), siguiendo la sección 6, punto 6 (RNF-03: el código no debe ser adivinable), y `normalizar_telefono()` resuelve la sección 6, punto 7.

### 9.6 Los dos pendientes abiertos de la sección 8, resueltos en código

- **Servicio inactivo en un pedido nuevo** (sección 6, punto 4; sección 8, pendiente 1): `PedidoCrearSerializer.servicio_id`, en `api/serializers.py`, es un `PrimaryKeyRelatedField(queryset=Servicio.objects.filter(activo=True))`. Si el `servicio_id` enviado corresponde a un servicio inactivo (o no existe), DRF lo trata igual que "no existe" y el manejador de excepciones lo convierte en `422 VALIDACION`, sin que haya que escribir una validación aparte.
- **Formato de hora `HH:MM`** (sección 3.4, diferencia 8; sección 8, pendiente 1): se definió `HoraField`, una subclase de `serializers.TimeField` con `format='%H:%M'` e `input_formats=['%H:%M']`, usada en los serializadores de `horario_atencion`.

### 9.7 Precio y peso como cadena decimal, con los mismos límites que el contrato

`PrecioField` y `PesoField` (en `api/serializers.py`) son subclases de `CharField`, no de `DecimalField`: el contrato (sección 3.4) expone estos valores como cadenas decimales, nunca como `number`, para no perder precisión. Cada una valida con una expresión regular los mismos límites que ya tiene la base de datos (`precio`/`precio_final`: hasta 8 enteros y 2 decimales, `>= 0`, como `NUMERIC(10,2)`; `peso`: `> 0` y hasta `99999.99`, como `NUMERIC(7,2)` y `pedido_peso_positivo_ck`), y devuelve siempre el valor con dos decimales fijos.

### 9.8 Decisión propia: se agrega `DELETE /servicios/{servicio_id}`, y se documenta por qué no se agrega en los otros dos recursos

La actividad pide un CRUD **completo** (Crear, Leer, Actualizar, **Eliminar**) para `servicio`, `horario_atencion` y `pedido`, pero `openapi_equipo.yaml` no tiene ninguna operación `DELETE`. Como ingeniero, decidí lo siguiente para no dejar ese hueco sin resolver ni inventar un endpoint que choque con las reglas de negocio ya acordadas:

- **`DELETE /servicios/{servicio_id}` sí se agregó** (`ServicioDetailView.destroy`, en `api/views.py`). No borra la fila: la marca con `activo = False` y responde `204`. Es una baja lógica, consistente con la sección 2.2 y con el hecho de que `pedido.servicio_id` es `RESTRICT` (un servicio usado en algún pedido no se puede borrar de la base sin romper esa FK). Esto es exactamente lo mismo que ya permitía `PATCH {"activo": false}`, expuesto también como `DELETE` porque la actividad lo pide por nombre.
- **`horario_atencion` no tiene `DELETE`**, a propósito. La decisión D5 del diagrama (citada en la sección 4.5 y en el esquema) es que siempre existen los 7 días de la semana: un día no se borra, solo se marca `cerrado = true`. Agregar un `DELETE` real dejaría un día de la semana sin fila, lo que rompería la unicidad `horario_atencion_dia_semana_uq` al querer volver a crearlo y no tiene ningún caso de uso real para el negocio.
- **`pedido` no tiene `DELETE`**, a propósito. RD-07 exige conservar el pedido 12 meses desde su cierre antes de anonimizarlo (sección 6, punto 9); borrarlo bajo demanda contradice directamente ese requerimiento, además de que `historial_estado`, `nota_pedido` y `notificacion` dependen de él por `CASCADE` y se perdería la auditoría completa del pedido.

**Esto es una decisión unilateral mía, no una corrección de algo que el equipo ya hubiera decidido.** Si alguien del equipo quiere, puede agregar `DELETE /servicios/{servicio_id}` a `openapi_equipo.yaml` para que el contrato y el código coincidan del todo (la respuesta ya es la estándar `204 No Content`); no hace falta ningún cambio de código para eso, solo documentarlo en el contrato.

### 9.9 Resumen de archivos entregados

```
backend/
├── requirements.txt          Django, DRF, psycopg[binary], python-dotenv
├── .env.example               Variables de entorno (incluye ADMIN_ID_TEMPORAL)
├── .gitignore
├── manage.py
├── config/
│   ├── settings.py            Sin auth, zona horaria de México, EXCEPTION_HANDLER
│   ├── urls.py                 Monta api.urls en /api/v1/
│   └── wsgi.py
└── api/
    ├── models.py               Equivalente a inspectdb, corregido a mano
    ├── exceptions.py           Formato de error y códigos HTTP del contrato
    ├── pagination.py           Paginación en el formato del contrato
    ├── services.py             Transiciones de estado, código de seguimiento
    ├── serializers.py          Validación de campos, PrecioField/PesoField/HoraField
    ├── views.py                 Una vista por endpoint de openapi_equipo.yaml
    ├── urls.py                  Rutas bajo /api/v1/
    └── management/commands/
        └── seed_admin.py        Crea el administrador temporal (correr una vez)
```

**Lo que el equipo necesita hacer para correrlo:** importar `esquema_bd.sql` en PostgreSQL 16, copiar `.env.example` a `.env` y llenar los datos de conexión, instalar `requirements.txt`, correr `python manage.py seed_admin` una vez, y luego `python manage.py runserver`. No hace falta `python manage.py migrate` para las tablas del dominio (son `managed = False`); si Django pide migrar `contenttypes`, correr `migrate` una vez es seguro porque esa tabla no choca con nada de `esquema_bd.sql`.

No se pudo probar este código contra una base PostgreSQL real en este entorno (sandbox sin base de datos disponible); sí se verificó que todos los archivos compilan como Python válido. El equipo debe correr las pruebas de humo (crear un servicio, crear un pedido, cambiar su estado, consultarlo) en su propio entorno antes de dar por cerrada la entrega.
