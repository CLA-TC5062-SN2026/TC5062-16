-- ============================================================
-- LaundryDesk — Esquema físico de base de datos
-- Motor: PostgreSQL 16
-- Fuente de verdad: diagrama_clases_equipo.puml (S05-S06-A1, Parte 0.3)
-- Requerimientos citados: SRS_equipo.md v0.9
--
-- Convenciones:
--   * Una tabla por clase del diagrama. Los enums del diagrama NO son
--     tablas: se representan como VARCHAR + CHECK (Django inspectdb no
--     mapea bien los tipos ENUM nativos de PostgreSQL).
--   * PK: UUID con DEFAULT gen_random_uuid() (decisión D2). La función
--     es nativa desde PostgreSQL 13; no requiere la extensión pgcrypto.
--   * Nombres en snake_case y en singular, igual que las clases.
--   * Fechas y horas con TIMESTAMPTZ (Django con USE_TZ = True).
--   * Columnas de FK con sufijo _id para que inspectdb genere
--     ForeignKey con el nombre de la asociación.
--   * Los COMMENT ON TABLE / COLUMN los recoge inspectdb (Django 4.2+)
--     como db_table_comment y db_comment.
--
-- Política de ON DELETE (resumen; el detalle está junto a cada FK):
--   historial_estado.pedido_id      -> CASCADE  (composición)
--   nota_pedido.pedido_id           -> CASCADE  (composición)
--   notificacion.pedido_id          -> CASCADE  (dato dependiente del pedido)
--   pedido.servicio_id              -> RESTRICT (el catálogo se desactiva, no se borra)
--   pedido.administrador_id         -> RESTRICT (auditoría)
--   historial_estado.administrador_id -> RESTRICT (auditoría)
-- ============================================================

BEGIN;

-- ------------------------------------------------------------
-- administrador
-- Sustenta: RF-02 (autenticación), RNF-05 (control de acceso a
-- operaciones administrativas), RD-06 (un único administrador en el MVP).
-- ------------------------------------------------------------
CREATE TABLE administrador (
    id              UUID         NOT NULL DEFAULT gen_random_uuid(),
    usuario         VARCHAR(150) NOT NULL,
    password_hash   VARCHAR(255) NOT NULL,
    activo          BOOLEAN      NOT NULL DEFAULT TRUE,

    CONSTRAINT administrador_pk PRIMARY KEY (id),
    CONSTRAINT administrador_usuario_uq UNIQUE (usuario),
    CONSTRAINT administrador_usuario_no_vacio_ck CHECK (btrim(usuario) <> '')
);

COMMENT ON TABLE administrador IS
    'Cuenta administrativa. RF-02, RNF-05, RD-06. Se desactiva (activo = false), no se borra: el historial lo referencia.';
COMMENT ON COLUMN administrador.password_hash IS
    'Hash de la contraseña (nunca texto plano). Credenciales de RF-02; guardar solo el hash es práctica de seguridad, el SRS no lo exige explícitamente.';

-- ------------------------------------------------------------
-- servicio
-- Sustenta: RF-01-AC-1 (catálogo público con precios vigentes),
-- RF-11 (alta, modificación y desactivación de servicios).
-- ------------------------------------------------------------
CREATE TABLE servicio (
    id              UUID          NOT NULL DEFAULT gen_random_uuid(),
    nombre          VARCHAR(100)  NOT NULL,
    descripcion     TEXT,
    precio          NUMERIC(10,2) NOT NULL,
    unidad          VARCHAR(20)   NOT NULL,
    activo          BOOLEAN       NOT NULL DEFAULT TRUE,

    CONSTRAINT servicio_pk PRIMARY KEY (id),
    CONSTRAINT servicio_nombre_no_vacio_ck CHECK (btrim(nombre) <> ''),
    CONSTRAINT servicio_unidad_no_vacia_ck CHECK (btrim(unidad) <> ''),
    CONSTRAINT servicio_precio_no_negativo_ck CHECK (precio >= 0)
);

-- Nombre único entre los servicios ACTIVOS, sin distinguir mayúsculas
-- ni espacios al inicio o al final: dos servicios activos con el mismo
-- nombre confundirían al administrador al registrar un pedido (RF-03).
-- Es parcial (WHERE activo) porque los servicios se desactivan en vez de
-- borrarse (RF-11-AC-3): un UNIQUE simple haría que un servicio
-- desactivado bloqueara para siempre su nombre e impediría crear uno
-- nuevo con ese nombre y otro precio (RF-11-AC-1).
-- Django: inspectdb no detecta índices parciales. Hay que declarar a mano
-- UniqueConstraint(Upper(Trim('nombre')), condition=Q(activo=True), ...)
-- en Meta.constraints, y reactivar un servicio cuyo nombre ya usa otro
-- activo debe responder 409 en lugar de un IntegrityError.
CREATE UNIQUE INDEX servicio_nombre_activo_uq
    ON servicio (UPPER(btrim(nombre)))
    WHERE activo;

COMMENT ON TABLE servicio IS
    'Catálogo de servicios. RF-01-AC-1, RF-11. Baja lógica con activo = false (RF-11-AC-3).';
COMMENT ON COLUMN servicio.unidad IS
    'Unidad de cobro, p. ej. "lb". El precio por unidad es configurable (RF-11); el SRS no fija una tarifa (RD-03).';

-- ------------------------------------------------------------
-- horario_atencion
-- Sustenta: RF-01-AC-2 (consulta pública de horarios),
-- RF-11-AC-2 (actualizar horario y reflejarlo públicamente).
-- ------------------------------------------------------------
CREATE TABLE horario_atencion (
    id              UUID        NOT NULL DEFAULT gen_random_uuid(),
    dia_semana      VARCHAR(10) NOT NULL,
    -- Hora del día local del negocio: TIME sin zona (ver notas de diseño).
    hora_apertura   TIME,
    hora_cierre     TIME,
    cerrado         BOOLEAN     NOT NULL DEFAULT FALSE,

    CONSTRAINT horario_atencion_pk PRIMARY KEY (id),
    -- D5: un solo horario por día.
    CONSTRAINT horario_atencion_dia_semana_uq UNIQUE (dia_semana),
    CONSTRAINT horario_atencion_dia_semana_ck CHECK (dia_semana IN (
        'LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES', 'SABADO', 'DOMINGO'
    )),
    -- Un día abierto necesita ambas horas y apertura antes del cierre.
    CONSTRAINT horario_atencion_horas_ck CHECK (
        cerrado
        OR (hora_apertura IS NOT NULL
            AND hora_cierre IS NOT NULL
            AND hora_apertura < hora_cierre)
    )
);

COMMENT ON TABLE horario_atencion IS
    'Horario semanal del negocio. RF-01-AC-2, RF-11-AC-2. Un registro por día (D5).';

-- ------------------------------------------------------------
-- pedido
-- Sustenta: RF-03 (registro de pedidos), RF-04 (peso, precio e
-- instrucciones), RF-05 (código de seguimiento único), RF-06 (consulta
-- pública), RF-07 (lista y filtrado), RF-08 / RF-10 (estado),
-- RD-02 (estado inicial), RD-03 (peso y precio posteriores al registro),
-- RD-07 (conservación por 12 meses y anonimización).
-- ------------------------------------------------------------
CREATE TABLE pedido (
    id                       UUID          NOT NULL DEFAULT gen_random_uuid(),
    codigo_seguimiento       VARCHAR(20)   NOT NULL,
    fecha_recepcion          TIMESTAMPTZ   NOT NULL DEFAULT now(),

    -- Datos de contacto del cliente (D1: sin entidad Cliente).
    nombre_cliente           VARCHAR(150)  NOT NULL,
    telefono_cliente         VARCHAR(20)   NOT NULL,
    email_cliente            VARCHAR(254),

    -- Datos operativos (se completan después del registro, RF-04, RD-03).
    peso                     NUMERIC(7,2),
    precio_final             NUMERIC(10,2),
    instrucciones_especiales TEXT,

    -- Estado y cierre. Estado inicial RECIBIDO (RD-02, RF-03-AC-1).
    estado_actual           VARCHAR(20)   NOT NULL DEFAULT 'RECIBIDO',
    fecha_listo              TIMESTAMPTZ,
    fecha_cierre             TIMESTAMPTZ,
    anonimizado              BOOLEAN       NOT NULL DEFAULT FALSE,

    -- Asociaciones.
    servicio_id              UUID          NOT NULL,
    administrador_id         UUID          NOT NULL,

    CONSTRAINT pedido_pk PRIMARY KEY (id),
    -- RF-05-AC-2, RNF-03: el código no se repite entre pedidos.
    CONSTRAINT pedido_codigo_seguimiento_uq UNIQUE (codigo_seguimiento),

    CONSTRAINT pedido_estado_actual_ck CHECK (estado_actual IN (
        'RECIBIDO', 'EN_PROCESO', 'LISTO', 'ENTREGADO', 'CANCELADO'
    )),
    CONSTRAINT pedido_codigo_no_vacio_ck CHECK (btrim(codigo_seguimiento) <> ''),
    CONSTRAINT pedido_nombre_no_vacio_ck CHECK (btrim(nombre_cliente) <> ''),
    CONSTRAINT pedido_telefono_no_vacio_ck CHECK (btrim(telefono_cliente) <> ''),
    CONSTRAINT pedido_peso_positivo_ck CHECK (peso > 0),
    CONSTRAINT pedido_precio_no_negativo_ck CHECK (precio_final >= 0),

    -- RF-06-AC-2: un pedido en LISTO siempre tiene la fecha que se muestra.
    CONSTRAINT pedido_fecha_listo_ck CHECK (
        estado_actual <> 'LISTO' OR fecha_listo IS NOT NULL
    ),
    -- fecha_cierre existe si y solo si el pedido está en un estado final.
    -- Una corrección que reabre el pedido debe limpiarla, para que RD-07
    -- no cuente el plazo de conservación de un pedido activo.
    CONSTRAINT pedido_fecha_cierre_ck CHECK (
        (estado_actual IN ('ENTREGADO', 'CANCELADO')) = (fecha_cierre IS NOT NULL)
    ),
    CONSTRAINT pedido_fecha_listo_orden_ck CHECK (fecha_listo >= fecha_recepcion),
    CONSTRAINT pedido_fecha_cierre_orden_ck CHECK (fecha_cierre >= fecha_recepcion),
    -- RD-07: solo se anonimiza un pedido cerrado.
    CONSTRAINT pedido_anonimizado_ck CHECK (NOT anonimizado OR fecha_cierre IS NOT NULL),

    -- Pedido "0..*" --> "1" Servicio.
    -- RESTRICT: un servicio se desactiva, no se elimina (RF-11-AC-3). Borrarlo
    -- dejaría pedidos sin el servicio que se cobró; la BD lo impide.
    CONSTRAINT pedido_servicio_fk FOREIGN KEY (servicio_id)
        REFERENCES servicio (id) ON DELETE RESTRICT,

    -- Administrador "1" --> "0..*" Pedido.
    -- RESTRICT: quién registró el pedido es dato de auditoría. El
    -- administrador se desactiva con activo = false en lugar de borrarse.
    CONSTRAINT pedido_administrador_fk FOREIGN KEY (administrador_id)
        REFERENCES administrador (id) ON DELETE RESTRICT
);

COMMENT ON TABLE pedido IS
    'Pedido de lavandería. RF-03, RF-04, RF-05, RF-06, RF-07, RF-08, RF-10, RD-02, RD-03, RD-07.';
COMMENT ON COLUMN pedido.codigo_seguimiento IS
    'Código público, aleatorio y no secuencial. RF-05, RNF-03.';
COMMENT ON COLUMN pedido.peso IS
    'Peso en libras (lb), no en kilogramos. RF-04-AC-1.';
COMMENT ON COLUMN pedido.fecha_listo IS
    'Redundancia deliberada con historial_estado para la consulta pública sin JOIN. RF-06-AC-2.';
COMMENT ON COLUMN pedido.fecha_cierre IS
    'Momento en que pasa a ENTREGADO o CANCELADO. Inicio del plazo de 12 meses de RD-07.';
COMMENT ON COLUMN pedido.anonimizado IS
    'TRUE cuando los datos personales ya se anonimizaron. RD-07.';

-- ------------------------------------------------------------
-- historial_estado
-- Sustenta: RF-08 (cambios de estado), RF-08-AC-5 (corrección manual),
-- RF-10 (cancelación), D3 (auditoría de quién y cuándo).
-- El SRS no pide consultar el historial ni exige motivo en las
-- correcciones: ambas reglas vienen del diagrama consolidado (D3 y la
-- nota de HistorialEstado).
-- ------------------------------------------------------------
CREATE TABLE historial_estado (
    id               UUID        NOT NULL DEFAULT gen_random_uuid(),
    estado_anterior  VARCHAR(20),
    estado_nuevo     VARCHAR(20) NOT NULL,
    fecha_cambio     TIMESTAMPTZ NOT NULL DEFAULT now(),
    es_correccion    BOOLEAN     NOT NULL DEFAULT FALSE,
    motivo           TEXT,

    pedido_id        UUID        NOT NULL,
    administrador_id UUID        NOT NULL,

    CONSTRAINT historial_estado_pk PRIMARY KEY (id),

    -- NULL pasa el CHECK, así que estado_anterior sigue siendo opcional.
    CONSTRAINT historial_estado_anterior_ck CHECK (estado_anterior IN (
        'RECIBIDO', 'EN_PROCESO', 'LISTO', 'ENTREGADO', 'CANCELADO'
    )),
    CONSTRAINT historial_estado_nuevo_ck CHECK (estado_nuevo IN (
        'RECIBIDO', 'EN_PROCESO', 'LISTO', 'ENTREGADO', 'CANCELADO'
    )),
    -- El registro sin estado anterior es la creación del pedido: RECIBIDO
    -- (nota del diagrama; RD-02, RF-03-AC-1).
    CONSTRAINT historial_estado_creacion_ck CHECK (
        estado_anterior IS NOT NULL OR estado_nuevo = 'RECIBIDO'
    ),
    -- Un cambio de estado cambia el estado.
    CONSTRAINT historial_estado_distinto_ck CHECK (
        estado_anterior IS NULL OR estado_anterior <> estado_nuevo
    ),
    -- Toda corrección manual (RF-08-AC-5) exige motivo. La exigencia del
    -- motivo es regla del diagrama consolidado; RF-08-AC-5 solo pide
    -- confirmación explícita.
    CONSTRAINT historial_estado_motivo_ck CHECK (
        NOT es_correccion OR (motivo IS NOT NULL AND btrim(motivo) <> '')
    ),

    -- Pedido "1" *-- "1..*" HistorialEstado (composición).
    -- CASCADE: el historial no existe sin su pedido. Si RD-07 se cumple
    -- eliminando el pedido, su historial se va con él en la misma operación.
    CONSTRAINT historial_estado_pedido_fk FOREIGN KEY (pedido_id)
        REFERENCES pedido (id) ON DELETE CASCADE,

    -- Administrador "1" --> "0..*" HistorialEstado.
    -- RESTRICT: "quién hizo el cambio" es lo que convierte el historial en
    -- auditoría (D3). Borrar al administrador lo dejaría sin autor.
    CONSTRAINT historial_estado_administrador_fk FOREIGN KEY (administrador_id)
        REFERENCES administrador (id) ON DELETE RESTRICT
);

COMMENT ON TABLE historial_estado IS
    'Bitácora de cambios de estado de un pedido. RF-08, RF-08-AC-5, RF-10, D3.';
COMMENT ON COLUMN historial_estado.motivo IS
    'Obligatorio cuando es_correccion = TRUE (regla del diagrama consolidado para las correcciones de RF-08-AC-5).';

-- ------------------------------------------------------------
-- nota_pedido
-- Sustenta: RF-09-AC-1 (registrar nota o incidencia sin alterar el
-- estado), RF-09-AC-2 (consultar notas e incidencias), D4.
-- ------------------------------------------------------------
CREATE TABLE nota_pedido (
    id              UUID        NOT NULL DEFAULT gen_random_uuid(),
    tipo            VARCHAR(10) NOT NULL,
    texto           TEXT        NOT NULL,
    fecha_registro  TIMESTAMPTZ NOT NULL DEFAULT now(),

    pedido_id       UUID        NOT NULL,

    CONSTRAINT nota_pedido_pk PRIMARY KEY (id),
    CONSTRAINT nota_pedido_tipo_ck CHECK (tipo IN ('NOTA', 'INCIDENCIA')),
    CONSTRAINT nota_pedido_texto_no_vacio_ck CHECK (btrim(texto) <> ''),

    -- Pedido "1" *-- "0..*" NotaPedido (composición).
    -- CASCADE: una nota solo tiene sentido dentro de su pedido y puede
    -- contener datos del cliente; se elimina con él.
    CONSTRAINT nota_pedido_pedido_fk FOREIGN KEY (pedido_id)
        REFERENCES pedido (id) ON DELETE CASCADE
);

COMMENT ON TABLE nota_pedido IS
    'Notas e incidencias de un pedido. RF-09-AC-1, RF-09-AC-2, D4.';

-- ------------------------------------------------------------
-- notificacion
-- Sustenta: RF-12-AC-1 (correo al pasar a LISTO), RF-12-AC-2 y RNF-06
-- (la falla del proveedor no revierte el pedido: patrón outbox),
-- D6. SMS existe en el dominio pero está fuera del MVP (SRS 1.2).
-- ------------------------------------------------------------
CREATE TABLE notificacion (
    id              UUID         NOT NULL DEFAULT gen_random_uuid(),
    canal           VARCHAR(10)  NOT NULL,
    destinatario    VARCHAR(254) NOT NULL,
    estado_envio    VARCHAR(10)  NOT NULL DEFAULT 'PENDIENTE',
    intentos        INTEGER      NOT NULL DEFAULT 0,
    fecha_solicitud TIMESTAMPTZ  NOT NULL DEFAULT now(),
    fecha_envio     TIMESTAMPTZ,
    error           TEXT,

    pedido_id       UUID         NOT NULL,

    CONSTRAINT notificacion_pk PRIMARY KEY (id),
    CONSTRAINT notificacion_canal_ck CHECK (canal IN ('CORREO', 'SMS')),
    CONSTRAINT notificacion_estado_envio_ck CHECK (estado_envio IN (
        'PENDIENTE', 'ENVIADA', 'FALLIDA'
    )),
    CONSTRAINT notificacion_destinatario_no_vacio_ck CHECK (btrim(destinatario) <> ''),
    CONSTRAINT notificacion_intentos_ck CHECK (intentos >= 0),
    -- fecha_envio existe si y solo si el aviso se envió.
    CONSTRAINT notificacion_fecha_envio_ck CHECK (
        (estado_envio = 'ENVIADA') = (fecha_envio IS NOT NULL)
    ),
    CONSTRAINT notificacion_fecha_envio_orden_ck CHECK (fecha_envio >= fecha_solicitud),

    -- Pedido "1" --> "0..*" Notificacion.
    -- CASCADE: aunque es asociación y no composición, el aviso no tiene
    -- valor sin su pedido y destinatario es dato personal que debe
    -- eliminarse con el pedido (RD-07).
    CONSTRAINT notificacion_pedido_fk FOREIGN KEY (pedido_id)
        REFERENCES pedido (id) ON DELETE CASCADE
);

COMMENT ON TABLE notificacion IS
    'Outbox de avisos al cliente. RF-12-AC-1, RF-12-AC-2, RNF-06, D6.';
COMMENT ON COLUMN notificacion.destinatario IS
    'Correo o teléfono del cliente. Dato personal: se anonimiza con el pedido (RD-07).';

-- ============================================================
-- Índices
-- Las restricciones UNIQUE ya crean su índice B-tree y no se repiten:
--   pedido.codigo_seguimiento    -> RF-06-AC-1/3 (consulta pública por código)
--                                   y RF-05-AC-2 (unicidad al generar)
--   horario_atencion.dia_semana  -> RF-11-AC-2 (actualizar el horario de un día)
--   administrador.usuario        -> RF-02-AC-1/2 (búsqueda en el login)
-- PostgreSQL NO indexa automáticamente las columnas de FK; abajo se
-- crean solo las que tienen una consulta que las justifique.
-- ============================================================

-- RF-07-AC-2: filtrar pedidos por estado, o por estado y rango de fechas
-- (GET /orders?status=&dateFrom=&dateTo=). El estado va primero porque
-- se compara por igualdad y la fecha por rango.
CREATE INDEX pedido_estado_fecha_recepcion_idx
    ON pedido (estado_actual, fecha_recepcion);

-- RF-07-AC-2: filtrar solo por rango de fechas, sin estado. El índice
-- compuesto anterior no sirve sin el estado como prefijo. También sirve
-- para ordenar por fecha la lista de RF-07-AC-1 (el SRS no fija el orden).
CREATE INDEX pedido_fecha_recepcion_idx
    ON pedido (fecha_recepcion);

-- RD-07: el proceso de conservación busca pedidos cerrados hace más de
-- 12 meses que aún no se anonimizan. Índice parcial: solo contiene las
-- filas que ese proceso puede tocar.
CREATE INDEX pedido_pendiente_anonimizar_idx
    ON pedido (fecha_cierre)
    WHERE anonimizado = FALSE AND fecha_cierre IS NOT NULL;

-- Búsqueda de pedidos por datos de contacto del cliente (verificar su
-- identidad con nombre y teléfono cuando no trae su ticket).
-- Trazabilidad: RF-11 de insumos/emilio/SRS_final.md (SRS INDIVIDUAL de
-- S02, no el del equipo), "Verificar la identidad del cliente al entregar
-- el pedido", AC-2 y AC-3: nombre y teléfono como alternativa al ticket.
-- OJO: en SRS_equipo.md el ID RF-11 es otro requerimiento ("Administrar
-- servicios, precios y horarios"), y este no pasó a la consolidación.
-- Ver revision_sql.md, sección 8, pendiente 2.
--
-- El índice sobre el nombre usa UPPER(...) porque así traduce Django
-- los lookups iexact / istartswith en PostgreSQL
-- (UPPER(col) = UPPER(valor), UPPER(col) LIKE UPPER('x%')). Un índice
-- sobre la columna sin UPPER no se usaría en esas consultas.
-- text_pattern_ops permite usar el índice también con LIKE de prefijo.

-- El teléfono es el dato más selectivo: con él la verificación encuentra
-- los pedidos del cliente y el nombre se compara sobre esas pocas filas.
-- La búsqueda es exacta: el código debe normalizar el formato del
-- teléfono (sin espacios ni guiones) al guardar y al buscar.
CREATE INDEX pedido_telefono_cliente_idx
    ON pedido (telefono_cliente);

CREATE INDEX pedido_nombre_cliente_idx
    ON pedido (UPPER(nombre_cliente) text_pattern_ops);

-- email_cliente no tiene índice: ningún requerimiento busca por correo.
-- Ver revision_sql.md, sección 2.4.

-- D3: mostrar la bitácora de auditoría de un pedido en orden
-- cronológico (regla del diagrama; el SRS no tiene un AC que pida
-- consultar el historial). También acelera el ON DELETE CASCADE desde pedido.
CREATE INDEX historial_estado_pedido_fecha_idx
    ON historial_estado (pedido_id, fecha_cambio);

-- RF-09-AC-2: mostrar las notas e incidencias de un pedido en orden.
-- También acelera el ON DELETE CASCADE desde pedido.
CREATE INDEX nota_pedido_pedido_fecha_idx
    ON nota_pedido (pedido_id, fecha_registro);

-- RF-12-AC-1, RF-12-AC-2, RNF-06: el proceso del outbox toma los avisos pendientes
-- en orden de llegada (SELECT ... FOR UPDATE SKIP LOCKED). Índice
-- parcial: las enviadas, que son la mayoría, no entran.
CREATE INDEX notificacion_pendiente_idx
    ON notificacion (fecha_solicitud)
    WHERE estado_envio = 'PENDIENTE';

-- RD-07: anonimizar el destinatario de las notificaciones de un pedido.
-- También lo usa la idempotencia de PUT /orders/{orderId}/status
-- (repetirlo no reenvía el aviso), que es una decisión del contrato
-- OpenAPI y no un AC del SRS. También acelera el CASCADE.
CREATE INDEX notificacion_pedido_idx
    ON notificacion (pedido_id);

COMMIT;
