# Diferencias entre los diseños individuales — LaundryDesk

**Actividad:** S05-S06-A1, Parte 0
**Consolida:** Emilio
**Resultado de la consolidación:** `diagrama_clases_equipo.puml`, `esquema_bd.sql` y `openapi_equipo.yaml`

> **Resumen.**
> - Los cuatro diseños coinciden en el dominio: los mismos recursos, los mismos cinco estados, una consulta pública reducida y un código de seguimiento no secuencial.
> - Hay cuatro mayorías de tres contra uno que resolvieron casi todo el modelo de datos. Las minorías fueron Diego (entidad `Cliente`, borrado de servicios, notificación síncrona), Sebastián (ids enteros), Isaí (microservicios) y Emilio (cookie de sesión, prefijo `/admin`).
> - Los conflictos reales fueron ocho. El más costoso fue el stack: solo Sebastián y Emilio nombraron uno, y eran incompatibles.
> - **Lo más serio no es una diferencia entre diseños, sino lo que apareció al consolidar** (sección 6). La entrevista con el cliente real no llegó al SRS del equipo. El diagrama consolidado citaba la sesión simulada como si fuera el cliente; ya está corregido, y solo el borrador, que es un insumo, repite esa atribución. Además, ninguno de los cuatro contratos individuales habría funcionado contra la base de datos.
> - Varias resoluciones contradicen lo que propuso Emilio, que es quien consolida. Están marcadas como **Contradice a Emilio**.

---

## 1. Qué se comparó y en qué actividad se produjo cada artefacto

Las rutas son relativas a `insumos/`. La columna de actividad dice lo que indica el propio archivo; donde el archivo no lo indica, se dice.

| Integrante | Artefactos | Actividad según el archivo |
|---|---|---|
| **Diego** | `diego/decision_arquitectonica.md` (ADR-001, 2026-10-10), `diego/diagrama_clases.puml`, `diego/diagrama_componentes.puml`, `diego/diagrama_despliegue.puml`, `diego/openapi.yaml`, `diego/revision_rest.md`, `diego/decisiones_y_trazabilidad.md`, dos diagramas de secuencia | Ninguno de sus archivos indica la actividad. |
| **Isaí** | `isai/Semana seis 2/Decision_arquitectonica.md` (ADR-001, 2026-10-10), `Decisiones_diseno_clases.md`, `Diagrama_clases.mmd`, `Diagrama_componentes.mmd`, `Diagrama_despliegue.mmd`; `isai/Semana_seis/openapi.yaml`, `Revision_rest.md`, `Decisiones_y_trazabilidad.md`, dos diagramas de secuencia | ADR y decisiones de clases: **S04_A1**. Revisión REST y trazabilidad: **S04_A2**. `Semana seis 2/opción.md` está vacío. |
| **Sebastián** | `sebastian/decision_arquitectonica.md` (ADR-001 y ADR-002, este del 2026-10-09); en `sebastian/Actividad semana 6/`: `openapi.yaml`, `diagramas/diagrama_clases.puml`, `diagrama_componentes.puml`, `diagrama_componentes_backend.puml`, `diagrama_despliegue.puml`, dos diagramas de secuencia | Su ADR ubica el OpenAPI en **S04_A2**, y el encabezado de `openapi.yaml` ubica los diagramas en **S04_A1**. Los documentos `revision_rest.md` y `revision_diagrama_clases.md` que cita no están en `insumos/`. |
| **Emilio** | `emilio/decision_arquitectonica.md` (ADR-001, 2026-10-06), `emilio/diagrama_clases.puml`, `emilio/openapi.yaml` (v0.9.1) | Ninguno indica la actividad. **No hay diagramas de componentes ni de despliegue** en `insumos/emilio/`, aunque `openapi.yaml` cita `diagrama_componentes.puml`. Tampoco está `stack_decision.md`, que cita el ADR. |

**Insumos de requerimientos:**
- `SRS_equipo.md` v0.9, la línea base. Isaí lo cita como `S03_A1/SRS_equipo.md`.
- `emilio/SRS_final.md` y `emilio/requerimientos.md`, del SRS individual de Emilio.
- `emilio/transcript_entrevista.md`: la sesión simulada de S02-A1.
- `emilio/entrevista_cliente_real.md`: la entrevista con el dueño. Su encabezado dice que usó el guion de la sesión simulada de S02-A1.

Los SRS individuales de Diego, Isaí y Sebastián no están en `insumos/`.

**Material de apoyo producido en esta actividad:**
- el comparativo de los cuatro `openapi.yaml`;
- `emilio/mapeo_ids_srs.md`;
- `revision_sql.md`.

**Orden de trabajo.** `esquema_bd.sql` se escribió antes que el backend, que se generará con `inspectdb` (`revision_sql.md`, sección 3.4). `openapi_equipo.yaml` se escribió después y se cotejó con el esquema.

> **Corrección al borrador.** `conflictos_diseno_borrador.md` afirma que los cuatro entregaron diagramas de componentes y de despliegue y que "ya está completo el insumo de la Parte 0". No es así: faltan los dos diagramas de Emilio, y también los dos documentos de revisión que cita Sebastián.

---

## 2. Consenso de los cuatro

Cada punto está verificado en los cuatro archivos citados.

- **Recursos.** Servicios, horarios de atención, pedidos y consulta pública por código de seguimiento. Aparecen en los cuatro `openapi.yaml`.
- **Los mismos cinco estados.** Recibido, en proceso, listo, entregado y cancelado. Diego los escribe como `Recibido` y `EnProceso` (`diego/diagrama_clases.puml`) o `En proceso` (`diego/openapi.yaml`); los otros tres, como `RECIBIDO` y `EN_PROCESO`.
- **Consulta pública con un tipo reducido.** Nunca devuelven el pedido completo:
  - Diego: `TrackingResponse` (`diego/openapi.yaml`);
  - Isaí: `SeguimientoPublico` (`isai/Semana_seis/openapi.yaml`);
  - Sebastián: `SeguimientoPublico` (`sebastian/.../openapi.yaml`, y ADR-001, escenario E3);
  - Emilio: `PedidoPublico` (`emilio/openapi.yaml`, y ADR-001, decisión 2).
- **El servidor genera el código de seguimiento, no secuencial.** Diego lo pone en el parámetro `TrackingCode`; Isaí, en `post_pedidos`; Sebastián, en `registrarPedido` y en su ADR-001 (RNF-03); Emilio, en `registrarPedido`.
- **El cliente no tiene cuenta.** Los cuatro declaran el seguimiento público sin token (`security: []`).
- **Peso, precio final e instrucciones pueden llenarse después del registro.** Los cuatro los declaran opcionales o `nullable`.
- **Las notas e incidencias no cambian el estado.** Lo dicen las cuatro operaciones de alta de notas.
- **Un servicio no se borra físicamente.** Hasta el `DELETE` de Diego es una "eliminación lógica" (`diego/openapi.yaml`, `deactivateService`).
- **Una falla del correo no revierte el estado guardado (RNF-06).** El fondo es común, pero el mecanismo no: Diego guarda y luego envía de forma síncrona en la misma petición (`diego/decisiones_y_trazabilidad.md`, sección RF-12), y los otros tres registran un aviso que se envía aparte (sección 3).
- **El proveedor de correo queda separado del dominio.** Diego lo separa de la lógica principal (ADR-001, "Decisión"). Isaí le da su propio servicio de Notificaciones (`Diagrama_componentes.mmd`). Sebastián usa el adaptador `EnviadorCorreo` (ADR-001, patrones). Emilio usa adaptadores por canal (ADR-001, decisión 3).

> **Correcciones al borrador.**
> - **"Autenticación Bearer JWT" no es consenso.** Emilio la declara en su `openapi.yaml` pero dice explícitamente que **no está implementada**: el mecanismo real es la cookie de sesión de Better Auth. Es una mayoría de tres contra uno (sección 3).
> - **"Los cuatro resuelven el correo desacoplando la notificación" es inexacto.** Diego no tiene entidad de notificación, y su `secuencia_flujo2.puml` responde `sent` o `failed` en la misma petición.
> - **"El backend es la única capa con acceso a la base de datos" no vale para Isaí.** En su diseño cada microservicio tiene acceso exclusivo a sus propios datos (`Diagrama_componentes.mmd`). Lo común a los cuatro es que el navegador nunca toca la base.

---

## 3. Mayorías de tres contra uno

| Punto | Mayoría | Minoría y su argumento | Resolución |
|---|---|---|---|
| **El cliente no es entidad propia** (D1) | Isaí, con `DatosCliente` en composición 1:1 (`Diagrama_clases.mmd`); Sebastián y Emilio, con campos planos en `Pedido` (sus `diagrama_clases.puml`) | **Diego**: entidad `Cliente` con `id: UUID` y asociación `1 -- 0..*` con `Pedido` (`diego/diagrama_clases.puml`). **Diego no documenta por qué**: ni su ADR ni `decisiones_y_trazabilidad.md` hablan de la entidad. | Columnas en `pedido`. El argumento de la mayoría está escrito por dos integrantes de forma independiente: Isaí dice que una entidad global obliga a reglas de identificación y deduplicación que el SRS no pide (`Decisiones_diseno_clases.md`, decisión 1), y Emilio que el SRS excluye cuentas e historial por cliente (`emilio/diagrama_clases.puml`, nota de `Pedido`). |
| **Identificadores UUID** (D2) | Diego, Isaí y Emilio (sus diagramas de clases; en `openapi.yaml`, Isaí deja los parámetros de ruta como `string` sin formato) | **Sebastián**: `id: int` en todas las clases (`diagrama_clases.puml`) y `integer` en el contrato. **No documenta por qué** en ningún archivo. | UUID en las 7 tablas y en todo el contrato, también en los parámetros de ruta. |
| **Una sola unidad desplegable** | Diego: cliente-servidor en capas (ADR-001). Sebastián: capas más cliente-servidor, desplegado como monolito modular Django (ADR-001). Emilio: monolito modular en capas (ADR-001). | **Isaí**: microservicios con API Gateway y **cuatro** servicios: Identidad, Pedidos, Catálogo y Notificaciones (ADR-001, "Componentes lógicos" e "Implicaciones"). Su argumento es la separación por capacidad de negocio, el potencial de evolución independiente y la "oportunidad académica de practicar [...] arquitectura distribuida"; acepta "expresamente" el mayor esfuerzo. Él mismo matiza: "evitando añadir infraestructura distribuida que aún no se necesite", y admite un mismo servidor de base de datos con esquemas separados en desarrollo local. | Una sola unidad desplegable. Los cuatro módulos de Isaí coinciden con los módulos de Sebastián (`pedidos`, `catalogo`, `notificaciones` y autenticación) y de Emilio (`catalogo`, `pedidos`, `notificaciones`, `auth`). Lo que se pierde de su propuesta es el despliegue separado y el Gateway. |
| **Autenticación JWT Bearer** | Diego, Isaí y Sebastián (sus `openapi.yaml`). Sebastián además define access y refresh (ADR-001, RNF-05). | **Emilio**: cookie de sesión HttpOnly de Better Auth, con inicio de sesión por `email` (`emilio/openapi.yaml`). Argumento (ADR-001, alternativa 1): `onrender.com` está en la Public Suffix List, así que una cookie no se comparte entre subdominios, y los tokens en cabeceras tienen "el riesgo de almacenarlos en el navegador". | JWT con access y refresh, inicio de sesión por `usuario`. **Contradice a Emilio:** su ADR-001 mantiene Better Auth y la cookie. El riesgo que él señala sigue abierto: Sebastián lo mitiga con el token de acceso solo en memoria y CSP (ADR-001, consecuencias negativas). |
| **El aviso se registra y se envía aparte** (D6) | Isaí: `Notificacion` (`Diagrama_clases.mmd`) y Notificaciones "desacopladas" (`Decisiones_diseno_clases.md`, decisión 3). Sebastián: "Transactional Outbox" con `Notificacion.enviada` (ADR-001, patrones). Emilio: `NotificacionPendiente` como outbox (ADR-001, decisión 3). | **Diego**: sin entidad. Guarda primero el estado y después solicita el envío, "de esta forma una falla del servicio de correo no revierte la modificación" (`decisiones_y_trazabilidad.md`, RF-12). Cumple RF-12-AC-2, pero el aviso fallido se pierde. Emilio lo dice de esa alternativa: "cumple el requisito solo si se guarda primero, y aun así pierde la notificación sin reintento" (ADR-001). | Tabla `notificacion` como outbox, con los campos de Emilio (`canal`, `intentos`, `error`). |
| **Desactivar servicios con `PATCH`, no con `DELETE`** | Isaí (`Revision_rest.md`, REST-05: "se evita `DELETE` porque el SRS exige desactivar, no borrar"), Sebastián y Emilio (`PATCH` con `activo`) | **Diego**: `DELETE /services/{serviceId}` como eliminación lógica idempotente (`diego/openapi.yaml`). | `PATCH {"activo": false}`. Con `DELETE` el servicio no se puede reactivar. |
| **Valores de estado en mayúsculas** | Isaí, Sebastián y Emilio: `RECIBIDO`, `EN_PROCESO`… | **Diego**: `Recibido`, `En proceso`… Sigue literalmente la forma en que el SRS los escribe (`SRS_equipo.md`, RF-03-AC-1 y RF-08). | Mayúsculas con guion bajo, que son los valores del `CHECK` de `esquema_bd.sql`. |
| **Lo administrativo se distingue por `security`, no por la ruta** | Diego, Isaí y Sebastián | **Emilio**: prefijo `/admin` para materializar las dos superficies de RNF-05 (`emilio/openapi.yaml`, descripción). | Sin prefijo. **Contradice a Emilio.** |

> **Correcciones al borrador.**
> - **Isaí no propone "seis servicios".** Propone cuatro servicios entre seis componentes lógicos; los otros dos son el frontend y el Gateway. Su propio ADR dice "cuatro servicios".
> - **Los otros tres no descartan los microservicios "con el mismo argumento".** Diego habla de complejidad y de un MVP "con un único negocio y un solo usuario administrador". Sebastián, de la cadena de disponibilidad (0.995³ ≈ 98.5 %) y de la necesidad de *sagas*. Emilio, de que no hay RNF de escalado, del administrador único y de la consistencia distribuida. Coinciden en parte, no en todo.
> - **El argumento a favor del entero no es de Sebastián.** Que es "más fácil de leer y es el valor por defecto de Django" no aparece en ningún archivo suyo.
> - **El ejemplo de la familia que comparte teléfono no está en los archivos de Isaí ni de Emilio.** Se quitó.
> - **"Idioma español, tres contra uno" no es un conflicto de fondo.** Pasa al párrafo de diferencias de nombre (sección 5).

---

## 4. Elementos que solo uno o dos propusieron

| Elemento | Quién | Qué aporta | Destino |
|---|---|---|---|
| **Historial de cambios de estado** | Isaí (`HistorialEstado`, `Diagrama_clases.mmd`) y Sebastián (`CambioEstado`, `diagrama_clases.puml`) | Los dos tienen los mismos campos: estado anterior, estado nuevo, fecha, `esCorreccion` y `motivo`. Es lo que hace auditable una corrección manual. Isaí lo justifica por "auditoría y trazabilidad" (`Decisiones_diseno_clases.md`, decisión 2). Emilio lo había dejado como hueco: "La corrección no deja historial [...] (pendiente documentado)" (`emilio/openapi.yaml`). | Adoptado (D3): tabla `historial_estado` y `GET /pedidos/{pedido_id}/cambios-estado`, que es aporte de Sebastián. |
| **Paginación de la lista de pedidos** | Isaí (`page`/`limit`, `Revision_rest.md`, REST-01) y Sebastián (`pagina`/`tamano_pagina`) | Agregarla después cambiaría el tipo de la respuesta de arreglo a objeto, y el frontend se rompería. | Adoptada con los nombres de Sebastián. |
| **Campo `cerrado` en el horario** | Isaí (`Diagrama_clases.mmd`) | Marca un día sin servicio sin borrar el registro. | Adoptado (D5). |
| **Tabla de transiciones permitidas** | Emilio (`TransicionEstado`, `diagrama_clases.puml`; ADR-001, "Preparación para recolección"). Sebastián usa un diccionario en código (ADR-001, patrón "State simplificado"). | Agregar estados de recolección sin reescribir la validación. | Descartada como tabla: las transiciones se validan en código (leyenda de `diagrama_clases_equipo.puml`). **Contradice a Emilio**, que la planteó en su ADR para preparar la recolección. |
| **Cabecera `Idempotency-Key`** | Emilio (obligatoria en pedidos y notas, `emilio/openapi.yaml`) y Sebastián (opcional en pedidos, `openapi.yaml` y `secuencia_flujo1.puml`). Isaí la deja como "mejora pendiente de aprobación" (`Decisiones_y_trazabilidad.md`). | Evita pedidos duplicados cuando la respuesta tarda. | Quitada: no hay tabla donde guardar la clave. **Contradice a Emilio.** |
| **Token de renovación** | Sebastián (`POST /auth/tokens/refresh`; ADR-001: acceso de 15 min y renovación de 8 h) | Define qué pasa cuando expira el token. | Adoptado, con `x-acceptance-criteria: []` porque ningún criterio del SRS lo respalda. |
| **Límite de consultas (429)** | Sebastián (ADR-001: táctica de RNF-03 y escenario E4, 30 consultas por minuto por IP) | Dificulta adivinar códigos de seguimiento. | Fuera del contrato (sección 6.9). |
| **`fecha_cierre` y `anonimizado` en el pedido** | Sebastián (`diagrama_clases.puml`, D3) y Emilio (`diagrama_clases.puml`) | Dan soporte a la conservación de 12 meses (RD-07). | Adoptados. |
| **`unidad` del servicio** | Sebastián (`diagrama_clases.puml`; en el contrato, enum `LIBRA`, `PIEZA`, `CARGA`) | Sin ella, el precio no dice si es por libra o por pieza. | Adoptada como columna obligatoria, pero como texto libre (sección 6.9). |
| **`descripcion` del servicio** | Isaí y Sebastián | Texto para el catálogo público. | Adoptada, opcional. |
| **Entidad `Negocio`** | Sebastián (`diagrama_clases.puml`) | Agrupa horarios y servicios bajo el negocio. | Descartada: el MVP tiene un solo negocio (leyenda del diagrama consolidado). |
| **Proceso programado** para el outbox y la purga de RD-07 | Sebastián: Cron Job de Render con `procesar_avisos` cada 10 minutos y `anonimizar_pedidos` diario (`diagrama_despliegue.puml`) | Emilio lo deja abierto entre dos opciones, un job externo o la ejecución oportunista (ADR-001, "Tarea periódica para RD-07"). | No afecta al contrato; pendiente con el stack (sección 7). |
| **Autenticación con `django.contrib.auth`** | Sebastián (ADR-001, tabla de módulos) | Reutiliza usuarios y hash de contraseñas de Django. | Choca con la tabla `administrador` propia: es el pendiente bloqueante 5 de `revision_sql.md`. |
| **Consulta de notas aparte del detalle** | Isaí (`GET /pedidos/{pedidoId}/incidencias`) y Sebastián (`GET /pedidos/{pedido_id}/notas`) | Una segunda vía de lectura. | Quitada: RF-09-AC-2 pide verlas "cuando consulta su detalle", y el detalle las incluye. |

> **Correcciones al borrador.**
> - **La entidad de notificación no es de "uno o dos".** La tienen tres (Isaí, Sebastián y Emilio), así que pasó a la sección 3.
> - **`Idempotency-Key` no es solo de Emilio.** Sebastián también la tiene, e Isaí la menciona como mejora pendiente.
> - **No hay ningún documento de Emilio que llame "deuda consciente" a la paginación.** Se quitó la afirmación.
> - **El historial no se justifica con la cita del borrador.** El borrador dice que el dueño declaró que su criterio de fracaso es "que el sistema muestre un estado que no corresponde a la realidad". Esa frase viene de la sesión simulada (`emilio/transcript_entrevista.md`, líneas 381–384), no del dueño real (sección 6.2). El historial sí tiene respaldo en la entrevista real: "history of the orders is also a must to keep a clean track" (`emilio/entrevista_cliente_real.md`, Sección 1, Pregunta 7).

---

## 5. Conflictos reales

### Diferencias de nombre

No son conflictos de fondo y se resolvieron en bloque.
- **Idioma de rutas y campos:** Diego usa inglés (`/orders`, `/services`, `/business-hours`) y los otros tres español.
- **Formato de los campos:** Sebastián usa `snake_case` (`nombre_cliente`), Isaí y Emilio `camelCase` en español (`nombreCliente`), y Diego `camelCase` en inglés (`receivedAt`).
- **Singular o plural:** `/seguimiento` (Isaí y Emilio) frente a `/seguimientos` (Sebastián). El recurso de notas se llama `notes` (Diego), `incidencias` (Isaí) o `notas` (Sebastián y Emilio).
- **Ruta base:** `/api` en Diego y Emilio, `/api/v1` en Isaí y Sebastián.

El contrato consolidado usa español, `snake_case` igual que las columnas de `esquema_bd.sql` (así los serializadores no traducen nombres), recursos en plural y `/api/v1`. **Contradice a Emilio**, que usaba `camelCase` y `/api`.

### C1 — Cómo se cambia el estado de un pedido

| | Propuesta | Archivo |
|---|---|---|
| Diego | `PUT /orders/{orderId}/status` con `mode` y `confirmCorrection`. Es idempotente: repetir no reenvía el aviso. | `diego/openapi.yaml`, `diego/revision_rest.md` |
| Isaí | `PUT /pedidos/{pedidoId}/estado` con `modo`, `confirmacionExplicita` y `motivo`, más un `POST .../cancelacion` aparte | `isai/Semana_seis/openapi.yaml`, `Revision_rest.md` (REST-03 y REST-04) |
| Sebastián | `POST /pedidos/{pedido_id}/cambios-estado`, que crea un registro de historial (201); pedir el estado actual responde 422 | `sebastian/.../openapi.yaml` |
| Emilio | `PUT /admin/pedidos/{pedidoId}/estado` con `modo: NORMAL \| CORRECCION_MANUAL` y `confirmacion`; la corrección no deja historial | `emilio/openapi.yaml` |

**Resolución.** `PUT /pedidos/{pedido_id}/estado` para cambiar el estado, incluida la cancelación, y `GET /pedidos/{pedido_id}/cambios-estado` para consultar el historial.

**Argumento:**
- El `PUT` lo propusieron tres y es idempotente: un reintento por red no tiene efecto adicional. Con el `POST` de Sebastián, el mismo reintento devuelve 422 y el frontend tendría que distinguirlo de un error real.
- Cada `PUT` que cambia el estado inserta un registro de historial, así que se conserva el fondo de la propuesta de Sebastián.
- La cancelación de Isaí se absorbe en el `PUT`. Con dos caminos para llegar a `CANCELADO`, uno sería idempotente y el otro respondería 409 al repetirse.

**Contradice a Emilio:** su corrección no dejaba historial. La resolución corrige el hueco que él mismo había dejado anotado como pendiente.

### C2 — La corrección manual

| | Confirmación explícita | Motivo |
|---|---|---|
| Diego | `confirmCorrection` | no existe el campo |
| Isaí | `confirmacionExplicita` | `motivo` |
| Sebastián | no existe el campo (`es_correccion: true` hace de confirmación) | `motivo` |
| Emilio | `confirmacion` | no existe el campo |

**Resolución.** `es_correccion`, `confirmacion` y `motivo`, y en una corrección son obligatorios los dos últimos.

**Argumento:**
- RF-08-AC-5 pide confirmación explícita.
- `historial_estado_motivo_ck` exige el motivo. Con los contratos de Diego o Emilio, el `INSERT` en el historial viola el `CHECK`.
- Solo Isaí tenía los dos datos.

**Contradice a Emilio.**

### C3 — Notas e incidencias

| | Modelo | Archivo |
|---|---|---|
| Diego | Una sola clase `NotaIncidencia` con `contenido`, sin tipo | `diego/diagrama_clases.puml`; ADR-001, decisión 2 |
| Isaí | Solo `Incidencia`; no modela notas generales | `Diagrama_clases.mmd` |
| Sebastián | Herencia `Nota <\|-- Incidencia`, con `severidad` en `Incidencia` | `diagrama_clases.puml` |
| Emilio | `NotaPedido` con enum `TipoNota {NOTA, INCIDENCIA}` | `emilio/diagrama_clases.puml` |

**Resolución.** La de Emilio (D4): una tabla `nota_pedido` con columna `tipo`.

**Argumento:**
- Cubre los cuatro casos con una sola tabla.
- La herencia de Sebastián exigiría una segunda tabla o una columna discriminadora.
- `severidad` se descartó porque ningún requerimiento la pide.
- El contrato de Diego no envía `tipo`, que es `NOT NULL`, así que su alta de notas fallaría.

### C4 — Horarios

| | Identificación | Día cerrado | Valores del día | Archivo |
|---|---|---|---|---|
| Diego | En el contrato, el día es la llave (`PUT /business-hours/{dayOfWeek}`); en su diagrama, `id: UUID` | `isOpen` | `monday`… | `diego/openapi.yaml`, `diego/diagrama_clases.puml` |
| Isaí | `id` propio (`PUT /horarios/{horarioId}`), sin operación de alta | `cerrado` | entero 1–7 | `isai/Semana_seis/openapi.yaml` |
| Sebastián | Sin `id`; `PUT /horarios` reemplaza la semana completa | el día omitido queda cerrado | entero 1–7 | `sebastian/.../openapi.yaml`, `diagrama_clases.puml` |
| Emilio | `id` propio, CRUD completo con `DELETE` | se borra el registro | `LUNES`… | `emilio/openapi.yaml`, `emilio/diagrama_clases.puml` |

**Resolución.**
- `id` propio y campo `cerrado` (D5).
- `dia_semana` es `UNIQUE`, y crear un horario para un día que ya tiene uno responde 409.
- Los valores van de `LUNES` a `DOMINGO`.
- Las operaciones son `POST /horarios` y `PATCH /horarios/{horario_id}`, sin `DELETE`.

**Argumento:**
- `cerrado` existe para marcar un día sin servicio sin borrar el registro, y eso no es compatible con el reemplazo de la semana de Sebastián ni con el `DELETE` de Emilio.
- De los cuatro valores, solo los de Emilio coinciden con el `CHECK`.

**Contradice a Emilio** en el `DELETE` y en la falta de `cerrado`.

### C5 — Resultado del aviso al marcar un pedido como listo

| | Propuesta | Archivo |
|---|---|---|
| Diego | `notificationStatus`: `sent`, `failed`, `skipped`, `not_applicable` | `diego/openapi.yaml`, `secuencia_flujo2.puml` |
| Isaí | Sin campo; el aviso se encola | `isai/Semana_seis/openapi.yaml` |
| Sebastián | `aviso_correo`: `GENERADO`, `SIN_CORREO`, `NO_APLICA` | `sebastian/.../openapi.yaml` |
| Emilio | Sin campo; outbox en la misma transacción | `emilio/openapi.yaml` |

**Resolución.** La de Sebastián.

**Argumento:** con outbox, en el momento de responder el aviso está `PENDIENTE`. Para responder `sent` o `failed`, la petición tendría que esperar al proveedor, y entonces una falla del proveedor bloquearía el cambio de estado, que es lo que prohíbe RF-12-AC-2.

### C6 — Forma de la lista de pedidos

| | Forma | Datos por fila | Archivo |
|---|---|---|---|
| Diego | arreglo plano | `id`, código, estado, fecha | `diego/openapi.yaml` |
| Isaí | `{items, page, limit, total}` | `id`, código, estado, fecha | `isai/Semana_seis/openapi.yaml` |
| Sebastián | `{resultados, total, pagina, tamano_pagina, siguiente, anterior}` | además nombre, `servicio_id` y precio | `sebastian/.../openapi.yaml` |
| Emilio | arreglo plano | el `Pedido` completo, con teléfono y correo | `emilio/openapi.yaml` |

**Resolución.** Objeto `{resultados, total, pagina, tamano_pagina}`. Cada fila trae `id`, `codigo_seguimiento`, `estado_actual`, `fecha_recepcion` y `nombre_cliente`.

**Argumento:**
- La paginación hay que fijarla desde el principio (sección 4).
- La lista no debe exponer teléfono ni correo (RNF-02); RF-07-AC-1 solo pide código y estado.
- `id` es necesario para abrir el detalle. Una primera versión del contrato lo omitió y se corrigió.

**Contradice a Emilio**, cuya lista devolvía datos personales en cada fila.

### C7 — Stack del backend

| | Propuesta | Archivo |
|---|---|---|
| Sebastián | Python 3.12, Django 5.2 LTS, DRF, simplejwt, PostgreSQL 16, Gunicorn y WhiteNoise en Docker, Render con plan pagado (≈ 7 USD el Web Service + ≈ 6 USD Postgres por mes) y Cron Job | ADR-002; `diagrama_despliegue.puml` |
| Emilio | Next.js (App Router), TypeScript, Prisma, Better Auth, PostgreSQL en Neon, Render | ADR-001, "Estilo" |
| Diego | No nombra lenguaje, framework, base de datos ni proveedor | `diego/decision_arquitectonica.md`, `diagrama_despliegue.puml` |
| Isaí | No nombra tecnología: "El motor y el proveedor se decidirán después"; el proveedor cloud está "aún por decidir" | ADR-001, "Propiedad de datos" e "Implicaciones" |

**Lo que coincidía:** los dos que nombraron un stack eligieron PostgreSQL.

**Lo que dejaba abierto Emilio y resolvía Sebastián:**
- **Plan de hosting.** Emilio deja "pendiente del equipo" elegir entre revisar RNF-01 o pagar un plan sin suspensión. No eligió el plan gratuito, como dice el borrador; dejó la decisión abierta.
- **Proceso programado.** Emilio lo deja con dos opciones a evaluar (ADR-001, "Tarea periódica para RD-07").

Sebastián resolvió los dos: un plan pagado, porque el gratuito "incumple RNF-01 y RNF-06" (ADR-002), y el Cron Job.

**Resolución.** Django con DRF y PostgreSQL 16. Es la premisa de `esquema_bd.sql` (`inspectdb`, `managed = False`) y de `openapi_equipo.yaml` (`snake_case` de DRF, decimales como cadena).

**Lo que no tiene fuente.** El borrador atribuye la decisión a un "acuerdo del equipo bajo el criterio 'lo más sencillo de aplicar y con más soporte'", con el argumento de que `ModelViewSet` resuelve un CRUD en unas diez líneas. **Ningún archivo de `insumos/` registra ese acuerdo** (sección 7).

**Contradice a Emilio.** Su ADR-001 mantiene Next.js, Prisma y Better Auth porque `stack_decision.md` exigía un solo lenguaje (TypeScript). Con la resolución, su ADR queda sustituido en tecnología, autenticación y despliegue. De él se conservan las decisiones de diseño: el tipo público separado, el outbox y la autorización cerca de los datos.

### C8 — Otros conflictos de contrato

| Punto | Propuestas | Resolución y argumento |
|---|---|---|
| **Montos y pesos** | Diego: `number` con `format: double`. Isaí: `number`. Sebastián: cadena decimal `"12.50"`. Emilio: `number` con `multipleOf: 0.01`. | Cadena decimal, como la serializa DRF. `double` puede perder precisión frente a `NUMERIC`. **Contradice a Emilio.** |
| **Fecha de recepción** | Sebastián: `format: date`. Los otros tres: `date-time`. | `date-time`: la columna es `TIMESTAMPTZ`, y con `date` se pierde la hora. |
| **Formato de errores** | Cuatro formas distintas: Diego `{code, message}` con `errors[]`; Isaí `{code, message, details[]}`; Sebastián `{codigo, mensaje, errores[]}`; Emilio `{codigo, mensaje}` con `campos[{campo, motivo, mensaje}]`. | El de Sebastián. El frontend lee los errores de una sola forma. **Contradice a Emilio**, que tenía un enum de motivos por campo. |
| **Alta de pedido** | Diego no acepta peso, precio ni instrucciones en el alta; los otros tres sí. | Se aceptan: la base lo permite y ahorra una llamada. |

---

## 6. Hallazgos de la consolidación

Estos hallazgos no son diferencias entre los cuatro diseños, sino problemas que solo aparecieron al juntarlos y contrastarlos con la base de datos y con la entrevista real. Son lo más importante del entregable: varios afectan a requerimientos que ya están en la línea base, no solo al diseño.

### 6.1 La entrevista con el cliente real no llegó al SRS del equipo

**Lo que se puede afirmar con los archivos:**
- `SRS_equipo.md` no menciona ninguna entrevista; una búsqueda de "entrevista" no da resultados.
- El SRS individual de Emilio, uno de sus insumos, dice basarse en la sesión simulada (`emilio/SRS_final.md`, líneas 4–7).
- En el registro de la sesión simulada, la "Sesión 2: Entrevista con el cliente real" quedó como **"Pendiente"**: "El stakeholder real no tuvo disponibilidad en la fecha de esta entrega" (`emilio/transcript_entrevista.md`, líneas 489–494).
- La entrevista real está ahora en `emilio/entrevista_cliente_real.md`.

> **Corrección al borrador.** El borrador dice que la entrevista "nunca entró al proyecto". Es demasiado fuerte: el ADR-001 de Emilio ya la usa. Habla de "herramienta de operación interna", de notificaciones "por correo o mensaje de texto", y en la sección de clases cita "la entrevista con el stakeholder real" para el registro de correos y la recolección. Lo que no ocurrió es que llegara al **SRS del equipo**. El propio ADR es incoherente: en "Información nueva del stakeholder" dice que la recolección es una "evolución", y en la sección de clases que es el "punto de partida del servicio", que es lo que dice la entrevista (Sección 2, "Alcance del servicio").

**Lo que la entrevista dice y la línea base contradice o no recoge**, con su efecto en lo consolidado:

| Entrevista real | Línea base y diseños | Efecto |
|---|---|---|
| La recolección y entrega a domicilio es el punto de partida (Sección 2, "Alcance del servicio"). | Fuera del MVP (`SRS_equipo.md`, RD-08). | `pedido` no tiene dirección y ningún RF la pide (`revision_sql.md`, pendiente 6). |
| Datos del cliente: nombre, **dirección**, teléfono y servicio (Sección 1, Pregunta 2). | RF-03 no pide la dirección. | Ídem. |
| Cada cliente elige entre correo y mensaje de texto (Sección 2, "Notificaciones"). | El MVP excluye SMS (`SRS_equipo.md`, sección 1.2). | `notificacion.canal` existe, pero el contrato siempre usa correo (pendiente 7). |
| Pide confirmación doble al marcar un pedido como "Listo" (Sección 2). | Ningún diseño la tiene; el contrato solo exige confirmación en las correcciones. | Sin decidir (sección 7). |
| El cobro es al inicio del servicio (Pregunta 2). | Los diseños calculan el precio final después de pesar. | No cambia el esquema, porque `precio_final` es opcional, pero sí el flujo. |
| Se usa en computadora o tableta (Pregunta 6). | RNF-04 prioriza el uso móvil. | No afecta al contrato. |
| No se modifica un pedido: se cancela y se crea otro (Sección 2). | Los diseños permiten editar datos operativos (RF-04). | Sin decidir. |
| Un solo usuario (Sección 2) frente a un nivel de acceso de empleado (Pregunta 6). | Un administrador (RD-06). | Contradicción sin resolver (Sección 6 de la entrevista; pendiente 8). |

### 6.2 Dos artefactos citan la sesión simulada como si fuera el cliente

1. **`diagrama_clases_equipo.puml`, leyenda D3. Corrección aplicada.** La frase venía de la sesión simulada, donde el agente hacía de dueño (`emilio/transcript_entrevista.md`, líneas 381–384). El historial tiene respaldo en la entrevista real, en la misma pregunta que da el criterio de éxito del dueño.

   | | Texto de D3 |
   |---|---|
   | **Decía** | "Resuelve el hueco de auditoría de las correcciones manuales, que el stakeholder señaló como su criterio de fracaso del sistema." |
   | **Dice ahora** | "Resuelve el hueco de auditoría de las correcciones manuales. El dueño pidió el historial ("history of the orders is also a must to keep a clean track") y su criterio de éxito es "no lost orders or unnotified customers" (insumos/emilio/entrevista_cliente_real.md, Sección 1, Pregunta 7)." |

2. **`conflictos_diseno_borrador.md`, sección 3.** Repite la misma atribución. No se corrigió porque es un insumo de este documento, no un entregable; este documento ya no la repite (sección 4).

**Por qué importa:** un argumento de diseño apoyado en lo que dijo un agente simulando al cliente puede presentarse como requisito del cliente.

### 6.3 Un requerimiento se perdió en la consolidación

RF-11 de `emilio/SRS_final.md` (línea 326), "Verificar la identidad del cliente al entregar el pedido", tenía tres criterios: verificar con el ticket, con nombre y teléfono, y rechazar la entrega si no coinciden. No tiene equivalente en `SRS_equipo.md`, aunque su sección 1.2 dice que el sistema debe "identificar al cliente" (línea 37).

Los índices de búsqueda por teléfono y nombre de `esquema_bd.sql` se apoyan en ese requerimiento, que no está en la línea base (`revision_sql.md`, sección 2.1 y pendiente 2).

### 6.4 La consolidación reasignó casi todos los IDs

Entre `emilio/SRS_final.md` y `SRS_equipo.md`, **solo RF-09, RNF-02 y RNF-03 conservan su significado** (`emilio/mapeo_ids_srs.md`). Por ejemplo:
- RF-11 es "verificar identidad" en uno y "administrar servicios, precios y horarios" en el otro;
- RD-07 es "ticket = etiqueta, no secuencial" en uno y "conservación 12 meses" en el otro;
- RNF-06 es "segundo dato de verificación" en uno e "integridad y persistencia" en el otro.

La regla adoptada es que una cita sin documento indicado se refiere a `SRS_equipo.md`.

Los cuatro `openapi.yaml` usan la numeración del equipo en todos sus `x-acceptance-criteria`. Se comprobó en todos los IDs, no por muestreo, así que el contrato consolidado no necesitó traducir IDs.

> **Corrección al borrador.** El borrador dice que el equipo renumeró "al consolidar los cuatro SRS individuales". El mapeo solo compara el SRS de Emilio con el del equipo, porque **los SRS individuales de Diego, Isaí y Sebastián no están en `insumos/`**. No se sabe si sus IDs también colisionan.

### 6.5 El dato de auditoría no llegaba a la API en ningún diseño

Ninguno de los cuatro `openapi.yaml` expone quién registró un pedido ni quién hizo un cambio de estado. En los diagramas, Diego, Isaí y Sebastián asocian `Administrador` con `Pedido`, pero ninguno con el historial. La asociación `Administrador → HistorialEstado` la agregó la consolidación, y su leyenda la deja "pendiente de confirmar con el equipo".

El contrato consolidado expone `administrador_id` en `GET /pedidos/{pedido_id}/cambios-estado` y en el detalle del pedido.

> **Corrección al borrador.** El borrador dice que `GET .../cambios-estado` es "el único lugar del contrato donde se expone `administrador_id`". También está en `PedidoDetalle`.

### 6.6 Ninguno de los cuatro contratos individuales habría funcionado contra la base

Al contrastar cada `openapi.yaml` con `esquema_bd.sql`, cada uno falla en al menos una operación central. Los fallos posibles son tres:
- un `INSERT` que viola `NOT NULL` o un `CHECK`;
- una cadena más larga que su columna;
- un valor que el `CHECK` no acepta.

En los tres casos Django lanza `IntegrityError` o `DataError` y el cliente recibe un 500.

| Spec | Lo que falla |
|---|---|
| **Diego** | El alta de servicio no envía `unidad` (`NOT NULL`). El alta de nota no envía `tipo` (`NOT NULL`). La corrección no envía `motivo` (`historial_estado_motivo_ck`). Los valores de estado (`Recibido`, `En proceso`) y de día (`monday`) no pasan sus `CHECK`. `weight` acepta 0 y `pedido_peso_positivo_ck` lo rechaza. |
| **Isaí** | El alta de servicio no envía `unidad`. `diaSemana` es un entero y el `CHECK` espera `LUNES`… |
| **Sebastián** | Todos los ids son enteros y las columnas son `UUID`. `dia_semana` es un entero. El patrón del teléfono admite 21 caracteres y la columna tiene 20. El detalle declara nombre y teléfono como `null` tras anonimizar, y las columnas son `NOT NULL`. `fecha_recepcion` es `date`. |
| **Emilio** | El alta de servicio no envía `unidad`. La corrección no envía `motivo`. El inicio de sesión es por `email`, columna que no existe. Las respuestas exigen `creadoEn` y `actualizadoEn`, que no tienen columna. |

**Además, en general:**
- Diego, Isaí y Sebastián validan los textos con `minLength: 1`, que acepta una cadena de espacios; los `CHECK (btrim(...) <> '')` la rechazan.
- Solo Sebastián declara `maxLength`.

**Por qué importa:** el esquema se escribió a partir del diagrama consolidado, no de ningún spec. Si se hubiera tomado un contrato individual como base, el backend habría heredado estos fallos. El contrato consolidado se cotejó columna por columna; el resultado está en `revision_sql.md`, sección 3.4.

> **Corrección al borrador.** El borrador decía que fallaban "tres de los cuatro". Fallan los cuatro: el borrador no contó los de Sebastián.

### 6.7 La unidad del peso no estaba fijada

| Diseño | Unidad del peso |
|---|---|
| Isaí | `pesoKg`, kilogramos (`Diagrama_clases.mmd`; `Decisiones_diseno_clases.md`, "Consideraciones") |
| Sebastián | `peso_lb`, libras (`openapi.yaml`) |
| Diego | No la fija, y lo dice: "El SRS actual no fija explícitamente la unidad utilizada para registrar el peso" (`diego/openapi.yaml`, `OrderOperationalUpdate`) |
| Emilio | No la indica |

`SRS_equipo.md` habla de "precio por libra", pero no fija una fórmula porque "los SRS individuales no presentaron una regla común confirmada" (línea 563).

La consolidación fijó libras con la entrevista real ($1.50/lb en wash & dry y $2.50/lb en wash & fold; Sección 1, Pregunta 2). Está en la nota de `Pedido` del diagrama y en el comentario de `pedido.peso`. El modelo de Isaí en kilogramos habría cobrado mal cada pedido.

### 6.8 Incoherencias dentro de los propios artefactos

- **Sebastián.** Su ADR-001 elige JWT "en la cabecera `Authorization`" y dice que por eso "no aplica el ataque CSRF". Su `diagrama_despliegue.puml`, en cambio, dibuja el panel con "cookie de sesión" y la conexión como "sesión + CSRF".
- **Emilio.** Su `openapi.yaml` declara `bearerAuth` y aclara que no está implementado. Su ADR-001 describe la recolección como "evolución" en una sección y como "punto de partida" en otra (sección 6.1).
- **Diego.** Su `diagrama_clases.puml` le da a `HorarioAtencion` un identificador propio (`+id: UUID`, línea 52), pero su `openapi.yaml` identifica el horario por el día (`PUT /business-hours/{dayOfWeek}`) y ningún esquema del contrato expone ese `id`.

**Correcciones aplicadas a `diagrama_clases_equipo.puml`.** El diagrama consolidado tenía dos errores propios, y le faltaba una restricción que el esquema sí implementa. Se corrigieron solo la leyenda y las notas; las clases, los atributos y las relaciones no cambiaron.

| Parte | Decía | Dice ahora | Motivo |
|---|---|---|---|
| Leyenda D5 | "El id propio lo tenían Isaí y Emilio" | "El id propio lo tenían Diego, Isaí y Emilio (3 de 4)" | El diagrama de clases de Diego también le da `id` al horario (ver el punto anterior). |
| Nota de `Pedido` | "El negocio cobra $1.50/lb en wash & dry y $2.50/lb en wash & fold (entrevista con el stakeholder). La unidad se declara en Servicio.unidad." | "La unidad se declara en Servicio.unidad." | El comentario equivalente ya se había quitado de `esquema_bd.sql` (`revision_sql.md`, sección 2.3), y los dos artefactos deben coincidir. La nota sigue diciendo que el peso está en libras. |
| Nota de `Servicio` (nueva) | No existía: el diagrama no indicaba ninguna restricción sobre `nombre`. | `nombre` es único entre los servicios activos, sin distinguir mayúsculas ni espacios en los extremos; en `esquema_bd.sql` es el índice único parcial `servicio_nombre_activo_uq`. | Cierra la incoherencia que registraba `revision_sql.md`. Es una nota y no un `{unique}` porque la unicidad es condicional y UML no la expresa bien. |

La corrección de D3 está en la sección 6.2.

### 6.9 Deudas conscientes del contrato consolidado

- **Sin `Idempotency-Key`.** La proponían Emilio y Sebastián, y Isaí la dejaba pendiente. No hay tabla donde guardar la clave con su respuesta. Se pierde la protección contra pedidos duplicados cuando el servidor tarda en responder.
- **Sin límite de consultas (429).** Fue decisión de quien consolidó al escribir el contrato, y no tiene otro respaldo documentado. El contrato se aparta así del ADR-001 de Sebastián, que lo liga a RNF-03 con el escenario E4.
- **`servicio.unidad` sin `CHECK`.** Enumerar los valores exige decidir si habrá servicios por pieza o por carga, y ni el SRS ni la entrevista lo definen (`revision_sql.md`, sección 3.5).
- **Servicio inactivo validado solo en código.** El contrato rechaza un pedido con un servicio inactivo, pero la base lo acepta.
- **Formato de hora.** El `TimeField` de DRF devuelve `HH:MM:SS` por defecto y el contrato dice `HH:MM`. Hay que fijar el formato en el serializador.

> **Corrección al borrador.**
> - **El 429 no está en el ADR-002 de Sebastián**, como dice el borrador, sino en su ADR-001: táctica de RNF-03 y escenario E4.
> - **"Este entregable excluye explícitamente la seguridad en los endpoints" no tiene fuente.** No hay ningún enunciado de la actividad en la carpeta que lo diga, así que se quitó como argumento.

---

## 7. Qué quedó pendiente de decidir con el equipo

**Bloqueantes para la Parte 2** (`revision_sql.md`, sección 8):

1. **Confirmar la asociación `Administrador → HistorialEstado`** (pendiente 4). No estaba en ningún diagrama individual (sección 6.5).
2. **Tabla `administrador` propia o `django.contrib.auth`** (pendiente 5). Sebastián proponía `django.contrib.auth` con simplejwt (ADR-001, tabla de módulos); el diagrama consolidado y el esquema tienen tabla propia.

**Decisiones de arquitectura sin registrar:**

3. **Registrar la elección de Django con DRF.** Es la premisa de todo lo consolidado, pero no hay ningún archivo que documente la decisión ni su argumento (C7). Hace falta un ADR del equipo que sustituya en tecnología a los ADR de Emilio e Isaí.
4. **Plan de hosting frente a RNF-01.** Sebastián eligió un plan pagado y Emilio lo dejó abierto (C7).
5. **Proceso programado** para el outbox y la purga de RD-07. Hay que adoptar el Cron Job de Sebastián o elegir una de las opciones de Emilio.
6. **Límite de consultas (429) y `Idempotency-Key`** (sección 6.9). Hay que decidir si vuelven al contrato y, en el caso de la clave, dónde se guarda.

**Requerimientos que la entrevista real reabre** (sección 6.1):

7. Dirección del cliente y alcance de la recolección (pendiente 6 de `revision_sql.md`).
8. Canal de notificación elegido por el cliente (pendiente 7).
9. Número de usuarios y nivel de acceso de empleado (pendiente 8).
10. Confirmación doble al marcar "Listo".
11. Restituir o descartar la verificación de identidad al entregar, el requerimiento perdido (sección 6.3).
12. Valores de `servicio.unidad` (sección 6.9).
13. **Modelo de cliente.** El ADR-001 de Emilio deja la decisión de no tener entidad `Cliente` como "provisional", porque la recolección y los correos promocionales exigen un cliente que persista entre pedidos. La consolidación la mantuvo (D1); hay que revisarla si se aceptan los puntos 7 y 8.
