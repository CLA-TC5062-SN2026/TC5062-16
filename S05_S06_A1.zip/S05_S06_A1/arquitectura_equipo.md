# ADR-EQ-001: Arquitectura del equipo — LaundryDesk

**Actividad:** S05-S06-A1, Parte 0
**Fecha:** 2026-10-24
**Estado:** Propuesto para aprobación del equipo. Solo el stack (sección 3.3) fue acordado por el equipo, y ese acuerdo se tomó fuera de cualquier ADR (ver el hallazgo de la sección 3.3).
**Consolida:** Emilio
**Formato:** Architecture Decision Record (Nygard, 2011), con la estructura del ADR de Sebastián.
**Supersede** (los documentos anteriores no se modifican; la trazabilidad queda aquí):
- **Restricción de un solo lenguaje (TypeScript) de `stack_decision.md`** (entregable cerrado de S01). La sustituye la elección de Python (secciones 1.1 y 3.3).
- **Stack del ADR-001 de Emilio:** Next.js (App Router), TypeScript, Prisma, Better Auth, PostgreSQL en Neon. Lo sustituyen Django 5.2 LTS, DRF y PostgreSQL 16 (sección 3.3). Del despliegue en Render, solo queda sin decidir el plan (pendiente 2).
- **Autenticación del ADR-001 de Emilio:** la cookie de sesión de Better Auth. La sustituye JWT con access y refresh (sección 3.4).
- **Separación de superficies del ADR-001 de Emilio:** el prefijo `/admin`. La sustituyen los permisos por vista (sección 3.5).
- **Tabla de transiciones del ADR-001 de Emilio** (`TransicionEstado`). La sustituye un diccionario en código (sección 4).
- **Estilo del ADR-001 de Isaí:** microservicios con API Gateway. Lo sustituye una sola unidad desplegable con módulos que son dueños de sus datos (secciones 3.1 y 3.2).
- **Estilo de los ADR-001 de Diego, Sebastián y Emilio.** Quedan absorbidos, porque los tres coinciden con la decisión del equipo (sección 3.1).
- **ADR-002 de Sebastián, solo en el framework, la API y la base de datos.** El resto de sus piezas no se ratificó y sigue pendiente (pendiente 4).

**ADR individuales que consolida** (las rutas son relativas a `insumos/`):

| Integrante | Archivo | Decisión individual |
|---|---|---|
| Diego | `diego/decision_arquitectonica.md` (ADR-001, 2026-10-10) | Cliente-servidor con separación por capas |
| Isaí | `isai/Semana seis 2/Decision_arquitectonica.md` (ADR-001, 2026-10-10, S04_A1) | Cliente-servidor basado en microservicios |
| Sebastián | `sebastian/decision_arquitectonica.md` (ADR-001 y ADR-002, este del 2026-10-09) | Capas + cliente-servidor con API REST, desplegado como monolito modular Django |
| Emilio | `emilio/decision_arquitectonica.md` (ADR-001, 2026-10-06) | Monolito modular en capas con Next.js |

Las diferencias entre los cuatro diseños y cómo se resolvieron están en `diferencias_diseno.md`. Este documento toma de ahí las resoluciones y solo registra las que son de arquitectura.

> **Resumen.**
> - **Estilo:** capas dentro de un esquema cliente-servidor con API REST, desplegado como **una sola unidad** con cuatro módulos de límites explícitos. Cada módulo es dueño de sus tablas, como pedía Isaí, pero sin API Gateway ni servicios separados.
> - **Stack:** Django 5.2 LTS, Django REST Framework y PostgreSQL 16, la propuesta del ADR-002 de Sebastián. **El equipo lo acordó en el chat y no quedó en ningún ADR hasta este documento.**
> - **Contradice** el estilo del ADR de Isaí, y el stack y la autenticación del ADR de Emilio, que es quien consolida. Los argumentos están en cada punto.
> - **Queda abierto** casi todo lo que el acuerdo del stack no cubrió: hosting, proceso programado, frontend, proveedor de correo y la tabla de administradores. Son 14 decisiones pendientes (sección 6), y una de ellas bloquea la Parte 2.

---

## 1. Contexto

### 1.1 Restricciones del equipo y del proyecto

| Restricción | Fuente |
|---|---|
| Cuatro estudiantes con unas 8–9 horas por semana cada uno y un horizonte de 12 semanas. | ADR-001 de Sebastián, "Restricciones del equipo" |
| El lenguaje que domina el equipo es **Python**. | ADR-001 de Sebastián. **Choca con el ADR de Emilio**, que mantenía la restricción de `stack_decision.md` de usar un solo lenguaje, TypeScript. El acuerdo del stack (sección 3.3) la resolvió a favor de Python. |
| La actividad pide valorar la viabilidad de la implementación por **un desarrollador**. | ADR-001 de Isaí, "Contexto" |
| Proceso *spec-first*: el contrato OpenAPI se escribe antes que el código, y las pruebas se derivan de él. | ADR-001 de Sebastián. Hoy el contrato es `openapi_equipo.yaml`. |
| Presupuesto mínimo: es una lavandería de pueblo y un proyecto académico. | ADR-001 de Sebastián. Emilio advierte que el costo deja de ser cero en cuanto se envía correo a clientes (ADR-001, "Costo real de las notificaciones"). |
| Un solo administrador y sin cuentas de cliente. | `SRS_equipo.md`, RD-05, RD-06 y sección 2.4. Lo citan los cuatro ADR. |
| Fuera del MVP: pagos en línea, SMS, recolección a domicilio e integración con las máquinas. | `SRS_equipo.md`, sección 2.4 y RD-08. ADR-001 de Diego, "Contexto". |
| `esquema_bd.sql` se escribe primero y el backend se genera con `inspectdb` (`managed = False`). | No viene de ningún ADR: es una decisión de esta actividad, registrada en `revision_sql.md`, sección 3.4. |

### 1.2 Requerimientos no funcionales que condicionan la arquitectura

| RNF (`SRS_equipo.md`) | Qué exige | Qué le pide a la arquitectura |
|---|---|---|
| **RNF-01** Disponibilidad | 99 % mensual durante el horario de operación | Pocas piezas en la ruta crítica (Sebastián) y un hosting que no suspenda la aplicación por inactividad (Emilio y Sebastián). |
| **RNF-02** Datos personales | La consulta pública no muestra teléfono, correo, instrucciones ni notas | Controlar los campos de cada respuesta pública; los cuatro ADR o sus contratos tienen un tipo público reducido. |
| **RNF-03** Código de seguimiento | Único y no predecible | Generador aleatorio criptográfico y unicidad en la base de datos (Emilio, Isaí y Sebastián). |
| **RNF-04** Usabilidad móvil | Interfaz adaptable; el dueño no toca código, configuración ni base de datos | Un panel administrativo con backend (Emilio) e interfaz responsiva (Isaí y Sebastián). |
| **RNF-05** Control de acceso | Toda función administrativa exige sesión; lo público, separado de lo administrativo | Un mecanismo de autenticación y una separación verificable entre lo público y lo administrativo (los cuatro). |
| **RNF-06** Integridad | Una falla externa no pierde pedidos ni revierte cambios | Transacciones en la base de datos y un aviso desacoplado del cambio de estado (Emilio, Isaí y Sebastián). |
| Sin RNF de escalabilidad | El SRS no define carga, concurrencia ni escalado | Ningún requerimiento justifica distribuir el sistema (Emilio, ADR-001). |

**Requerimientos de dominio con efecto en la arquitectura:**
- **RD-07:** anonimizar los datos 12 meses después del cierre exige una tarea periódica (Emilio, ADR-001).
- **RD-08:** la recolección exigirá estados nuevos, y el flujo de estados debe poder extenderse (Emilio y Sebastián).

### 1.3 Información del cliente real que la línea base no recoge

La entrevista con el dueño (`emilio/entrevista_cliente_real.md`) contradice partes de la línea base:
- el sistema es una herramienta de operación interna;
- la recolección es el punto de partida del servicio;
- cada cliente elige entre correo y mensaje de texto.

Esa información no llegó a `SRS_equipo.md` (`diferencias_diseno.md`, sección 6.1). Este ADR decide sobre la línea base vigente, y lo que la entrevista abre queda en la sección 6. El ADR de Emilio ya pedía que la arquitectura pudiera incorporar SMS y recolección "sin rehacerse" (ADR-001, "Información nueva del stakeholder").

---

## 2. Alternativas consideradas

### 2.1 Lo que propuso cada integrante

| Integrante | Estilo elegido | Alternativas que evaluó y descartó |
|---|---|---|
| **Diego** | Cliente-servidor con separación por capas: presentación, aplicación y dominio, y persistencia. El backend es la única capa con acceso a la base de datos. | MVC monolítico, por menor separación entre frontend y API. Microservicios, porque son "excesivos para un MVP con un único negocio y un solo usuario administrador". |
| **Isaí** | Cliente-servidor basado en microservicios, con API Gateway y cuatro servicios (Identidad, Pedidos, Catálogo y Notificaciones), cada uno dueño de sus datos. Lo implementaría de forma incremental. | Monolito modular en capas, que su propia tabla de *trade-offs* califica de complejidad "baja a media" y adecuación "alta" a un desarrollador. |
| **Sebastián** | A: capas + cliente-servidor con API REST y frontend ligero, desplegado como monolito modular Django. | B: SPA React y API por separado. C: páginas MVT sin API, que incumple el proceso *spec-first*. D: microservicios. E: orientada a eventos; de ella toma solo la idea local del aviso después del *commit*. |
| **Emilio** | Monolito modular en capas, una sola unidad desplegable en tres niveles físicos, con Next.js. | SPA con API REST separada, por dos servicios que se suspenden y el problema de cookies entre subdominios de `onrender.com`. Supabase, por el riesgo sobre RNF-02 en las políticas RLS. Microservicios. |

### 2.2 Los cuatro ejes de la decisión

| Eje | Diego | Isaí | Sebastián | Emilio |
|---|---|---|---|---|
| Unidades desplegables | Una (ADR-001, "Desventajas") | Varias (Gateway y servicios) | Una | Una |
| Módulos explícitos | Capas, sin módulos por tema | Servicios por capacidad de negocio | Módulos por tema y capas | Módulos por tema y capas |
| Tecnología | No la nombra | "El motor y el proveedor se decidirán después" | Django, DRF y PostgreSQL 16 (ADR-002) | Next.js, Prisma, Better Auth y PostgreSQL en Neon |
| Notificación | Integración "separada de la lógica principal" | Asíncrona o con reintentos desacoplados "cuando se implemente" | Outbox y envío después del *commit* | Outbox y adaptador por canal |

Tres de los cuatro eligieron una sola unidad desplegable. Isaí es el único que eligió microservicios, aunque su ADR los matiza: "evitando añadir infraestructura distribuida que aún no se necesite".

---

## 3. Decisión

### 3.1 Estilo y forma de despliegue

**Estilo: arquitectura en capas dentro de un esquema cliente-servidor.** El navegador se comunica con el backend solo a través de una API REST JSON versionada (`/api/v1`).
- **De dónde viene:** de Diego, Sebastián y Emilio. Los tres eligen capas y cliente-servidor. La API REST versionada es de Sebastián, y Diego también separa frontend y backend con una "API web".

**Despliegue: una sola unidad desplegable** que contiene los cuatro módulos de la sección 3.2.
- **De dónde viene:** de Diego, Sebastián y Emilio.
- **Contradice el ADR de Isaí.**
  - **Lo que Isaí eligió:** microservicios con Gateway y despliegue por servicio. Su argumento es la separación por capacidad de negocio y la evolución independiente.
  - **Por qué no se adopta:**
    - Ningún RNF exige escalar por partes. Lo dice Emilio y lo reconoce la propia tabla de Isaí.
    - Hay un solo administrador.
    - Una cadena de tres servicios al 99.5 % deja la disponibilidad en ≈ 98.5 %, por debajo del 99 % de RNF-01 (ADR-001 de Sebastián, tabla de RNF).
    - La consistencia entre pedido y aviso (RNF-06) se volvería un problema distribuido (Emilio y Sebastián).
    - La propia tabla de Isaí califica su opción como de adecuación "moderada a baja" para un desarrollador.
  - **Lo que se conserva de Isaí:** los mismos límites, como módulos (sección 3.2).
  - **Lo que se pierde:** el Gateway, el despliegue independiente y el escalado por servicio.

### 3.2 Módulos y propiedad de datos

Cuatro módulos con límites explícitos. Los nombres coinciden en los ADR de Isaí (como servicios), Sebastián y Emilio. Diego los menciona como posible división en su alternativa de microservicios: "autenticación, pedidos, configuración y notificaciones".

| Módulo | Responsabilidad | RF | Tablas de las que es dueño (`esquema_bd.sql`) | Origen |
|---|---|---|---|---|
| `catalogo` | Servicios, precios y horarios | RF-01, RF-11 | `servicio`, `horario_atencion` | Isaí (Catálogo), Sebastián y Emilio (`catalogo`) |
| `pedidos` | Registro, datos operativos, código, estados, historial, notas y cancelación | RF-03 a RF-10 | `pedido`, `historial_estado`, `nota_pedido` | Isaí (Pedidos), Sebastián y Emilio (`pedidos`) |
| `notificaciones` | Outbox, envío y reintentos por canal | RF-12 | `notificacion` | Isaí (Notificaciones), Sebastián y Emilio (`notificaciones`) |
| Autenticación | Administrador, credenciales y tokens | RF-02 | `administrador`, o las tablas de `django.contrib.auth` (pendiente 1) | Isaí (Identidad), Sebastián (autenticación con `django.contrib.auth`) y Emilio (`auth`) |

**Propiedad de datos por módulo.** Es la regla de Isaí: "cada servicio será responsable de sus datos [...] se evitarán accesos directos entre servicios a tablas ajenas" (ADR-001, "Propiedad de datos"). En una sola unidad se aplica así:
- **Escritura.** Solo el módulo dueño escribe en sus tablas.
- **Lectura y cambios desde otros módulos.** Un módulo que necesita datos de otro llama a sus funciones de servicio, no consulta sus tablas con el ORM. Es la misma regla que fijan Emilio ("Las rutas de API y las páginas llaman a esas funciones y no consultan Prisma directamente") y Sebastián ("las vistas de la API solo llaman a servicios de aplicación").
- **Una sola base de datos.** Isaí ya admitía "un mismo servidor de base de datos con esquemas separados" en desarrollo local.

> **Contradice a Isaí en un punto.** Isaí pedía que las asociaciones entre servicios fueran solo por identificador, "**no** mediante claves foráneas entre bases de datos de servicios distintos" (`Decisiones_diseno_clases.md`). `esquema_bd.sql` sí tiene llaves foráneas entre módulos: `pedido.servicio_id → servicio` y `pedido.administrador_id → administrador`, con `ON DELETE RESTRICT`.
> - **Argumento:** con una sola base de datos, la integridad referencial la garantiza PostgreSQL sin código adicional (RNF-06), y el `RESTRICT` impide borrar un servicio que un pedido referencia (RF-11-AC-3).
> - **Costo:** si algún módulo se extrae después, esas llaves foráneas habría que sustituirlas por identificadores y contratos, que es lo que Isaí proponía desde el principio.

### 3.3 Stack

| Pieza | Decisión | Origen |
|---|---|---|
| Framework | **Django 5.2 LTS** | ADR-002 de Sebastián; acuerdo del equipo |
| API | **Django REST Framework** | ADR-002 de Sebastián; acuerdo del equipo |
| Base de datos | **PostgreSQL 16** | ADR-002 de Sebastián y ADR-001 de Emilio, que eligió PostgreSQL con otro stack; acuerdo del equipo |
| Acceso a datos | ORM de Django sobre tablas existentes: `inspectdb` y `managed = False` | Decisión de esta actividad (sección 1.1), no de un ADR |

> **Hallazgo: el stack se decidió fuera de cualquier ADR.** El equipo acordó Django con DRF y PostgreSQL 16 **en el chat del equipo**, y la decisión no quedó en ningún ADR hasta este documento.
> - **Los cuatro ADR individuales no coinciden.** El de Emilio fija Next.js. El de Isaí dice que "el motor y el proveedor se decidirán después". El de Diego no nombra tecnología. Solo el ADR-002 de Sebastián propone el stack que se adoptó.
> - **El criterio del acuerdo.** Según el borrador de quien consolida (`emilio/conflictos_diseno_borrador.md`, C4), el criterio fue "lo más sencillo de aplicar y con más soporte", con el argumento de que `ModelViewSet` y `ModelSerializer` de DRF resuelven el CRUD de una entidad en unas diez líneas. No hay otro registro escrito del acuerdo.
> - **Por qué es un hallazgo y no un detalle:**
>   - `esquema_bd.sql` (`inspectdb`), `openapi_equipo.yaml` (`snake_case` de DRF, decimales como cadena) y la Parte 2 dependen de esta decisión.
>   - Hasta este documento, el único ADR vigente que nombraba tecnología era el de Emilio, y decía otra cosa.
>   - Además, **el acuerdo cubrió solo el framework, la API y la base de datos.** El resto del ADR-002 de Sebastián (frontend, servidor de aplicación, empaquetado, hosting, correo) no se ratificó y queda en la sección 6.

**Argumento a favor del stack**, del ADR-002 de Sebastián:
- **Python** es el lenguaje que domina el equipo.
- **Django** trae ORM, usuarios y hash de contraseñas.
- **DRF** aporta serializadores, permisos, paginación y límite de solicitudes.
- **FastAPI** se descartó porque genera la especificación desde el código (*code-first*), y aquí el contrato se escribe primero.
- **PostgreSQL** da transacciones para RNF-06 y `SKIP LOCKED` para la cola de avisos.

> **Contradice el ADR de Emilio (quien consolida).**
> - **Lo que fijaba:** Next.js (App Router), TypeScript, Prisma, Better Auth, PostgreSQL en Neon y Render. Su argumento era la restricción de un solo lenguaje de `stack_decision.md`; el propio ADR aclara que "no la revisa".
> - **Por qué cae:** el criterio del acuerdo y la restricción de Python del ADR de Sebastián la sustituyen.
> - **Lo que se pierde de Emilio:** todo lo que dependía de Next.js. Eso incluye la decisión de verificar la autorización fuera del middleware, motivada por CVE-2025-29927 de Next.js. Su principio general, no apoyar la autorización solo en una capa, se discute en el pendiente 9.
>
> **Para Isaí no es una contradicción:** resuelve lo que su ADR dejaba abierto.

### 3.4 Autenticación

**JWT Bearer con token de acceso y de renovación.** El administrador inicia sesión con `usuario` y contraseña.
- **De dónde viene:** del ADR-001 de Sebastián (RNF-05) y de los contratos de Diego e Isaí, que también usan Bearer JWT. Está fijado en `openapi_equipo.yaml` (`POST /auth/tokens` y `POST /auth/tokens/refresh`).

> **Contradice el ADR de Emilio (quien consolida).**
> - **Lo que proponía:** la cookie de sesión HttpOnly de Better Auth.
> - **Su argumento:** que los tokens en cabeceras tienen "el riesgo de almacenarlos en el navegador" (ADR-001, alternativa 1).
> - **Por qué no se adopta:**
>   - Better Auth es de Node, y el acuerdo del stack lo excluye.
>   - Con el token en la cabecera `Authorization`, el ataque CSRF no aplica (ADR-001 de Sebastián, RNF-05).
>   - El proceso *spec-first* del curso pide Bearer JWT (ADR-001 de Sebastián, restricciones).
> - **El riesgo que Emilio señaló sigue siendo real.** Sebastián lo mitiga con el token de acceso solo en memoria y de corta duración, más una política CSP, pero esa mitigación depende del frontend, que no está decidido (pendiente 5).

### 3.5 Capas

Cuatro capas, con dependencias que solo van hacia abajo. Vienen del ADR-001 de Sebastián, y coinciden con las tres de Diego y las de Emilio.

| Capa | Contenido | Equivalente en Diego | Equivalente en Emilio |
|---|---|---|---|
| 1. Presentación | Vistas y serializadores de DRF; en el navegador, las páginas | Presentación | Presentación y rutas de API |
| 2. Servicios de aplicación | Casos de uso; abren la transacción y coordinan | Aplicación y dominio | Funciones de servicio de cada módulo |
| 3. Dominio | Modelos y reglas: transiciones, cancelación, generación del código | (incluido en la anterior) | Dominio |
| 4. Infraestructura | ORM sobre PostgreSQL y adaptadores de proveedores externos | Persistencia | Acceso a datos (Prisma) |

**Separación entre lo público y lo administrativo (RNF-05).** La API pública y la administrativa usan permisos y serializadores distintos, pero comparten la ruta base.
- **De dónde viene:** de Sebastián (`api.publica` y `api.admin`, ADR-001), y está fijado en el contrato: todo lo administrativo exige token, y lo público declara `security: []`.

> **Contradice el ADR de Emilio (quien consolida).** Emilio separaba las dos superficies con el prefijo `/admin` en la ruta. El contrato del equipo las separa por `security` (`diferencias_diseno.md`, sección 3). El argumento es que la separación queda en los permisos de cada vista, verificables con pruebas: cualquier endpoint administrativo sin token responde 401, que es el escenario E2 de Sebastián.

---

## 4. Patrones de diseño adoptados

| Patrón | Dónde se aplica | De qué ADR viene |
|---|---|---|
| **API REST con contrato *spec-first*** | `openapi_equipo.yaml` ↔ vistas de DRF | Sebastián (ADR-001, patrones). Isaí (APIs HTTP/REST) y Diego (API web) coinciden en la API REST. |
| **Tipo de lectura público separado** (DTO o serializador) | `SeguimientoPublico` en el contrato; serializador propio que selecciona solo esos campos | Emilio (ADR-001, decisión 2, y "Decisiones de diseño sobre el modelo de clases", punto 2) y Sebastián (ADR-001, patrón DTO/Serializer y escenario E3). Isaí pide "exposición limitada de datos" (ADR-001, Servicio de Pedidos). |
| **Service Layer** | Funciones de servicio por módulo | Sebastián (ADR-001) y Emilio ("Cada módulo expone funciones de servicio"). Diego asigna esa coordinación a su capa de aplicación. |
| **Transiciones como tabla en código** (State simplificado) | Un diccionario `{estado: estados permitidos}` en el dominio de `pedidos` | Sebastián (ADR-001: "Se descarta el patrón State completo [...] por ser excesivo para cinco estados"). |
| **Transactional Outbox** | Tabla `notificacion`: el aviso se inserta en la misma transacción que el cambio de estado | Sebastián (ADR-001, con `Notificacion.enviada`) y Emilio (ADR-001, decisión 3, `notificacion_pendiente`). Isaí pide reintentos desacoplados. Los campos `canal`, `intentos` y `error` son de Emilio. |
| **Bloqueo `SELECT … FOR UPDATE SKIP LOCKED`** | El proceso que toma los avisos pendientes; índice parcial `notificacion_pendiente_idx` | Sebastián (ADR-001, control de concurrencia del outbox). |
| **Adapter / Gateway** para proveedores externos | Una interfaz de envío con un adaptador por proveedor | Sebastián (`EnviadorCorreo`, con implementación real y de consola para pruebas) y Emilio (`CanalNotificacion`, con un adaptador por canal, que prepara SMS). Diego mantiene la integración "separada de la lógica principal". |
| **Active Record** (ORM de Django), sin Repository | Acceso a datos | Sebastián (ADR-001: Repository "duplicaría código sin beneficio"). |

> **Contradice el ADR de Emilio (quien consolida): la tabla de transiciones.** Emilio proponía las transiciones como una **tabla en la base de datos** (`TransicionEstado`), para que los estados de recolección se agregaran "sin reescribir la lógica de validación" (ADR-001, "Preparación para recolección").
> - **Se adopta el diccionario en código de Sebastián**, que ya descartó la tabla `diagrama_clases_equipo.puml`.
> - **Argumento:** con el diccionario se obtiene el mismo beneficio. Sebastián lo justifica con el principio abierto/cerrado: "agregar un estado [...] es agregar una entrada a la tabla de transiciones, no reescribir la lógica" (ADR-001, SOLID). Y se evita una tabla de configuración que el administrador no edita.
> - **Lo que se pierde:** agregar un estado exige desplegar código, no solo insertar filas.

> **Contradice la práctica de Diego**, no su ADR. Su ADR solo exige que una falla del correo no pierda ni revierta información guardada. Su `decisiones_y_trazabilidad.md` y su diagrama de secuencia, en cambio, envían el correo de forma síncrona después de guardar. Con el outbox, el aviso fallido se reintenta en lugar de perderse: "cumple el requisito solo si se guarda primero, y aun así pierde la notificación sin reintento" (ADR-001 de Emilio).

**Patrón de Sebastián sin decidir: Observer vía *post-commit*.** En su diseño, `transaction.on_commit()` intenta enviar el aviso en cuanto se confirma el cambio de estado, y la tarea programada reintenta los fallidos (ADR-001, patrones). El equipo no lo ha adoptado ni descartado (pendiente 14).

**Tácticas por RNF**, tomadas del ADR-001 de Sebastián salvo donde se indica:
- **RNF-01:** pocas piezas en la ruta crítica.
- **RNF-02:** serializador público con los campos permitidos y una prueba que lo verifica.
- **RNF-03:** código generado con `secrets`, como proponen también Emilio e Isaí, más la unicidad en la base de datos (`pedido_codigo_seguimiento_uq`).
- **RNF-05:** JWT y permisos en toda la API administrativa.
- **RNF-06:** transacciones ACID y outbox.

---

## 5. Consecuencias

### 5.1 Positivas

- **Una sola unidad desplegable y un solo lenguaje.** Es menos infraestructura que revisar para un equipo con 8–9 horas por semana (Sebastián y Emilio).
- **La consistencia entre pedido y aviso se resuelve con una transacción local** de PostgreSQL, sin infraestructura adicional (Emilio).
- **Los módulos con dueño de datos permiten extraer un servicio después** sin rehacer el dominio, que es lo que Isaí buscaba con los microservicios. Diego ya preveía que "algunos módulos podrían requerir extracción hacia servicios independientes".
- **El proveedor de correo se cambia o se agrega SMS sin tocar `pedidos`,** gracias al adaptador (Emilio y Sebastián).
- **El contrato es la frontera entre frontend y backend,** así que los dos pueden avanzar en paralelo y las pruebas se derivan de él (Sebastián).
- **El CRUD de cada entidad sale de DRF** con poco código, que es el argumento del acuerdo del stack.

### 5.2 Negativas y cómo se mitigan

| Consecuencia | Mitigación | Origen |
|---|---|---|
| La modularidad no la impone el framework: sin revisión, los módulos se acoplan, por ejemplo con una vista que consulta tablas de otro módulo. | Las vistas solo llaman a servicios de aplicación; ningún módulo consulta tablas ajenas; se revisa en cada Pull Request. | Emilio y Sebastián; la regla de tablas ajenas es de Isaí. |
| El backend es un punto único de falla (RNF-01). | Reinicio automático del contenedor y despliegue fuera del horario de operación (escenario E5). El plan de hosting está sin decidir (pendiente 2). | Diego (la desventaja); Sebastián (la mitigación). |
| Escala solo como bloque. | Con la carga supuesta no es un problema; los límites de módulo permiten extraer uno si hace falta. | Sebastián y Diego. |
| Una respuesta JSON puede exponer más de lo que la pantalla muestra (RNF-02). | Serializadores explícitos por caso de uso, nunca "todos los campos", y una prueba sobre la respuesta pública. | Sebastián; Emilio por la misma razón, con su tipo `PedidoPublico`. |
| Un token JWT guardado en el navegador puede leerlo un script inyectado (XSS). | Token de acceso en memoria y de corta duración, más CSP. Depende de los pendientes 5 y 8. | Sebastián; el riesgo lo señaló Emilio. |
| El reintento puede enviar un aviso duplicado si se perdió la respuesta del proveedor. | Es aceptable para un aviso de "pedido listo". Si el proveedor lo permite, se usa el `id` del aviso como clave de idempotencia. | Sebastián. |
| Las llaves foráneas entre módulos los acoplan en la base de datos. | Se aceptan por la integridad referencial; habría que sustituirlas si se extrae un módulo (sección 3.2). | Decisión de este ADR, contra lo que pedía Isaí. |
| Con `managed = False`, Django no migra estas tablas, e `inspectdb` no genera `choices` ni `Meta.constraints` ni recoge los índices parciales. | Los cambios de esquema se hacen en `esquema_bd.sql`, y las restricciones se declaran a mano en los modelos (`revision_sql.md`, secciones 2.2 y 3.4). | Decisión de esta actividad. **Contradice el ADR-002 de Sebastián**, que contaba con las "migraciones" de Django como ventaja. El argumento es que el esquema entregado debe derivar del diagrama consolidado, no de lo que decida el ORM. |
| El costo deja de ser cero: el correo a clientes exige un dominio verificado, y un hosting sin suspensión tiene costo mensual. | Hay que decidirlo explícitamente (pendientes 2 y 6). | Emilio (dominio de Resend) y Sebastián (≈ 13–15 USD al mes). |
| Las tareas periódicas (outbox y RD-07) no corren si la aplicación está suspendida. | Un proceso programado externo a la aplicación (pendiente 3). | Emilio (el problema) y Sebastián (Cron Job). |

---

## 6. Decisiones pendientes

Ninguna de estas decisiones tiene un ADR que la respalde, o la proponía un solo ADR y el equipo no la ratificó. Este documento no las toma.

| # | Decisión | Qué propuso cada ADR | Por qué importa |
|---|---|---|---|
| 1 | **BLOQUEANTE para la Parte 2: tabla `administrador` propia o `django.contrib.auth`.** | Sebastián: `django.contrib.auth` con simplejwt (ADR-001, módulos). El diagrama consolidado y `esquema_bd.sql` tienen tabla propia. Los demás no lo deciden. | Define el modelo de usuario de Django y las llaves foráneas de `pedido` e `historial_estado` (`revision_sql.md`, pendiente 5). |
| 2 | **Hosting y plan frente a RNF-01.** | Sebastián: Render con plan Starter, sin suspensión, y Postgres administrado (ADR-002). Emilio: lo deja "pendiente del equipo", entre revisar RNF-01 o pagar un plan (ADR-001). Isaí: "proveedor cloud aún por decidir". Diego: no lo trata. | Un plan con suspensión incumple RNF-01 durante el horario de operación. |
| 3 | **Quién procesa el outbox y la purga de RD-07.** | Sebastián: Cron Job de Render, con `procesar_avisos` cada 10 minutos y `anonimizar_pedidos` diario (`diagrama_despliegue.puml`; ADR-001, escenario E1). Emilio: un job externo o la ejecución oportunista (ADR-001). | Sin un proceso, no se envía ningún aviso ni se cumple RD-07. El intento inmediato al confirmar el cambio es una decisión aparte (pendiente 14). |
| 4 | **Ratificar el resto del ADR-002 de Sebastián:** Python 3.12, simplejwt, Gunicorn con WhiteNoise y Docker. | Solo Sebastián. | El acuerdo del chat cubrió el framework, la API y la base de datos, no estas piezas. |
| 5 | **Tecnología del frontend, y si se sirve desde la misma unidad.** | Sebastián: HTML, Bootstrap 5 y Alpine.js, servidos con WhiteNoise. Emilio: React dentro de Next.js, ya descartado con el stack. Diego e Isaí: no lo deciden. | De esto dependen dónde vive el token (sección 3.4), la configuración de CORS y RNF-04. |
| 6 | **Proveedor de correo y dominio verificado.** | Sebastián y Emilio: Resend; Emilio advierte que sin dominio verificado solo se puede enviar al titular de la cuenta. | RF-12 no funciona sin él. |
| 7 | **Límite de solicitudes (429).** | Sebastián: 30 consultas por minuto por IP en el seguimiento y límite de intentos de login (ADR-001, escenario E4). Se quitó del contrato consolidado. | Es su táctica para RNF-03 (`diferencias_diseno.md`, sección 6.9). |
| 8 | **Vigencia y almacenamiento de los tokens.** | Sebastián: 15 minutos el de acceso, 8 horas el de renovación, en `sessionStorage` (ADR-001). El contrato no fija la vigencia. | Es la mitigación del riesgo de XSS (sección 5.2). |
| 9 | **Verificar la autorización también en la capa de servicios.** | Emilio: "Toda función de servicio que lea o modifique información administrativa verifica la sesión" (ADR-001, decisión 1). Sebastián: permiso `IsAdminUser` en la vista. | El motivo concreto de Emilio era de Next.js, pero el principio de no depender de una sola capa sigue en pie. |
| 10 | **Clave de idempotencia en las altas.** | Emilio y Sebastián la tenían en sus contratos; Isaí la dejaba como "mejora pendiente de aprobación". No hay tabla donde guardarla. | Pedidos duplicados cuando la respuesta tarda (`diferencias_diseno.md`, sección 6.9). |
| 11 | **Recolección a domicilio y módulo de logística.** | Emilio prevé un módulo `logistica` y estados nuevos (ADR-001). La entrevista real dice que la recolección es el punto de partida; el SRS la deja fuera (RD-08). | Puede agregar un quinto módulo y estados nuevos (`diferencias_diseno.md`, sección 6.1). |
| 12 | **Roles: un solo administrador o también nivel de empleado.** | Emilio: un rol de repartidor "contradice RD-06 y requerirá roles". La entrevista real se contradice a sí misma sobre esto. | Afecta al módulo de autenticación y al pendiente 1 (`revision_sql.md`, pendiente 8). |
| 13 | **Canal SMS.** | Emilio: un adaptador `SmsAdapter` previsto; advierte del registro A2P 10DLC en EE. UU. El SRS lo excluye; la entrevista lo pide. | El adaptador ya lo permite. Falta la decisión de alcance y de costo. |
| 14 | **Intento de envío inmediato con `transaction.on_commit()`.** | Sebastián: al confirmar el cambio de estado, `on_commit` intenta el envío y el Cron Job reintenta los fallidos (ADR-001, patrón Observer vía *post-commit*). Emilio: un proceso aparte lee los pendientes y los envía (ADR-001, decisión 3), sin intento inmediato. Diego e Isaí: no lo tratan. | Las dos opciones tienen un costo. **En contra de `on_commit`:** en Django, los *callbacks* de `on_commit` se ejecutan en el mismo proceso de la petición, así que la respuesta del cambio de estado espera al proveedor de correo, y un proveedor lento o caído retrasa la respuesta al administrador. **En contra de no tenerlo:** todo aviso espera al Cron Job, hasta diez minutos con la frecuencia de Sebastián. El criterio de éxito del stakeholder es "no lost orders or unnotified customers" (`emilio/entrevista_cliente_real.md`, Sección 1, Pregunta 7). **Lo que cambia en el contrato:** la descripción de `PUT /pedidos/{pedido_id}/estado` en `openapi_equipo.yaml` dice que "el envío al proveedor ocurre fuera de esta petición", y eso supone que no hay `on_commit`. Si se adopta, hay que corregir esa frase. |
